"""
modules/experience/rule_extraction.py
=======================================
Rule Extraction

Scans the Memory Journal for recurring (condition, action, outcome) patterns
and crystallises them into reusable rules stored in Strategy Memory.

Algorithm
---------
1. For each (metric, threshold) condition and each strategy action,
   count how many times applying the action under that condition
   led to a score improvement vs. score deterioration.
2. If P(improvement | condition, action) ≥ confidence_thresh
   over at least min_observations occurrences, emit a rule.
3. Conditions are discretised into "low / medium / high" buckets.

Rule Evolution (triggered from StrategyEvolution)
-------------------------------------------------
Similar rules are merged:
  "forget_acc > 0.25 → noise↑"  +  "forget_acc > 0.30 → noise↑"
  → "forget_acc high → noise↑"
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Tuple
import uuid

from unlearning_meta.schemas import (
    JournalEntry, StrategyAction, StrategyRecord, StrategyState
)
from unlearning_meta.modules.experience.memory_journal import MemoryJournal


# ─────────────────────────────────────────────────────────────────────────────
# Candidate rule accumulation
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class _Candidate:
    """Accumulates evidence for a potential rule."""
    condition_key:    str
    condition_op:     str
    condition_thresh: float
    action:           StrategyAction
    successes:        int = 0
    failures:         int = 0

    @property
    def total(self) -> int:
        return self.successes + self.failures

    @property
    def confidence(self) -> float:
        if self.total == 0:
            return 0.0
        return self.successes / self.total

    def rule_text(self) -> str:
        op_word = "above" if self.condition_op == ">" else "below"
        return (
            f"if {self.condition_key} {op_word} {self.condition_thresh:.2f}: "
            f"{self.action.value}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Main Rule Extractor
# ─────────────────────────────────────────────────────────────────────────────

class RuleExtractor:
    """
    Scans a MemoryJournal and emits new StrategyRecords (rules).

    Attributes:
        extracted_rules: List of StrategyRecords produced so far.
    """

    # Metrics and bucket thresholds
    METRICS = ["forget_acc", "retain_acc", "accuracy", "privacy",
               "hallucination", "stability"]

    # Low/medium/high thresholds per metric  (op ">")
    THRESHOLDS: Dict[str, List[Tuple[str, float]]] = {
        "forget_acc":    [(">", 0.15), (">", 0.25), (">", 0.40)],
        "retain_acc":    [("<", 0.85), ("<", 0.75), ("<", 0.60)],
        "accuracy":      [("<", 0.85), ("<", 0.75), ("<", 0.60)],
        "privacy":       [("<", 0.80), ("<", 0.65), ("<", 0.50)],
        "hallucination": [(">", 0.05), (">", 0.10), (">", 0.20)],
        "stability":     [("<", 0.80), ("<", 0.65), ("<", 0.50)],
    }

    def __init__(
        self,
        min_observations:   int   = 3,
        confidence_thresh:  float = 0.65,
        window:             int   = 15,
    ) -> None:
        self.min_obs           = min_observations
        self.conf_thresh       = confidence_thresh
        self.window            = window
        self.extracted_rules:  List[StrategyRecord] = []
        self._known_signatures: set = set()

    # ──────────────────────────────────────────────────────────────────────────

    def extract(
        self,
        journal:       MemoryJournal,
        current_cycle: int,
    ) -> List[StrategyRecord]:
        """
        Run rule extraction on the last `window` journal entries.

        Args:
            journal:       MemoryJournal to scan.
            current_cycle: Current cycle (used for rule metadata).

        Returns:
            List of newly extracted StrategyRecords.
        """
        recent  = journal.last_n(self.window)
        new_rules: List[StrategyRecord] = []

        # Index entries by consecutive (before, after) pairs for outcome detection
        pairs: List[Tuple[JournalEntry, JournalEntry]] = [
            (recent[i], recent[i + 1]) for i in range(len(recent) - 1)
        ]

        # Accumulate evidence for each (condition, action) combination
        candidates: Dict[str, _Candidate] = {}

        for before, after in pairs:
            # `after.strategy_applied` is the proposal that was DECIDED in
            # direct response to `before.metrics` (journal semantics: each
            # entry stores the metrics it produced AND the strategy that
            # caused them — i.e. journal[k].strategy_applied was decided
            # from journal[k-1].metrics). To correctly attribute "condition
            # observed → action chosen → outcome", we must pair the
            # condition on `before.metrics` with the action recorded on
            # `after` (decided right after seeing `before`), not the action
            # already baked into `before` itself.
            if after.strategy_applied is None:
                continue
            action = after.strategy_applied.action

            # Check which conditions were satisfied BEFORE the strategy was applied
            for metric, threshold_list in self.THRESHOLDS.items():
                value = getattr(before.metrics, metric, None)
                if value is None:
                    continue
                for op, thresh in threshold_list:
                    satisfied = (op == ">" and value > thresh) or \
                                (op == "<" and value < thresh)
                    if not satisfied:
                        continue

                    key = f"{metric}{op}{thresh:.2f}:{action.value}"
                    if key not in candidates:
                        candidates[key] = _Candidate(
                            condition_key=metric, condition_op=op,
                            condition_thresh=thresh, action=action
                        )
                    cand = candidates[key]

                    # Outcome: did the composite score improve?
                    if after.composite_score > before.composite_score + 0.02:
                        cand.successes += 1
                    else:
                        cand.failures  += 1

        # Promote strong candidates to rules
        for key, cand in candidates.items():
            if cand.total < self.min_obs:
                continue
            if cand.confidence < self.conf_thresh:
                continue
            if key in self._known_signatures:
                continue

            rule = self._make_rule(cand, current_cycle)
            self._known_signatures.add(key)
            self.extracted_rules.append(rule)
            new_rules.append(rule)

        return new_rules

    # ──────────────────────────────────────────────────────────────────────────

    def _make_rule(self, cand: _Candidate, cycle: int) -> StrategyRecord:
        return StrategyRecord(
            id                  = str(uuid.uuid4())[:8],
            rule                = cand.rule_text(),
            action              = cand.action,
            condition_key       = cand.condition_key,
            condition_op        = cand.condition_op,
            condition_thresh    = cand.condition_thresh,
            success_rate        = cand.confidence,
            generalization_score = 0.5,  # will be updated by StrategyEvolution
            usage_frequency     = 0,
            last_used           = cycle,
            confidence          = cand.confidence,
            state               = StrategyState.ACTIVE,
            created_at          = cycle,
        )
