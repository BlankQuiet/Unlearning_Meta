"""
modules/experience/self_explanation.py
========================================
Self Explanation

Converts raw metrics + reflection into human-readable natural language logs.
One explanation is generated per cycle.  These logs are:
  • stored in the Journal entry
  • used for rule extraction
  • useful for researchers inspecting system behaviour

Example output
--------------
  Cycle 7: Forget quality improved. Privacy risk detected.
  Retain accuracy stable. Increasing correction replay.
"""

from __future__ import annotations
from typing import List, Optional

from unlearning_meta.schemas import UnlearningMetrics, StrategyUpdate
from unlearning_meta.modules.experience.self_reflection import ReflectionReport


class SelfExplainer:
    """
    Generates natural language explanations of each unlearning cycle.
    """

    def explain(
        self,
        metrics:       UnlearningMetrics,
        reflection:    ReflectionReport,
        proposal:      Optional[StrategyUpdate],
        prev_score:    Optional[float] = None,
        current_score: Optional[float] = None,
    ) -> str:
        """
        Build a natural language explanation for the current cycle.

        Args:
            metrics:       Metrics from the completed unlearning step.
            reflection:    ReflectionReport from SelfReflection.
            proposal:      Strategy proposed for next cycle (may be None).
            prev_score:    Composite score from previous cycle.
            current_score: This cycle's composite score, already computed
                           by the caller with whatever weights/
                           target_forget_acc/retain_floor apply (see
                           ARCHITECTURE.md §16). Falls back to
                           metrics.composite_score() with default args if
                           omitted, for backward compatibility.

        Returns:
            Multi-sentence explanation string.
        """
        sentences: List[str] = []

        # ── Opening: overall trend ─────────────────────────────────────────
        if current_score is None:
            current_score = metrics.composite_score()
        if prev_score is None:
            sentences.append(f"Cycle {metrics.cycle}: Initial evaluation.")
        elif current_score > prev_score + 0.05:
            sentences.append(f"Cycle {metrics.cycle}: Overall score improved "
                             f"({prev_score:.3f} → {current_score:.3f}).")
        elif current_score < prev_score - 0.05:
            sentences.append(f"Cycle {metrics.cycle}: Score declined "
                             f"({prev_score:.3f} → {current_score:.3f}).")
        else:
            sentences.append(f"Cycle {metrics.cycle}: Score stable "
                             f"(≈ {current_score:.3f}).")

        # ── Forgetting quality ─────────────────────────────────────────────
        if metrics.forget_acc < 0.05:
            sentences.append("Forget quality excellent.")
        elif metrics.forget_acc < 0.15:
            sentences.append("Forget quality good.")
        elif metrics.forget_acc < 0.30:
            sentences.append("Forget quality moderate — residual memory detected.")
        else:
            sentences.append(f"Forget quality poor (forget_acc={metrics.forget_acc:.2f}).")

        # ── Retention ─────────────────────────────────────────────────────
        if metrics.retain_acc > 0.90:
            sentences.append("Retain accuracy excellent.")
        elif metrics.retain_acc > 0.75:
            sentences.append("Retain accuracy acceptable.")
        else:
            sentences.append(f"Retain accuracy degraded ({metrics.retain_acc:.2f}).")

        # ── Privacy ───────────────────────────────────────────────────────
        if metrics.privacy > 0.85:
            sentences.append("Privacy well preserved.")
        elif metrics.privacy > 0.65:
            sentences.append("Privacy adequate.")
        else:
            sentences.append(f"Privacy risk detected (score={metrics.privacy:.2f}).")

        # ── Hallucination (displayed as OMR — see ARCHITECTURE.md §11) ──────
        if metrics.hallucination < 0.05:
            sentences.append("No significant overconfident misclassification.")
        elif metrics.hallucination < 0.15:
            sentences.append("Minor overconfident misclassification present.")
        else:
            sentences.append(
                f"Overconfident misclassification risk high (OMR={metrics.hallucination:.2f})."
            )

        # ── Active failures ───────────────────────────────────────────────
        if reflection.active_failures:
            failure_str = ", ".join(reflection.active_failures)
            sentences.append(f"Active failure modes: {failure_str}.")

        if reflection.recurring_failures:
            rec_str = ", ".join(reflection.recurring_failures)
            sentences.append(f"Recurring issues: {rec_str}.")

        # ── Strategy proposal ─────────────────────────────────────────────
        if proposal is not None and not proposal.is_noop():
            sentences.append(
                f"Strategy for next cycle: {proposal.action.value} "
                f"(δ={proposal.delta:.4f}, conf={proposal.confidence:.2f}). "
                f"{proposal.rationale}"
            )
        else:
            sentences.append("No strategy change needed.")

        # ── Trend summary ─────────────────────────────────────────────────
        trend_msg = {
            "improving":         "Trend: improving. 📈",
            "stagnant":          "Trend: stagnant. ⚠️  Consider strategy change.",
            "declining":         "Trend: declining. 🔴 Urgent intervention needed.",
            "insufficient_data": "Trend: insufficient data.",
            "unknown":           "",
        }.get(reflection.score_trend, "")
        if trend_msg:
            sentences.append(trend_msg)

        return " ".join(sentences)
