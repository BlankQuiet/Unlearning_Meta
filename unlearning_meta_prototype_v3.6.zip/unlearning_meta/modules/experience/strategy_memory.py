"""
modules/experience/strategy_memory.py
=======================================
Long-Term Strategy Memory

Stores, retrieves, and manages the lifecycle of StrategyRecords.

Lifecycle states (per spec):
  ACTIVE   — recently useful, queried first
  DORMANT  — not used in N cycles
  ARCHIVE  — not used in M > N cycles; kept for potential revival
  DELETED  — importance score below threshold, permanently removed

Importance formula (per spec):
  importance = 0.35·success_rate
             + 0.25·generalization_score
             + 0.20·recency
             + 0.20·usage_frequency
"""

from __future__ import annotations
from typing import Dict, List, Optional

from unlearning_meta.schemas import (
    StrategyRecord, StrategyState, UnlearningMetrics
)


class StrategyMemory:
    """
    Long-Term Strategy Memory with 4-state lifecycle management.

    Attributes:
        records: Dict[id → StrategyRecord] for all non-deleted records.
    """

    def __init__(
        self,
        max_active:           int   = 30,
        max_dormant:          int   = 60,
        max_archive:          int   = 120,
        importance_threshold: float = 0.25,
        dormant_after:        int   = 15,
        archive_after:        int   = 50,
        w_success:            float = 0.35,
        w_gen:                float = 0.25,
        w_recency:            float = 0.20,
        w_usage:              float = 0.20,
    ) -> None:
        self.max_active           = max_active
        self.max_dormant          = max_dormant
        self.max_archive          = max_archive
        self.importance_threshold = importance_threshold
        self.dormant_after        = dormant_after
        self.archive_after        = archive_after
        self.w_success            = w_success
        self.w_gen                = w_gen
        self.w_recency            = w_recency
        self.w_usage              = w_usage

        self.records: Dict[str, StrategyRecord] = {}
        self._deleted_count = 0

    # ──────────────────────────────────────────────────────────────────────────
    # Storage
    # ──────────────────────────────────────────────────────────────────────────

    def add(self, record: StrategyRecord) -> None:
        """Store a new strategy record."""
        self.records[record.id] = record

    def get(self, record_id: str) -> Optional[StrategyRecord]:
        return self.records.get(record_id)

    # ──────────────────────────────────────────────────────────────────────────
    # Query
    # ──────────────────────────────────────────────────────────────────────────

    def query(
        self,
        metrics:       UnlearningMetrics,
        state_filter:  Optional[StrategyState] = StrategyState.ACTIVE,
        top_k:         int = 5,
        current_cycle: int = 0,
    ) -> List[StrategyRecord]:
        """
        Retrieve strategies matching the current metrics.

        Args:
            metrics:      Current cycle metrics (used to check conditions).
            state_filter: Only return records in this state (None = all states).
            top_k:        Return at most this many records.
            current_cycle: Used for importance scoring.

        Returns:
            List of matching StrategyRecords sorted by importance (descending).
        """
        matching = [
            r for r in self.records.values()
            if (state_filter is None or r.state == state_filter)
            and r.state != StrategyState.DELETED
            and r.matches(metrics)
        ]
        # Sort by importance
        matching.sort(
            key=lambda r: r.importance(
                current_cycle,
                w_success  = self.w_success,
                w_gen      = self.w_gen,
                w_recency  = self.w_recency,
                w_usage    = self.w_usage,
            ),
            reverse=True,
        )
        return matching[:top_k]

    def best_strategy(
        self,
        metrics:       UnlearningMetrics,
        current_cycle: int,
    ) -> Optional[StrategyRecord]:
        """Return the single highest-importance matching strategy."""
        results = self.query(metrics, state_filter=None, top_k=1,
                             current_cycle=current_cycle)
        return results[0] if results else None

    # ──────────────────────────────────────────────────────────────────────────
    # Update
    # ──────────────────────────────────────────────────────────────────────────

    def record_outcome(
        self,
        record_id:  str,
        success:    bool,
        cycle:      int,
        score_delta: float = 0.0,
    ) -> None:
        """
        Update a strategy's success rate and usage stats after application.

        Args:
            record_id:   ID of the strategy used.
            success:     Did the composite score improve?
            cycle:       Current cycle number.
            score_delta: Actual score change.
        """
        rec = self.records.get(record_id)
        if rec is None:
            return

        # Exponential moving average for success_rate
        alpha = 0.3
        new_success = 1.0 if success else 0.0
        rec.success_rate = (1 - alpha) * rec.success_rate + alpha * new_success

        rec.usage_frequency += 1
        rec.last_used        = cycle
        rec.state            = StrategyState.ACTIVE

        # Update generalisation score based on context diversity
        rec.generalization_score = min(
            1.0, rec.generalization_score + 0.02 if success else rec.generalization_score - 0.01
        )
        rec.confidence = (rec.success_rate + rec.generalization_score) / 2.0

        rec.update_history.append({
            "cycle":       cycle,
            "success":     success,
            "score_delta": score_delta,
        })

    # ──────────────────────────────────────────────────────────────────────────
    # Lifecycle management
    # ──────────────────────────────────────────────────────────────────────────

    def run_lifecycle(self, current_cycle: int) -> Dict[str, int]:
        """
        Transition strategies between states based on recency and importance.

        Returns:
            {"dormanted": int, "archived": int, "deleted": int}
        """
        dormanted = archived = deleted = 0
        to_delete: List[str] = []

        for rid, rec in self.records.items():
            if rec.state == StrategyState.DELETED:
                continue

            cycles_since_use = current_cycle - rec.last_used

            # Active → Dormant
            if rec.state == StrategyState.ACTIVE:
                if cycles_since_use >= self.dormant_after:
                    rec.state = StrategyState.DORMANT
                    dormanted += 1

            # Dormant → Archive
            elif rec.state == StrategyState.DORMANT:
                if cycles_since_use >= self.archive_after:
                    rec.state = StrategyState.ARCHIVE
                    archived  += 1

            # Archive → Delete (if importance too low)
            if rec.state == StrategyState.ARCHIVE:
                imp = rec.importance(current_cycle, self.w_success, self.w_gen,
                                      self.w_recency, self.w_usage)
                if imp < self.importance_threshold:
                    to_delete.append(rid)
                    deleted += 1

        for rid in to_delete:
            self.records[rid].state = StrategyState.DELETED

        # Enforce capacity limits — drop lowest-importance records per state
        self._enforce_capacity(current_cycle)

        self._deleted_count += deleted
        return {"dormanted": dormanted, "archived": archived, "deleted": deleted}

    def _enforce_capacity(self, current_cycle: int) -> None:
        def by_importance(r):
            return r.importance(current_cycle, self.w_success, self.w_gen,
                                 self.w_recency, self.w_usage)

        for state, cap in [
            (StrategyState.ACTIVE,  self.max_active),
            (StrategyState.DORMANT, self.max_dormant),
            (StrategyState.ARCHIVE, self.max_archive),
        ]:
            recs = sorted(
                [r for r in self.records.values() if r.state == state],
                key=by_importance,
            )
            excess = len(recs) - cap
            for rec in recs[:max(0, excess)]:
                rec.state = StrategyState.DELETED

    # ──────────────────────────────────────────────────────────────────────────
    # Summary
    # ──────────────────────────────────────────────────────────────────────────

    def stats(self) -> Dict[str, int]:
        counts: Dict[str, int] = {s.value: 0 for s in StrategyState}
        for r in self.records.values():
            counts[r.state.value] += 1
        counts["deleted_total"] = self._deleted_count
        return counts

    def __len__(self) -> int:
        return sum(
            1 for r in self.records.values()
            if r.state != StrategyState.DELETED
        )
