"""
modules/experience/meta_knowledge.py
======================================
Meta Knowledge

Maintains higher-order statistics about the unlearning process itself.
The Experience Engine uses meta-knowledge to calibrate its strategy proposals.

Tracks
------
  • Per-action effectiveness history
  • Best score achieved and when
  • Exploration vs exploitation balance
  • Confidence calibration over time
  • Action co-occurrence patterns (which combos work together)
"""

from __future__ import annotations
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Deque, Dict, List, Optional, Tuple
import math

from unlearning_meta.schemas import StrategyAction, UnlearningMetrics


@dataclass
class ActionStats:
    """Running statistics for one strategy action."""
    action: StrategyAction
    total_uses:    int   = 0
    total_success: int   = 0
    sum_delta:     float = 0.0    # sum of score deltas when used
    ema_success:   float = 0.5    # exponential moving average of success rate
    ema_delta:     float = 0.0    # EMA of score delta

    def update(self, success: bool, delta: float, alpha: float = 0.3) -> None:
        self.total_uses    += 1
        self.total_success += int(success)
        self.sum_delta     += delta
        self.ema_success    = (1 - alpha) * self.ema_success + alpha * float(success)
        self.ema_delta      = (1 - alpha) * self.ema_delta   + alpha * delta

    @property
    def mean_delta(self) -> float:
        return self.sum_delta / max(self.total_uses, 1)

    @property
    def success_rate(self) -> float:
        return self.total_success / max(self.total_uses, 1)


class MetaKnowledge:
    """
    Accumulates and exposes higher-level knowledge about the learning process.

    Key outputs used by ExperienceEngine:
      • ucb_score(action)    — Upper Confidence Bound for exploration/exploitation
      • best_action_for()    — Recommends action for a given failure mode
      • cycle_budget()       — Estimates remaining useful iterations
    """

    # Default action-to-failure mapping (bootstrap before experience)
    _DEFAULT_FAILURE_MAP: Dict[str, StrategyAction] = {
        "forget_failure":          StrategyAction.INCREASE_FORGETTING_STRENGTH,
        "forget_progress_stalled": StrategyAction.INCREASE_GRAD_CLIP,
        "retain_damage":           StrategyAction.INCREASE_REPLAY,
        "privacy_risk":            StrategyAction.INCREASE_NOISE,
        "hallucination_risk":      StrategyAction.INCREASE_CORRECTION_REPLAY,
        "knowledge_conflict":      StrategyAction.INCREASE_EWC,
        "noop":                    StrategyAction.NOOP,
    }

    def __init__(
        self,
        exploration_rate: float = 0.15,
        history_window:   int   = 50,
    ) -> None:
        self.exploration_rate = exploration_rate
        self.history_window   = history_window

        # Per-action statistics
        self.action_stats: Dict[str, ActionStats] = {
            a.value: ActionStats(action=a) for a in StrategyAction
        }

        # Global best
        self.best_score:   float = -math.inf
        self.best_cycle:   int   = 0
        self.best_metrics: Optional[UnlearningMetrics] = None

        # Score trajectory
        self.score_history: Deque[float] = deque(maxlen=history_window)

        # Cycle counter
        self.total_cycles = 0

        # Co-occurrence: {(a1,a2): delta_sum, count}
        self._cooccurrence: Dict[Tuple, List] = defaultdict(lambda: [0.0, 0])
        self._last_action: Optional[StrategyAction] = None

    # ──────────────────────────────────────────────────────────────────────────

    def update(
        self,
        action:        Optional[StrategyAction],
        metrics:       UnlearningMetrics,
        score_delta:   float,
        success:       bool,
        score:         Optional[float] = None,
    ) -> None:
        """
        Record outcome of one cycle.

        Args:
            score: The cycle's composite score, already computed by the
                  caller (ExperienceEngine.process(), with whatever
                  weights/target_forget_acc/retain_floor apply for this
                  run — see ARCHITECTURE.md §16). If omitted, falls back
                  to metrics.composite_score() with default args for
                  backward compatibility with any direct caller that
                  predates this parameter, but any run using
                  target_forget_acc should always pass it explicitly, or
                  best_score/best_cycle tracking below will silently use
                  the wrong target.
        """
        self.total_cycles += 1
        if score is None:
            score = metrics.composite_score()
        self.score_history.append(score)

        if score > self.best_score:
            self.best_score   = score
            self.best_cycle   = metrics.cycle
            self.best_metrics = metrics

        if action is not None:
            self.action_stats[action.value].update(success, score_delta)

            # Co-occurrence tracking
            if self._last_action is not None:
                pair = (self._last_action.value, action.value)
                self._cooccurrence[pair][0] += score_delta
                self._cooccurrence[pair][1] += 1

            self._last_action = action

    # ──────────────────────────────────────────────────────────────────────────

    def ucb_score(
        self, action: StrategyAction, c: float = 1.41
    ) -> float:
        """
        Upper Confidence Bound score for ε-greedy exploration.

          UCB(a) = µ(a) + c · sqrt(ln(N) / n(a))

        where µ(a) = EMA success rate, N = total cycles, n(a) = uses of action.
        """
        stats = self.action_stats[action.value]
        n = max(stats.total_uses, 1)
        N = max(self.total_cycles, 1)
        exploit = stats.ema_success
        explore = c * math.sqrt(math.log(N) / n)
        return exploit + explore

    def best_action_for(
        self,
        failure_type:  str,
        use_meta:      bool = True,
    ) -> StrategyAction:
        """
        Recommend the best action for a given failure type.

        Args:
            failure_type: e.g. "forget_failure"
            use_meta:     If True, bias by meta-knowledge; else use defaults.

        Returns:
            Recommended StrategyAction
        """
        default = self._DEFAULT_FAILURE_MAP.get(failure_type, StrategyAction.NOOP)

        if not use_meta or self.total_cycles < 5:
            return default

        # Find action with highest EMA success rate + delta
        candidates = [
            a for a in StrategyAction if a != StrategyAction.NOOP
        ]
        best_action = max(
            candidates,
            key=lambda a: self.ucb_score(a) + self.action_stats[a.value].ema_delta * 0.5,
        )
        return best_action

    def recommended_delta(self, action: StrategyAction) -> float:
        """
        Compute recommended step size for an action based on past outcomes.
        Larger deltas when improvement has been large; smaller when volatile.
        """
        stats = self.action_stats[action.value]
        if stats.total_uses < 3:
            return 0.2   # default starting delta

        # Calibrate: if EMA delta positive, keep current pace; if negative, halve
        base = 0.2
        if stats.ema_delta > 0.05:
            return min(0.5, base * (1 + stats.ema_delta))
        elif stats.ema_delta < -0.05:
            return max(0.05, base * 0.5)
        return base

    def score_trend(self, window: int = 10) -> str:
        """Quick trend classifier over recent window."""
        recent = list(self.score_history)[-window:]
        if len(recent) < 3:
            return "unknown"
        mid = len(recent) // 2
        early = sum(recent[:mid]) / mid
        late  = sum(recent[mid:]) / (len(recent) - mid)
        if late > early + 0.03:
            return "improving"
        elif late < early - 0.03:
            return "declining"
        return "stagnant"

    def summary(self) -> Dict:
        return {
            "total_cycles": self.total_cycles,
            "best_score":   round(self.best_score, 4),
            "best_cycle":   self.best_cycle,
            "trend":        self.score_trend(),
            "action_stats": {
                k: {
                    "uses":         v.total_uses,
                    "success_rate": round(v.success_rate, 3),
                    "ema_delta":    round(v.ema_delta, 4),
                }
                for k, v in self.action_stats.items()
                if v.total_uses > 0
            },
        }
