"""
modules/experience/strategy_evolution.py
==========================================
Strategy Evolution

Merges structurally similar strategies into higher-level generalisations.

Example (per spec):
  "forget_acc > 0.25 → noise↑"
  "forget_acc > 0.30 → noise↑"
  "forget_acc > 0.35 → noise↑"
          ↓
  "forget_acc high → noise↑"   (threshold replaced by qualitative label)

Algorithm
---------
1. Collect active StrategyRecords from StrategyMemory.
2. Group by (condition_key, action).
3. Within each group, find threshold clusters via hierarchical clustering.
4. Merge clusters whose success_rates are consistent and thresholds are close.
5. Replace merged records with a single generalised record.
6. Update generalization_score of merged record proportionally.
"""

from __future__ import annotations
from typing import Dict, List, Tuple
import uuid

from unlearning_meta.schemas import StrategyRecord, StrategyState
from unlearning_meta.modules.experience.strategy_memory import StrategyMemory


class StrategyEvolution:
    """
    Compresses similar strategies into abstract generalisations.
    """

    def __init__(
        self,
        similarity_thresh: float = 0.78,
        max_rounds:        int   = 5,
    ) -> None:
        self.similarity_thresh = similarity_thresh
        self.max_rounds        = max_rounds
        self.merge_log: List[Dict] = []

    # ──────────────────────────────────────────────────────────────────────────

    def evolve(
        self,
        memory:        StrategyMemory,
        current_cycle: int,
    ) -> int:
        """
        Run strategy evolution on the memory store.

        Args:
            memory:        StrategyMemory to evolve.
            current_cycle: Current cycle number.

        Returns:
            Number of merges performed.
        """
        total_merges = 0

        for _round in range(self.max_rounds):
            merges_this_round = self._run_one_round(memory, current_cycle)
            total_merges += merges_this_round
            if merges_this_round == 0:
                break

        return total_merges

    # ──────────────────────────────────────────────────────────────────────────

    def _run_one_round(
        self,
        memory:        StrategyMemory,
        current_cycle: int,
    ) -> int:
        """Execute one round of merge operations. Returns merge count."""
        active_records = [
            r for r in memory.records.values()
            if r.state in (StrategyState.ACTIVE, StrategyState.DORMANT)
        ]

        # Group by (condition_key, condition_op, action)
        groups: Dict[Tuple, List[StrategyRecord]] = {}
        for rec in active_records:
            key = (rec.condition_key, rec.condition_op, rec.action)
            groups.setdefault(key, []).append(rec)

        merge_count = 0
        for group_key, group in groups.items():
            if len(group) < 2:
                continue

            clusters = self._cluster_by_threshold(group)
            for cluster in clusters:
                if len(cluster) < 2:
                    continue
                if not self._should_merge(cluster):
                    continue

                merged = self._merge(cluster, current_cycle, group_key)
                # Add merged record to memory
                memory.add(merged)
                # Mark originals as deleted
                for rec in cluster:
                    rec.state = StrategyState.DELETED
                merge_count += 1

                self.merge_log.append({
                    "cycle":    current_cycle,
                    "merged":   [r.id for r in cluster],
                    "result_id": merged.id,
                    "rule":     merged.rule,
                })

        return merge_count

    # ──────────────────────────────────────────────────────────────────────────

    def _cluster_by_threshold(
        self, records: List[StrategyRecord]
    ) -> List[List[StrategyRecord]]:
        """
        Greedy single-linkage clustering by threshold proximity.
        Two records are linkable if |thresh_i - thresh_j| < 0.15.
        """
        LINK_DIST = 0.15
        sorted_recs = sorted(records, key=lambda r: r.condition_thresh)

        clusters: List[List[StrategyRecord]] = [[sorted_recs[0]]]
        for rec in sorted_recs[1:]:
            last_thresh = clusters[-1][-1].condition_thresh
            if abs(rec.condition_thresh - last_thresh) < LINK_DIST:
                clusters[-1].append(rec)
            else:
                clusters.append([rec])

        return clusters

    def _should_merge(self, cluster: List[StrategyRecord]) -> bool:
        """
        Merge only if success rates within cluster are consistent.
        Consistency = low variance in success_rate.
        """
        rates = [r.success_rate for r in cluster]
        mean  = sum(rates) / len(rates)
        # Cosine-like consistency: variance penalty
        variance = sum((r - mean) ** 2 for r in rates) / len(rates)
        consistency = 1.0 / (1.0 + variance * 10)
        return consistency >= self.similarity_thresh

    def _merge(
        self,
        cluster:       List[StrategyRecord],
        cycle:         int,
        group_key:     Tuple,
    ) -> StrategyRecord:
        """Create a generalised record from a cluster."""
        condition_key, condition_op, action = group_key

        # Generalised threshold = mean threshold of cluster
        mean_thresh  = sum(r.condition_thresh for r in cluster) / len(cluster)
        mean_success = sum(r.success_rate     for r in cluster) / len(cluster)
        total_usage  = sum(r.usage_frequency  for r in cluster)
        min_thresh   = min(r.condition_thresh for r in cluster)
        max_thresh   = max(r.condition_thresh for r in cluster)

        # Qualitative label for the condition value
        if condition_op == ">":
            quality_label = "high"  # above threshold = high
        else:
            quality_label = "low"

        rule_text = (
            f"[EVOLVED] if {condition_key} {quality_label} "
            f"(thresh ∈ [{min_thresh:.2f},{max_thresh:.2f}]): {action.value}"
        )

        # Generalization score increases with cluster size
        gen_score = min(1.0, 0.5 + 0.1 * len(cluster))

        return StrategyRecord(
            id                  = str(uuid.uuid4())[:8],
            rule                = rule_text,
            action              = action,
            condition_key       = condition_key,
            condition_op        = condition_op,
            condition_thresh    = mean_thresh,
            success_rate        = mean_success,
            generalization_score = gen_score,
            usage_frequency     = total_usage,
            last_used           = cycle,
            confidence          = (mean_success + gen_score) / 2.0,
            state               = StrategyState.ACTIVE,
            created_at          = cycle,
        )
