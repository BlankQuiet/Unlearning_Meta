"""
modules/experience/self_reflection.py
=======================================
Self Reflection

Analyses recent journal entries to identify failure modes and root causes.

Failure taxonomy (per spec):
  • forget_failure      — forget_acc still too high after unlearning
  • retain_damage       — retain_acc dropped significantly
  • privacy_risk        — privacy score too low (MIA succeeds)
  • hallucination_risk  — hallucination rate too high
  • knowledge_conflict  — high accuracy but inconsistent between runs

Addition beyond the original spec (ARCHITECTURE.md §12.3-12.4):
  • forget_progress_stalled — increase_forgetting_strength applied
    repeatedly with no measurable effect on forget_acc; a distinct
    condition from forget_failure requiring journal history, not just
    the current cycle's metrics, to detect.

Output: ReflectionReport — structured analysis passed to Self Explanation.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List

from unlearning_meta.schemas import UnlearningMetrics, StrategyAction, JournalEntry
from unlearning_meta.modules.experience.memory_journal import MemoryJournal


@dataclass
class ReflectionReport:
    """Structured output of one reflection pass."""
    cycle: int
    active_failures: List[str]           # failure types detected this cycle
    recurring_failures: List[str]        # failures seen in last N cycles
    score_trend: str                     # "improving" | "stagnant" | "declining"
    suggested_focus: str                 # primary issue to address
    confidence: float                    # 0–1 confidence in this analysis
    notes: Dict[str, str] = field(default_factory=dict)


class SelfReflection:
    """
    Reflects on recent Journal entries to detect and classify failures.
    """

    # Thresholds for failure detection
    FORGET_FAIL_THRESH    = 0.20   # forget_acc > this  → forget_failure
    RETAIN_DAMAGE_THRESH  = 0.70   # retain_acc < this  → retain_damage
    PRIVACY_RISK_THRESH   = 0.60   # privacy    < this  → privacy_risk
    HALLUC_RISK_THRESH    = 0.15   # hallucin.  > this  → hallucination_risk
    STAGNANT_DELTA        = 0.02   # score delta < this  → stagnant

    def __init__(self, window: int = 10) -> None:
        self.window = window

    # ──────────────────────────────────────────────────────────────────────────

    def reflect(
        self,
        journal: MemoryJournal,
        current_cycle: int,
    ) -> ReflectionReport:
        """
        Analyse journal and return a structured ReflectionReport.

        Args:
            journal:       The MemoryJournal to analyse.
            current_cycle: Current cycle number.

        Returns:
            ReflectionReport
        """
        recent = journal.last_n(self.window)
        if not recent:
            return ReflectionReport(
                cycle=current_cycle,
                active_failures=[],
                recurring_failures=[],
                score_trend="unknown",
                suggested_focus="noop",
                confidence=0.0,
            )

        latest = recent[-1]

        # ── Active failures (this cycle) ───────────────────────────────────
        active = self._detect_failures(latest.metrics)

        # ── Stalled-forgetting pattern (addition beyond the original 5-item
        # spec — see ARCHITECTURE.md §12.3-12.4): the lever being pulled
        # repeatedly is having no effect, which is a distinct condition from
        # forget_failure (metrics.forget_acc alone can't tell "still trying,
        # making progress" apart from "trying the same thing repeatedly,
        # going nowhere") ─────────────────────────────────────────────────
        if self._is_forget_progress_stalled(recent):
            active.append("forget_progress_stalled")

        # ── Recurring failures (last N cycles) ────────────────────────────
        all_failures: List[str] = []
        for e in recent:
            all_failures.extend(self._detect_failures(e.metrics))
        from collections import Counter
        freq = Counter(all_failures)
        recurring = [f for f, cnt in freq.items() if cnt >= max(2, len(recent) // 3)]

        # ── Score trend ───────────────────────────────────────────────────
        scores = [e.composite_score for e in recent]
        score_trend = self._classify_trend(scores)

        # ── Suggested focus ───────────────────────────────────────────────
        focus = self._suggested_focus(active, recurring, latest.metrics)

        # ── Confidence ────────────────────────────────────────────────────
        confidence = min(1.0, len(recent) / self.window)

        return ReflectionReport(
            cycle            = current_cycle,
            active_failures  = active,
            recurring_failures = recurring,
            score_trend      = score_trend,
            suggested_focus  = focus,
            confidence       = confidence,
            notes            = self._generate_notes(latest.metrics, scores),
        )

    # ──────────────────────────────────────────────────────────────────────────

    def _detect_failures(self, m: UnlearningMetrics) -> List[str]:
        failures = []
        if m.forget_acc    >  self.FORGET_FAIL_THRESH:   failures.append("forget_failure")
        if m.retain_acc    <  self.RETAIN_DAMAGE_THRESH:  failures.append("retain_damage")
        if m.privacy       <  self.PRIVACY_RISK_THRESH:   failures.append("privacy_risk")
        if m.hallucination >  self.HALLUC_RISK_THRESH:    failures.append("hallucination_risk")
        # Knowledge conflict: good accuracy but poor stability
        if m.accuracy > 0.80 and m.stability < 0.50:     failures.append("knowledge_conflict")
        return failures

    def _is_forget_progress_stalled(
        self,
        recent: List[JournalEntry],
        min_repeats: int = 3,
        improvement_thresh: float = 0.03,
    ) -> bool:
        """
        True if increase_forgetting_strength has been applied repeatedly
        (>= min_repeats times within the window) while forget_acc barely
        moved (< improvement_thresh total drop across that span) and is
        still above the forget-failure threshold.

        This is a distinct condition from plain forget_failure: metrics
        alone (a single cycle's forget_acc) can't distinguish "still
        working on it, making progress" from "pulling the same lever
        repeatedly, going nowhere" — that distinction requires looking at
        journal history, which is why this lives in SelfReflection (which
        has journal access) rather than in the pure metrics-only
        _detect_failures check above.
        """
        relevant = [
            e for e in recent
            if e.strategy_applied is not None
            and e.strategy_applied.action == StrategyAction.INCREASE_FORGETTING_STRENGTH
        ]
        if len(relevant) < min_repeats:
            return False
        if recent[-1].metrics.forget_acc <= self.FORGET_FAIL_THRESH:
            return False   # already succeeded — nothing stalled
        forget_accs = [e.metrics.forget_acc for e in relevant]
        total_improvement = forget_accs[0] - forget_accs[-1]   # positive = got better
        return total_improvement < improvement_thresh

    def _classify_trend(self, scores: List[float]) -> str:
        if len(scores) < 3:
            return "insufficient_data"
        mid = len(scores) // 2
        early_mean = sum(scores[:mid]) / mid
        late_mean  = sum(scores[mid:]) / (len(scores) - mid)
        delta = late_mean - early_mean
        if delta > self.STAGNANT_DELTA:
            return "improving"
        elif delta < -self.STAGNANT_DELTA:
            return "declining"
        return "stagnant"

    def _suggested_focus(
        self,
        active:    List[str],
        recurring: List[str],
        m:         UnlearningMetrics,
    ) -> str:
        """Pick the most urgent issue to address."""
        priority_order = [
            "forget_progress_stalled",  # more specific than forget_failure —
                                         # the generic lever already failed
            "forget_failure",
            "privacy_risk",
            "retain_damage",
            "hallucination_risk",
            "knowledge_conflict",
        ]
        combined = set(active) | set(recurring)
        for issue in priority_order:
            if issue in combined:
                return issue
        return "noop"

    def _generate_notes(
        self, m: UnlearningMetrics, scores: List[float]
    ) -> Dict[str, str]:
        notes = {}
        if len(scores) >= 3:
            notes["score_5avg"] = f"{sum(scores[-5:]) / len(scores[-5:]):.3f}"
        notes["forget_acc"]    = f"{m.forget_acc:.3f}"
        notes["retain_acc"]    = f"{m.retain_acc:.3f}"
        notes["privacy"]       = f"{m.privacy:.3f}"
        notes["hallucination"] = f"{m.hallucination:.3f}"
        return notes
