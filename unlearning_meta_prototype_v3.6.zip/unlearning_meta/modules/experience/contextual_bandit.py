"""
modules/experience/contextual_bandit.py
=========================================
Unified Contextual Bandit strategy selector — replaces the fixed-priority
Tier 1/2/3 hierarchy in ExperienceEngine._propose_strategy() with a single
scored comparison over the full action space, per external review round 2
Q3 and its empirical confirmation in ARCHITECTURE.md §13.

Score(a) = UCB(a) + beta * Rule_Prior(a)
action*  = argmax_a Score(a)

This module is based on a design proposal contributed during external
review (Gemini, round 3), adapted here to fix two integration bugs found
against the actual codebase and to add a cooldown mechanism motivated by
the specific failure this is meant to solve:

Fixes applied to the original proposal
-----------------------------------------
1. ``StrategyMemory.query()`` takes ``state_filter`` (a ``StrategyState``
   enum member), not ``state`` (a raw string) — the original proposal's
   ``memory.query(metrics, state="Active")`` would raise ``TypeError``
   against the actual method signature.
2. ``source_rule`` was not threaded through to the returned
   ``StrategyUpdate`` in the original proposal. Without it,
   ``ExperienceEngine.process()``'s existing rule-outcome-tracking step
   (``self.memory.record_outcome(record_id=...)``) silently stops
   reinforcing rules, since it keys off ``StrategyUpdate.source_rule``.
3. ``confidence`` on the returned proposal was set to the raw rule prior
   (0.0 whenever an action wins on UCB grounds alone, even confidently) —
   changed to reflect the actual winning score's composition instead of
   just the rule-prior component.

Cooldown mechanism (addition beyond the original proposal)
----------------------------------------------------------
§13.2 found a *specific, reproduced* failure: a single evolved rule with
confidence ~0.7-0.77 won every cycle for 12+ consecutive cycles once it
solidified, permanently blocking a more-specific, situationally-correct
alternative (``increase_grad_clip``) from ever being reconsidered — not
because the alternative was scored lower in any single comparison necessarily,
but because nothing ever forced a fresh comparison once one action's
score-plus-prior combination cleared every rival. A pure argmax score
comparison, run independently each cycle with slowly-changing UCB/prior
inputs, doesn't by itself guarantee an entrenched leader gets
periodically re-challenged — the leader's own inputs (confidence,
ema_success) only change if it stops being chosen, which a pure argmax
has no mechanism to force. A small cooldown closes this gap directly:
after ``cooldown_after`` consecutive cycles selecting the *same* action,
the single highest-scoring *different* action is selected instead for one
cycle, guaranteeing periodic re-evaluation of alternatives regardless of
how far ahead the incumbent's score currently is.
"""

from __future__ import annotations
import random
from typing import Dict, List, Optional, Tuple

from unlearning_meta.schemas import (
    StrategyAction, StrategyUpdate, StrategyState, UnlearningMetrics
)
from unlearning_meta.modules.experience.strategy_memory import StrategyMemory
from unlearning_meta.modules.experience.meta_knowledge import MetaKnowledge
from unlearning_meta.modules.experience.self_reflection import ReflectionReport


class ContextualBanditSelector:
    """
    Single unified scoring function over the full action space, replacing
    the fixed-priority Tier 1 (rule lookup) / Tier 2 (UCB fallback) /
    Tier 3 (random explore) hierarchy.
    """

    def __init__(
        self,
        beta:               float = 0.5,
        epsilon:            float = 0.15,
        cooldown_after:     int   = 4,
        momentum_patience:  int   = 2,
        seed:               int   = 42,
    ) -> None:
        """
        Args:
            beta:              Weight blending rule-based priors into the
                               UCB score. See ARCHITECTURE.md §14 for why a
                               fixed value was chosen over cycle-based
                               decay/scheduling (Gemini's round-3 question).
            epsilon:           Exploration probability, sampled exactly once
                               per call (fixes the independent-resampling bug
                               found in the old Tier 1/2/3 hierarchy —
                               ARCHITECTURE.md §11.2).
            cooldown_after:    Consecutive cycles selecting the SAME GROUP
                               before forcing reconsideration of the
                               next-best alternative group — see module
                               docstring.
            momentum_patience: Number of consecutive non-improving moves in
                               the current direction tolerated before a
                               paired group's momentum gives up and
                               re-opens the increase-vs-decrease comparison
                               (ARCHITECTURE.md §15). 1 = reverse
                               immediately on the first non-improving move;
                               higher values tolerate more noise before
                               concluding a direction has stopped helping.
            seed:              RNG seed.
        """
        self.beta              = beta
        self.epsilon           = epsilon
        self.cooldown_after    = cooldown_after
        self.momentum_patience = momentum_patience
        self._rng              = random.Random(seed)

        self._last_group_key:    Optional[str] = None
        self._consecutive_count: int = 0

        # Per-paired-parameter momentum state, keyed by config_attr:
        # {config_attr: {"direction": StrategyAction, "score_at_move": float,
        #                "stall_count": int}}
        self._momentum: Dict[str, Dict] = {}

    # ──────────────────────────────────────────────────────────────────────────

    def select(
        self,
        metrics:       UnlearningMetrics,
        reflection:    ReflectionReport,
        memory:        StrategyMemory,
        meta:          MetaKnowledge,
        cycle:         int,
        current_score: Optional[float] = None,
    ) -> StrategyUpdate:
        """
        Select the next strategy action via unified scoring, with
        parameter-level momentum for opposing action pairs.

        Args:
            current_score: This cycle's composite score, already computed
                           by the caller with whatever weights/
                           target_forget_acc/retain_floor apply for this
                           run (ARCHITECTURE.md §16). Falls back to
                           metrics.composite_score() with default args if
                           omitted. Passing this explicitly matters:
                           without it, momentum's "did the score improve"
                           check silently uses the wrong target on
                           instance-level benchmarks — see §16.

        Why grouping matters (ARCHITECTURE.md §15)
        ---------------------------------------------
        §14 found that treating increase_grad_clip / decrease_grad_clip
        (and the other three opposing pairs) as independent bandit arms
        causes thrashing: choosing one changes the environment the other
        is evaluated against (pulling max_grad_norm up changes what
        "pulling it back down" would even mean), which breaks the
        implicit independent-arms assumption standard UCB relies on —
        both directions look symmetrically "under-explored" and compete
        on that basis alone, with nothing to prefer "keep going, it's
        working" over "reverse, we haven't tried that in a while."

        This treats each opposing pair as ONE controlled parameter rather
        than two arms: they compete as a single group against the rest of
        the action space, and only *within* a winning paired group does
        directional momentum (not raw UCB) decide increase vs. decrease —
        continuing the current direction as long as the composite score
        hasn't gotten worse since the last move in that direction, and
        only re-opening the increase-vs-decrease comparison when it has.

        Returns:
            StrategyUpdate ready to hand to UnlearningEngine.apply_strategy().
        """
        action_space = [a for a in StrategyAction if a != StrategyAction.NOOP]

        # ── 1. Exploration — single sample, not per-tier (§11.2 fix) ───────
        if self._rng.random() < self.epsilon:
            action = self._rng.choice(action_space)
            return self._finalize(action, cycle,
                                   rationale="Exploration (ε-greedy)",
                                   confidence=0.3, source_rule=None)

        # ── 2. Rule priors from Strategy Memory ─────────────────────────────
        active_rules = memory.query(
            metrics, state_filter=StrategyState.ACTIVE, top_k=len(action_space),
            current_cycle=cycle,
        )
        rule_priors: Dict[StrategyAction, float] = {}
        rule_ids:    Dict[StrategyAction, str]   = {}
        for rec in active_rules:
            if rec.confidence > rule_priors.get(rec.action, 0.0):
                rule_priors[rec.action] = rec.confidence
                rule_ids[rec.action]    = rec.id

        # ── 3. Score every individual action ────────────────────────────────
        scores: Dict[StrategyAction, float] = {}
        for action in action_space:
            ucb = meta.ucb_score(action)
            prior = rule_priors.get(action, 0.0)
            scores[action] = ucb + self.beta * prior

        # ── 4. Collapse opposing pairs into groups; singletons stand alone ──
        # Group key: config_attr for paired actions (shared by both
        # directions), the action itself for unpaired ones (increase_replay,
        # increase_correction_replay have no .opposite — see schemas.py).
        groups: Dict[str, List[StrategyAction]] = {}
        for action in action_space:
            key = action.config_attr if action.opposite is not None else action.value
            groups.setdefault(key, []).append(action)

        group_scores = {
            key: max(scores[a] for a in members)
            for key, members in groups.items()
        }
        best_group_key = max(group_scores, key=group_scores.get)
        best_group = groups[best_group_key]

        # ── 5. Cooldown at the GROUP level ──────────────────────────────────
        if best_group_key == self._last_group_key:
            self._consecutive_count += 1
        else:
            self._consecutive_count = 1

        if self._consecutive_count > self.cooldown_after:
            runner_up_key = max(
                (k for k in group_scores if k != best_group_key),
                key=group_scores.get,
            )
            active_group_key = runner_up_key
            active_group = groups[runner_up_key]
            forced_note = (
                f"Cooldown: group '{best_group_key}' led "
                f"{self._consecutive_count-1} consecutive cycles; "
                f"forcing runner-up group '{runner_up_key}'. "
            )
            self._consecutive_count = 1
        else:
            active_group_key = best_group_key
            active_group = best_group
            forced_note = ""

        # ── 6. Within the active group: momentum for pairs, direct pick otherwise
        if len(active_group) == 1:
            chosen = active_group[0]
            rationale = (
                f"{forced_note}Group '{active_group_key}' "
                f"(single option) score={scores[chosen]:.2f}"
            )
        else:
            chosen, rationale = self._resolve_paired_group(
                active_group_key, active_group, scores, metrics, forced_note,
                current_score=current_score,
            )

        self._last_group_key = active_group_key
        confidence = min(1.0, max(rule_priors.get(chosen, 0.0), scores[chosen] / 3.0))

        return self._finalize(chosen, cycle, rationale, confidence,
                              source_rule=rule_ids.get(chosen))

    # ──────────────────────────────────────────────────────────────────────────

    def _resolve_paired_group(
        self,
        config_attr:   str,
        pair:          List[StrategyAction],
        scores:        Dict[StrategyAction, float],
        metrics:       UnlearningMetrics,
        forced_note:   str,
        current_score: Optional[float] = None,
    ) -> Tuple[StrategyAction, str]:
        """
        Decide increase_X vs decrease_X for a winning paired group using
        directional momentum rather than a fresh raw-score comparison every
        cycle — the actual fix for §14's oscillation (see class docstring).

        Momentum rule: if this parameter was moved in some direction on a
        previous cycle and the composite score has not gotten worse since,
        keep moving the same direction — bypass the increase-vs-decrease
        UCB comparison entirely, since "it's working, keep going" is
        exactly the information raw per-cycle UCB scores can't see. Only
        when the score has failed to improve (within momentum_patience
        cycles of tolerance) does this fall back to comparing the two
        directions' scores directly and potentially reverse.

        current_score must reflect whatever target_forget_acc/retain_floor
        apply for this run (ARCHITECTURE.md §16) — falling back to
        metrics.composite_score() with default args here would silently
        judge "improvement" against the wrong target on instance-level
        benchmarks, exactly the bug this parameter exists to prevent.

        Returns:
            (chosen_action, rationale_string)
        """
        if current_score is None:
            current_score = metrics.composite_score()
        state = self._momentum.get(config_attr)

        if state is not None:
            direction: StrategyAction = state["direction"]
            improved = current_score >= state["score_at_move"] - 1e-6
            if improved:
                state["stall_count"] = 0
            else:
                state["stall_count"] += 1

            if improved or state["stall_count"] <= self.momentum_patience:
                # Keep going — do NOT re-derive from raw UCB this cycle.
                chosen = direction
                rationale = (
                    f"{forced_note}Momentum: '{config_attr}' continuing "
                    f"{chosen.value} (score {'improved' if improved else 'held'} "
                    f"since last move, stall_count={state['stall_count']})"
                )
                state["score_at_move"] = max(current_score, state["score_at_move"])
                return chosen, rationale
            # else: patience exhausted — fall through to re-compare below,
            # and reset state fully after the new pick.

        # No momentum state yet, or patience just ran out: fresh comparison.
        chosen = max(pair, key=scores.get)
        self._momentum[config_attr] = {
            "direction": chosen, "score_at_move": current_score, "stall_count": 0,
        }
        rationale = (
            f"{forced_note}'{config_attr}': fresh comparison "
            f"({pair[0].value}={scores[pair[0]]:.2f} vs "
            f"{pair[1].value}={scores[pair[1]]:.2f}) -> {chosen.value}"
        )
        return chosen, rationale

    # ──────────────────────────────────────────────────────────────────────────

    def _finalize(
        self,
        action:      StrategyAction,
        cycle:       int,
        rationale:   str,
        confidence:  float,
        source_rule: Optional[str],
    ) -> StrategyUpdate:
        if action == StrategyAction.NOOP:
            return StrategyUpdate(action=action, delta=0.0, rationale=rationale,
                                  confidence=confidence, cycle=cycle)
        return StrategyUpdate(
            action=action, delta=0.2, rationale=rationale,
            confidence=confidence, source_rule=source_rule, cycle=cycle,
        )
