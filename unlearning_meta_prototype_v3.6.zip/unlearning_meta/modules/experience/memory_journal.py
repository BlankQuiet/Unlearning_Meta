"""
modules/experience/memory_journal.py
======================================
Memory Journal

Chronological log of every unlearning cycle.  The Experience Engine
reads the journal to extract rules, reflect on failures, and track
strategy outcomes.

Each entry records:
  • metrics from that cycle
  • which strategy was applied
  • composite score achieved
  • detected failure types
  • free-text explanation
"""

from __future__ import annotations
from collections import deque
from typing import Deque, List, Optional, Dict

from unlearning_meta.schemas import JournalEntry, UnlearningMetrics, StrategyUpdate


class MemoryJournal:
    """
    Circular buffer of JournalEntry objects.

    Attributes:
        entries: Deque of journal entries (oldest → newest).
    """

    def __init__(self, max_entries: int = 500) -> None:
        self.max_entries = max_entries
        self.entries: Deque[JournalEntry] = deque(maxlen=max_entries)

    # ──────────────────────────────────────────────────────────────────────────

    def add(
        self,
        cycle:             int,
        metrics:           UnlearningMetrics,
        strategy_applied:  Optional[StrategyUpdate],
        score_weights:     Optional[Dict[str, float]] = None,
        failure_types:     Optional[List[str]]        = None,
        explanation:       str                        = "",
        composite_score:   Optional[float]             = None,
    ) -> JournalEntry:
        """
        Record one cycle.

        Args:
            composite_score: Pre-computed score for this cycle (see
                             ARCHITECTURE.md §16 — ExperienceEngine.process()
                             computes this once with whatever
                             target_forget_acc/retain_floor apply and
                             passes it through here). Falls back to
                             metrics.composite_score(score_weights) with no
                             target/floor if omitted, for backward
                             compatibility with any direct caller.
        """
        if composite_score is None:
            composite_score = metrics.composite_score(score_weights)
        entry = JournalEntry(
            cycle            = cycle,
            metrics          = metrics,
            strategy_applied = strategy_applied,
            composite_score  = composite_score,
            failure_types    = failure_types or [],
            explanation      = explanation,
        )
        self.entries.append(entry)
        return entry

    # ──────────────────────────────────────────────────────────────────────────
    # Query methods
    # ──────────────────────────────────────────────────────────────────────────

    def last_n(self, n: int) -> List[JournalEntry]:
        """Return the last n entries."""
        entries = list(self.entries)
        return entries[-n:]

    def by_cycle(self, cycle: int) -> Optional[JournalEntry]:
        """Return the entry for a specific cycle number."""
        for e in reversed(self.entries):
            if e.cycle == cycle:
                return e
        return None

    def by_strategy(self, action_name: str) -> List[JournalEntry]:
        """Return all entries where a specific strategy was applied."""
        return [
            e for e in self.entries
            if e.strategy_applied is not None
            and e.strategy_applied.action.value == action_name
        ]

    def score_trend(self, window: int = 10) -> List[float]:
        """Return composite scores for the last `window` entries."""
        return [e.composite_score for e in self.last_n(window)]

    def improving(self, window: int = 5) -> bool:
        """True if the average score is trending upward."""
        trend = self.score_trend(window)
        if len(trend) < 2:
            return False
        half = len(trend) // 2
        return sum(trend[half:]) / (len(trend) - half) > sum(trend[:half]) / half

    def strategy_outcomes(self) -> Dict[str, Dict[str, float]]:
        """
        Summarise outcomes per strategy action.

        Returns:
            {action_name: {"mean_score": float, "count": int, "success_rate": float}}
        """
        from collections import defaultdict
        acc: Dict[str, List[float]] = defaultdict(list)

        for entry in self.entries:
            if entry.strategy_applied is not None:
                action_name = entry.strategy_applied.action.value
                acc[action_name].append(entry.composite_score)

        results = {}
        # Compute overall mean score per action
        for action, scores in acc.items():
            results[action] = {
                "mean_score":   sum(scores) / len(scores),
                "count":        len(scores),
                "success_rate": sum(1 for s in scores if s >= 3.5) / len(scores),
            }
        return results

    def failure_frequency(self) -> Dict[str, int]:
        """Count how often each failure type appeared."""
        from collections import Counter
        counter: Counter = Counter()
        for e in self.entries:
            counter.update(e.failure_types)
        return dict(counter)

    def __len__(self) -> int:
        return len(self.entries)

    def __repr__(self) -> str:
        n = len(self.entries)
        last = f" last_score={self.entries[-1].composite_score:.3f}" if n else ""
        return f"MemoryJournal(entries={n}/{self.max_entries}{last})"
