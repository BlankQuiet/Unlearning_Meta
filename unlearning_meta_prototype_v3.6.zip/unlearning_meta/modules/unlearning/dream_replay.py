"""
modules/unlearning/dream_replay.py
====================================
Dream Replay

After gradient ascent, the model may "drift" and forget retain knowledge.
Dream Replay generates synthetic pseudo-samples from the retain distribution
using the model's own high-confidence predictions, then fine-tunes on them.

This mirrors biological "memory consolidation during sleep" — the model
replays what it confidently knows to reinforce retained knowledge.

Algorithm
---------
1. Pass retain samples through the current model.
2. Keep only samples with softmax confidence > threshold ("dreams").
3. Use model's predicted labels (not ground-truth) as pseudo-labels.
4. Fine-tune the model on (dream_sample, pseudo_label) pairs.
"""

from __future__ import annotations
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.utils.data import DataLoader, TensorDataset


class DreamReplayer:
    """
    Reinforces retained knowledge via model self-generated pseudo-samples.

    Attributes:
        dream_count:  Number of dream samples used in last replay.
    """

    def __init__(
        self,
        model:              nn.Module,
        replay_lr:          float = 0.001,
        replay_epochs:      int   = 3,
        confidence_thresh:  float = 0.85,
        strength:           float = 0.5,
        max_dream_samples:  int   = 2000,
        device:             str   = "cpu",
    ) -> None:
        self.model             = model
        self.replay_lr         = replay_lr
        self.replay_epochs     = replay_epochs
        self.confidence_thresh = confidence_thresh
        self.strength          = strength
        self.max_dream_samples = max_dream_samples
        self.device            = device
        self.dream_count       = 0

    # ──────────────────────────────────────────────────────────────────────────

    def run(self, retain_loader: DataLoader) -> dict:
        """
        Execute dream replay.

        Args:
            retain_loader: DataLoader for retained data (used to seed dreams).

        Returns:
            {"dream_count": int, "avg_loss": float}
        """
        dream_x, dream_y = self._collect_dreams(retain_loader)

        if dream_x is None or dream_x.size(0) == 0:
            return {"dream_count": 0, "avg_loss": 0.0}

        self.dream_count = dream_x.size(0)
        avg_loss = self._replay(dream_x, dream_y)

        return {"dream_count": self.dream_count, "avg_loss": avg_loss}

    # ──────────────────────────────────────────────────────────────────────────

    @torch.no_grad()
    def _collect_dreams(
        self, loader: DataLoader
    ) -> Tuple[Optional[Tensor], Optional[Tensor]]:
        """
        Collect high-confidence model predictions on retain data.

        Returns:
            (dream_inputs, pseudo_labels)  or  (None, None) if none collected
        """
        self.model.eval()
        self.model.to(self.device)

        dream_xs, dream_ys = [], []
        total = 0

        for x, _ in loader:                    # ignore true labels
            x = x.to(self.device)
            logits = self.model(x)
            probs  = F.softmax(logits, dim=-1)

            conf, pred = probs.max(dim=-1)
            keep = conf >= self.confidence_thresh

            if keep.any():
                dream_xs.append(x[keep].cpu())
                dream_ys.append(pred[keep].cpu())
                total += keep.sum().item()

            if total >= self.max_dream_samples:
                break

        if not dream_xs:
            return None, None

        dream_x = torch.cat(dream_xs, dim=0)[: self.max_dream_samples]
        dream_y = torch.cat(dream_ys, dim=0)[: self.max_dream_samples]
        return dream_x, dream_y

    def _replay(self, dream_x: Tensor, dream_y: Tensor) -> float:
        """Fine-tune model on dream samples to reinforce retained knowledge."""
        dream_x = dream_x.to(self.device)
        dream_y = dream_y.to(self.device)

        dataset = TensorDataset(dream_x, dream_y)
        loader  = DataLoader(dataset, batch_size=64, shuffle=True, drop_last=True)

        self.model.train()
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.replay_lr)
        criterion = nn.CrossEntropyLoss()

        total_loss = 0.0
        n_steps    = 0

        for _ in range(self.replay_epochs):
            for x_b, y_b in loader:
                if x_b.size(0) < 2:
                    # BatchNorm1d cannot compute batch statistics from a
                    # single sample in train() mode — skip this trailing
                    # mini-batch rather than crash. The dream-sample count
                    # is confidence-threshold-dependent, so it is not
                    # guaranteed to be divisible by the loader batch size.
                    continue
                x_b, y_b = x_b.to(self.device), y_b.to(self.device)
                optimizer.zero_grad()
                loss = criterion(self.model(x_b), y_b) * self.strength
                loss.backward()
                optimizer.step()
                total_loss += loss.item()
                n_steps    += 1

        return total_loss / max(n_steps, 1)
