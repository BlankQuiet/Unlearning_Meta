"""
modules/unlearning/fisher_information.py
=========================================
Fisher Information Matrix — diagonal approximation.

Used by:
  • EWC Consolidation  (penalise changes to important parameters)
  • Privacy analysis   (parameters with high Fisher are privacy-sensitive)

Algorithm (empirical Fisher)
-----------------------------
  F_ii = E[ (∂ log p(y|x; θ) / ∂θ_i)² ]
       ≈ (1/N) Σ_n (∂ ℓ(x_n, y_n) / ∂θ_i)²
"""

from __future__ import annotations
from typing import Dict, Optional

import torch
import torch.nn as nn
from torch import Tensor
from torch.utils.data import DataLoader


class FisherInformation:
    """
    Computes and stores the diagonal empirical Fisher Information Matrix.

    Attributes:
        fisher: Dict[param_name → diagonal Fisher tensor (same shape as param)]
    """

    def __init__(self, device: str = "cpu") -> None:
        self.device = device
        self.fisher: Dict[str, Tensor] = {}

    # ──────────────────────────────────────────────────────────────────────────

    def compute(
        self,
        model:       nn.Module,
        loader:      DataLoader,
        criterion:   Optional[nn.Module] = None,
        max_samples: int = 200,
    ) -> "FisherInformation":
        """
        Estimate diagonal Fisher on the given dataset.

        Args:
            model:       Model whose parameters are analysed.
            loader:      DataLoader (retain or full train set).
            criterion:   Loss function (default: cross-entropy).
            max_samples: Cap on samples for efficiency.

        Returns:
            self
        """
        if criterion is None:
            criterion = nn.CrossEntropyLoss()

        model.eval()
        model.to(self.device)

        # Initialise accumulator
        fisher: Dict[str, Tensor] = {}
        for name, param in model.named_parameters():
            if param.requires_grad:
                fisher[name] = torch.zeros_like(param.data)

        total = 0
        for x, y in loader:
            if total >= max_samples:
                break

            x, y = x.to(self.device), y.to(self.device)
            model.zero_grad()

            out  = model(x)
            loss = criterion(out, y)
            loss.backward()

            for name, param in model.named_parameters():
                if param.requires_grad and param.grad is not None:
                    fisher[name] += param.grad.data ** 2

            total += x.size(0)

        # Average
        for name in fisher:
            fisher[name] /= max(total, 1)

        self.fisher = fisher
        model.zero_grad()
        return self

    # ──────────────────────────────────────────────────────────────────────────

    def importance_mask(self, percentile: float = 0.9) -> Dict[str, Tensor]:
        """
        Return a boolean mask of the most important parameters.

        Args:
            percentile: Threshold — top (1-percentile) are marked important.

        Returns:
            Dict[param_name → bool mask]
        """
        masks: Dict[str, Tensor] = {}
        for name, f in self.fisher.items():
            thresh = torch.quantile(f.flatten(), percentile)
            masks[name] = f >= thresh
        return masks

    def mean_importance(self) -> float:
        """Mean Fisher value across all parameters."""
        total = count = 0.0
        for f in self.fisher.values():
            total += f.sum().item()
            count += f.numel()
        return total / max(count, 1.0)

    def privacy_risk_score(self) -> float:
        """
        High Fisher ↔ high sensitivity to data → higher privacy risk.
        Returns a normalised score in [0, 1].
        """
        mi = self.mean_importance()
        # Empirically calibrated; clamp to [0,1]
        return float(min(1.0, mi * 100))

    def state_dict(self) -> Dict[str, Tensor]:
        return {k: v.clone() for k, v in self.fisher.items()}

    def load_state_dict(self, state: Dict[str, Tensor]) -> None:
        self.fisher = {k: v.clone() for k, v in state.items()}
