"""
modules/unlearning/correction_replay.py
=========================================
Correction Replay

Uses actual retain data to correct accuracy degradation caused by
gradient ascent forgetting. Unlike Dream Replay (which uses pseudo-labels),
Correction Replay uses ground-truth labels for precision fine-tuning.

Strategy
--------
• Applied after gradient ascent and dream replay.
• Uses a low learning rate to gently correct without overwriting the forgetting.
• Can optionally weight updates by Fisher importance (protect critical params).
"""

from __future__ import annotations
from typing import Dict, Optional

import torch
import torch.nn as nn
from torch import Tensor
from torch.utils.data import DataLoader


class CorrectionReplayer:
    """
    Fine-tunes on real retain data to restore accuracy after forgetting.
    """

    def __init__(
        self,
        model:       nn.Module,
        lr:          float = 0.001,
        epochs:      int   = 5,
        strength:    float = 1.0,
        device:      str   = "cpu",
    ) -> None:
        self.model    = model
        self.lr       = lr
        self.epochs   = epochs
        self.strength = strength
        self.device   = device

        self.loss_history: list[float] = []

    # ──────────────────────────────────────────────────────────────────────────

    def run(
        self,
        retain_loader:   DataLoader,
        fisher:          Optional[Dict[str, Tensor]] = None,
        reference_model: Optional[nn.Module]         = None,
        ewc_lambda:      float                       = 400.0,
    ) -> dict:
        """
        Execute correction replay.

        Args:
            retain_loader:   DataLoader with (x, true_y) pairs.
            fisher:          Optional Fisher for EWC regularisation.
            reference_model: Reference weights for EWC.
            ewc_lambda:      EWC strength.

        Returns:
            {"avg_loss": float, "epochs_run": int}
        """
        self.model.train()
        self.model.to(self.device)

        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        criterion = nn.CrossEntropyLoss()

        ref_params: Dict[str, Tensor] = {}
        if fisher is not None and reference_model is not None:
            for n, p in reference_model.named_parameters():
                ref_params[n] = p.data.clone().detach()

        total_loss = 0.0
        n_steps    = 0

        for epoch in range(self.epochs):
            for x, y in retain_loader:
                if x.size(0) < 2:
                    # See GradientAscentForgetter for rationale: BatchNorm1d
                    # requires ≥2 samples per batch in train() mode.
                    continue
                x, y = x.to(self.device), y.to(self.device)

                optimizer.zero_grad()
                logits = self.model(x)

                loss = criterion(logits, y) * self.strength

                # Optional EWC to prevent over-correction
                if fisher is not None and ref_params:
                    ewc = self._ewc_penalty(fisher, ref_params)
                    loss = loss + ewc_lambda * 0.1 * ewc  # lighter penalty here

                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                optimizer.step()

                total_loss += loss.item()
                n_steps    += 1

        avg_loss = total_loss / max(n_steps, 1)
        self.loss_history.append(avg_loss)
        return {"avg_loss": avg_loss, "epochs_run": self.epochs}

    # ──────────────────────────────────────────────────────────────────────────

    def _ewc_penalty(
        self,
        fisher:     Dict[str, Tensor],
        ref_params: Dict[str, Tensor],
    ) -> Tensor:
        penalty = torch.tensor(0.0, device=self.device)
        for name, param in self.model.named_parameters():
            if name in fisher and name in ref_params:
                f = fisher[name].to(self.device)
                r = ref_params[name].to(self.device)
                penalty = penalty + (f * (param - r) ** 2).sum()
        return penalty
