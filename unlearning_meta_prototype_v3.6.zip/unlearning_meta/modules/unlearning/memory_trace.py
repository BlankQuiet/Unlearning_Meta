"""
modules/unlearning/memory_trace.py
===================================
Memory Trace Mapping

Maps which neurons (per layer) are most strongly associated with
the forget set, and which are critical for the retain set.

Algorithm
---------
1. Compute mean activation magnitude on forget set  (F_act)
2. Compute mean activation magnitude on retain set  (R_act)
3. Selectivity score  S = F_act / (F_act + R_act + ε)
4. Top-k neurons with highest S form the "forget trace"
5. Neurons critical for retain are flagged for EWC protection
"""

from __future__ import annotations
from typing import Dict

import torch
from torch import Tensor
from torch.utils.data import DataLoader


class MemoryTraceMapper:
    """
    Computes per-layer neuron selectivity scores for forget vs retain data.

    After calling ``compute()``, the following attributes are available:

    Attributes:
        forget_activations:  Dict[layer_name → mean activation magnitudes]
        retain_activations:  Dict[layer_name → mean activation magnitudes]
        selectivity:         Dict[layer_name → selectivity scores]
        forget_mask:         Dict[layer_name → bool mask of forget-critical neurons]
        retain_mask:         Dict[layer_name → bool mask of retain-critical neurons]
    """

    def __init__(self, top_k: int = 50, device: str = "cpu") -> None:
        self.top_k  = top_k
        self.device = device

        self.forget_activations: Dict[str, Tensor] = {}
        self.retain_activations: Dict[str, Tensor] = {}
        self.selectivity:        Dict[str, Tensor] = {}
        self.forget_mask:        Dict[str, Tensor] = {}
        self.retain_mask:        Dict[str, Tensor] = {}

    # ──────────────────────────────────────────────────────────────────────────

    @torch.no_grad()
    def compute(
        self,
        model:          torch.nn.Module,
        forget_loader:  DataLoader,
        retain_loader:  DataLoader,
        max_samples:    int = 500,
    ) -> "MemoryTraceMapper":
        """
        Run the memory trace computation.

        Args:
            model:          The current model (must expose ``get_activations``).
            forget_loader:  DataLoader for the forget set.
            retain_loader:  DataLoader for the retain set.
            max_samples:    Cap on samples used for efficiency.

        Returns:
            self (for chaining)
        """
        model.eval()
        model.to(self.device)

        f_acts = self._accumulate_activations(model, forget_loader, max_samples)
        r_acts = self._accumulate_activations(model, retain_loader, max_samples)

        self.forget_activations = f_acts
        self.retain_activations = r_acts

        for layer in f_acts:
            f = f_acts[layer]
            r = r_acts.get(layer, torch.zeros_like(f))

            eps = 1e-8
            sel = f / (f + r + eps)
            self.selectivity[layer] = sel

            k = min(self.top_k, sel.numel())
            top_idx = sel.topk(k).indices

            f_mask = torch.zeros(sel.numel(), dtype=torch.bool, device=self.device)
            f_mask[top_idx] = True
            self.forget_mask[layer] = f_mask

            # Retain-critical: neurons *not* in forget trace that are highly active
            retain_top_idx = r.topk(k).indices
            r_mask = torch.zeros(sel.numel(), dtype=torch.bool, device=self.device)
            r_mask[retain_top_idx] = True
            r_mask[f_mask] = False   # don't double-count
            self.retain_mask[layer] = r_mask

        return self

    # ──────────────────────────────────────────────────────────────────────────

    @torch.no_grad()
    def _accumulate_activations(
        self,
        model:      torch.nn.Module,
        loader:     DataLoader,
        max_samples: int,
    ) -> Dict[str, Tensor]:
        """Return mean absolute activation per neuron per layer."""
        sums:   Dict[str, Tensor] = {}
        counts: Dict[str, int]    = {}
        total = 0

        for x, _ in loader:
            if total >= max_samples:
                break
            x = x.to(self.device)
            acts = model.get_activations(x)   # Dict[str, Tensor[B, H]]

            for layer, act in acts.items():
                # Skip logit layer (not a "neuron" in the usual sense)
                if layer == "output":
                    continue
                mag = act.abs().mean(dim=0)    # [H]
                if layer not in sums:
                    sums[layer]   = torch.zeros_like(mag)
                    counts[layer] = 0
                sums[layer]   += mag
                counts[layer] += 1

            total += x.size(0)

        return {
            layer: sums[layer] / max(counts[layer], 1)
            for layer in sums
        }

    # ──────────────────────────────────────────────────────────────────────────

    def overlap_score(self) -> float:
        """
        Fraction of forget-trace neurons that also appear in the retain trace.
        Low overlap → clean separation of memory traces (good).
        """
        total_forget = total_overlap = 0
        for layer in self.forget_mask:
            fm = self.forget_mask[layer]
            rm = self.retain_mask.get(layer, torch.zeros_like(fm))
            total_forget  += fm.sum().item()
            total_overlap += (fm & rm).sum().item()
        if total_forget == 0:
            return 0.0
        return total_overlap / total_forget

    def summary(self) -> str:
        lines = [f"MemoryTrace (top_k={self.top_k}):"]
        for layer in self.selectivity:
            sel = self.selectivity[layer]
            f_n = self.forget_mask[layer].sum().item()
            r_n = self.retain_mask.get(layer, torch.zeros(1)).sum().item()
            lines.append(
                f"  {layer}: selectivity_mean={sel.mean():.3f}  "
                f"forget_neurons={f_n}  retain_neurons={r_n}"
            )
        lines.append(f"  overlap_score = {self.overlap_score():.3f}")
        return "\n".join(lines)

    def to_parameter_weights(self, model: "torch.nn.Module") -> Dict[str, "torch.Tensor"]:
        """
        Convert per-neuron selectivity into a per-PARAMETER noise-scaling
        map matching model.named_parameters() exactly.

        Values are the raw continuous selectivity score (~1.0 for
        forget-specific neurons, ~0.0 for retain-critical), NOT the
        binarised top-k masks — the selectivity is a noisy sample-based
        estimate, treating it as a hard binary gate would over-commit to
        that estimate. Parameters not covered by self.selectivity
        (output_layer, which get_activations() explicitly excludes)
        default to 1.0 — neutral, identical to the prior uniform-noise
        behavior.

        This closes the gap identified during external review: selectivity
        was computed but never connected to actual weight perturbation.
        """
        weights: Dict[str, "torch.Tensor"] = {}
        for name, param in model.named_parameters():
            weights[name] = torch.ones_like(param.data)

        for layer_key, sel in self.selectivity.items():
            idx = layer_key.split("_")[-1]
            for suffix in (f"linears.{idx}.weight", f"linears.{idx}.bias",
                          f"bns.{idx}.weight", f"bns.{idx}.bias"):
                if suffix not in weights:
                    continue
                target_shape = weights[suffix].shape
                if len(target_shape) == 2:
                    weights[suffix] = sel.unsqueeze(1).expand(target_shape).clone()
                else:
                    weights[suffix] = sel.clone()

        return weights

    def to_ascent_weights(
        self, model: "torch.nn.Module",
        alpha: float = 1.0, beta: float = 0.5,
    ) -> Dict[str, "torch.Tensor"]:
        """
        Convert per-neuron selectivity into a per-PARAMETER gradient-
        scaling map for use during gradient ascent itself (IDEAS.md
        Idea 3), matching model.named_parameters() exactly. Distinct
        from to_parameter_weights() (used for noise injection, §20/§21)
        in two ways:

        1. Different neutral value. For noise injection, weight=1.0 IS
           the no-op value (noise * 1.0 = unchanged), so uncovered
           layers (output_layer) default to 1.0 correctly. Here the
           transform is `alpha * s + beta`, so 1.0 selectivity is NOT
           generally neutral (e.g. the defaults below make s=0.5
           neutral, not s=1.0) — passing an uncovered layer through
           alpha*1.0+beta would silently and always amplify a layer
           this class has no actual activation data for. Uncovered
           parameters instead get an explicit multiplier of 1.0 (no
           scaling at all), matching how they're already treated as
           "no information available" elsewhere in this class.

        2. Normalized before scaling. Measured directly on this
           project's model/data (3 seeds, instance-level forgetting):
           raw selectivity is tightly clustered around 0.5 (mean~0.50,
           std~0.03, full range roughly [0.39, 0.59]) — expected, since
           forget and retain are different SAMPLES of the same classes
           here, not different classes, so forget-set and retain-set
           activation patterns are naturally similar for most neurons.
           Feeding that raw ~0.2-wide range through alpha=1, beta=0.5
           would only ever produce multipliers in roughly [0.89, 1.09]
           — too narrow to be a fair test of whether selective ascent
           does anything at all, and liable to reproduce §21's null
           result for the trivial reason that the input signal barely
           varies, not because the mechanism doesn't work. To give the
           mechanism a real signal to act on, selectivity is min-max
           normalized to [0, 1] across all covered neurons *before*
           alpha/beta are applied, so alpha/beta's effect size is
           decoupled from how compressed the raw selectivity happens to
           be for a given seed or task.

        Args:
            model: current model (for named_parameters() shape matching).
            alpha: scales how much (normalized) selectivity matters.
            beta:  floor multiplier at normalized-s=0 (keeps
                   low-selectivity parameters from being fully frozen
                   out of ascent rather than merely suppressed).

        Returns:
            Dict[param_name -> Tensor of per-element gradient multipliers].
        """
        multipliers: Dict[str, "torch.Tensor"] = {}
        for name, param in model.named_parameters():
            multipliers[name] = torch.ones_like(param.data)  # neutral default

        if not self.selectivity:
            return multipliers

        all_sel = torch.cat([s.flatten() for s in self.selectivity.values()])
        s_min, s_max = all_sel.min(), all_sel.max()
        spread = (s_max - s_min).item()

        for layer_key, sel in self.selectivity.items():
            if spread < 1e-6:
                # Degenerate case: selectivity essentially constant across
                # every covered neuron for this run. No real signal to
                # normalize against — treat every covered neuron as
                # exactly neutral (normalized midpoint) rather than
                # dividing by a near-zero spread and amplifying noise.
                sel_norm = torch.full_like(sel, 0.5)
            else:
                sel_norm = (sel - s_min) / spread
            scaled = alpha * sel_norm + beta

            idx = layer_key.split("_")[-1]
            for suffix in (f"linears.{idx}.weight", f"linears.{idx}.bias",
                          f"bns.{idx}.weight", f"bns.{idx}.bias"):
                if suffix not in multipliers:
                    continue
                target_shape = multipliers[suffix].shape
                if len(target_shape) == 2:
                    multipliers[suffix] = scaled.unsqueeze(1).expand(target_shape).clone()
                else:
                    multipliers[suffix] = scaled.clone()

        return multipliers

    def _mean_rescale(self, sel: "torch.Tensor", target_mean: float,
                      min_mean_floor: float = 1e-4) -> "torch.Tensor":
        """
        Rescale sel proportionally so its OWN mean lands exactly at
        target_mean, preserving relative differences between elements
        (a multiplicative, not additive, rescaling — sel=0 stays 0).

        Shared by both mean-normalized methods below (IDEAS.md Idea 10):
        neither to_parameter_weights() (raw) nor to_ascent_weights()
        (min-max) fixes the AGGREGATE mean of a skewed distribution — a
        linear rescaling by range preserves skew exactly, which is what
        ARCHITECTURE.md §27.2 found left selective ascent's own
        min-max-normalized aggregate multiplier at ~0.83, not the
        intended 1.0, on class-level's heavily right-skewed selectivity
        (§25.2). Mean-rescaling instead guarantees mean(output)=target_mean
        by construction, for any distribution shape.

        Args:
            sel: raw selectivity for one layer.
            target_mean: the mean the OUTPUT must have.
            min_mean_floor: safety floor for sel's own mean, to avoid an
                explosive scale factor if a layer's selectivity happens
                to average out near zero (e.g. a degenerate/dead layer).
        """
        current_mean = sel.mean().item()
        if current_mean < min_mean_floor:
            return torch.full_like(sel, target_mean)
        return sel * (target_mean / current_mean)

    def to_parameter_weights_mean_normalized(
        self, model: "torch.nn.Module",
    ) -> Dict[str, "torch.Tensor"]:
        """
        Mean-normalized alternative to to_parameter_weights() (IDEAS.md
        Idea 10): rescales each layer's selectivity so its OWN mean is
        exactly 1.0 (the neutral value for noise's multiplicative form,
        noise * weight) before use, rather than passing raw selectivity
        straight through. ARCHITECTURE.md §26.4 found raw selectivity's
        mean on class-level forgetting is only ~0.30 (vs. instance-
        level's ~0.50), so under a noise_scale calibrated assuming
        roughly-uniform application, raw selective noise's AGGREGATE
        strength is diluted to ~0.30x there — a plausible cause of §26's
        confirmed harmful effect. This method targets that specific gap:
        relative differences between neurons are preserved (still
        differentiates high/low selectivity), but the aggregate strength
        is pinned to uniform-equivalent regardless of the task's raw
        selectivity distribution.

        Uncovered layers (output_layer) get an explicit, unscaled 1.0,
        identical to to_parameter_weights() — this method changes how
        COVERED layers are weighted, not which layers are covered.
        """
        weights: Dict[str, "torch.Tensor"] = {}
        for name, param in model.named_parameters():
            weights[name] = torch.ones_like(param.data)

        for layer_key, sel in self.selectivity.items():
            rescaled = self._mean_rescale(sel, target_mean=1.0)
            idx = layer_key.split("_")[-1]
            for suffix in (f"linears.{idx}.weight", f"linears.{idx}.bias",
                          f"bns.{idx}.weight", f"bns.{idx}.bias"):
                if suffix not in weights:
                    continue
                target_shape = weights[suffix].shape
                if len(target_shape) == 2:
                    weights[suffix] = rescaled.unsqueeze(1).expand(target_shape).clone()
                else:
                    weights[suffix] = rescaled.clone()

        return weights

    def to_ascent_weights_mean_normalized(
        self, model: "torch.nn.Module",
        alpha: float = 1.0, beta: float = 0.5,
    ) -> Dict[str, "torch.Tensor"]:
        """
        Mean-normalized alternative to to_ascent_weights() (IDEAS.md
        Idea 10): same alpha*s+beta formula and same alpha/beta defaults
        (unchanged from §24.1, so this remains a test of the same
        mechanism, not a retuned one), but rescales selectivity so its
        OWN mean lands at the formula's neutral point (s=0.5, since
        alpha*0.5+beta=1.0 with the defaults) before applying alpha/beta —
        rather than to_ascent_weights()'s min-max-to-[0,1], which fixes
        the range but not the skew. ARCHITECTURE.md §27.2 measured
        to_ascent_weights()'s resulting aggregate multiplier at ~0.83 on
        class-level forgetting, not the intended neutral 1.0, because
        min-max rescaling preserves the underlying distribution's skew
        exactly. This method targets that gap directly: mean(output
        multiplier) = alpha*0.5+beta by construction, for any
        distribution shape.

        Uncovered layers (output_layer) get an explicit, unscaled 1.0 —
        identical rationale to to_ascent_weights()'s own handling of
        this case (see that method's docstring).
        """
        multipliers: Dict[str, "torch.Tensor"] = {}
        for name, param in model.named_parameters():
            multipliers[name] = torch.ones_like(param.data)

        for layer_key, sel in self.selectivity.items():
            sel_rescaled = self._mean_rescale(sel, target_mean=0.5)
            scaled = alpha * sel_rescaled + beta
            idx = layer_key.split("_")[-1]
            for suffix in (f"linears.{idx}.weight", f"linears.{idx}.bias",
                          f"bns.{idx}.weight", f"bns.{idx}.bias"):
                if suffix not in multipliers:
                    continue
                target_shape = multipliers[suffix].shape
                if len(target_shape) == 2:
                    multipliers[suffix] = scaled.unsqueeze(1).expand(target_shape).clone()
                else:
                    multipliers[suffix] = scaled.clone()

        return multipliers
