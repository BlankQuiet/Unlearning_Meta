"""
modules/unlearning/gradient_ascent.py
======================================
Gradient Ascent Forgetting

Core unlearning mechanism: maximise the loss on the forget set
(gradient ascent) so the model "unlearns" the forgotten examples.

Optionally integrates:
  • EWC penalty  (preserve retain-important parameters)
  • Noise injection  (additional randomisation of forget-trace neurons)
  • Memory-trace-based parameter masking
"""

from __future__ import annotations
from typing import Dict, Optional

import torch
import torch.nn as nn
from torch import Tensor
from torch.utils.data import DataLoader


class GradientAscentForgetter:
    """
    Implements gradient-ascent-based unlearning.

    Usage::

        forgetter = GradientAscentForgetter(
            model, forget_lr=0.01, strength=1.2, max_epochs=5
        )
        forgetter.run(forget_loader, fisher=fisher_info)
    """

    def __init__(
        self,
        model:      nn.Module,
        forget_lr:  float = 0.01,
        strength:   float = 1.0,    # multiplier on ascent loss
        max_epochs: int   = 5,
        max_grad_norm: float = 1.0,
        noise_scale: float = 0.005,
        device: str = "cpu",
    ) -> None:
        self.model         = model
        self.forget_lr     = forget_lr
        self.strength      = strength
        self.max_epochs    = max_epochs
        self.max_grad_norm = max_grad_norm
        self.noise_scale   = noise_scale
        self.device        = device

        self.loss_history: list[float] = []

    # ──────────────────────────────────────────────────────────────────────────

    def run(
        self,
        forget_loader:       DataLoader,
        ewc_fisher:          Optional[Dict[str, Tensor]] = None,
        ewc_reference:       Optional[nn.Module]         = None,
        ewc_lambda:          float                       = 400.0,
        selectivity_weights: Optional[Dict[str, Tensor]] = None,
        ascent_weights:      Optional[Dict[str, Tensor]] = None,
    ) -> Dict[str, float]:
        """
        Execute gradient ascent forgetting.

        Args:
            forget_loader:       DataLoader for forget set.
            ewc_fisher:          Diagonal Fisher (if EWC is enabled).
            ewc_reference:       Reference model for EWC penalty.
            ewc_lambda:          EWC regularisation strength.
            selectivity_weights: Optional per-parameter noise-scaling map
                from MemoryTraceMapper.to_parameter_weights(). None
                preserves exact original uniform-noise behavior.
            ascent_weights:      Optional per-parameter GRADIENT-scaling
                map from MemoryTraceMapper.to_ascent_weights() (IDEAS.md
                Idea 3). None (default) preserves exact original
                behavior — every gradient is used as computed, with no
                selectivity-based scaling of the ascent step itself.
                Distinct from selectivity_weights above: that scales
                the post-ascent NOISE injection (§20/§21); this scales
                the ASCENT GRADIENT itself, before optimizer.step().

        Returns:
            {"avg_forget_loss": float, "epochs_run": int}
        """
        self.model.train()
        self.model.to(self.device)

        optimizer = torch.optim.SGD(
            self.model.parameters(), lr=self.forget_lr, momentum=0.9
        )
        criterion = nn.CrossEntropyLoss()

        # Snapshot reference params for EWC
        ref_params: Dict[str, Tensor] = {}
        if ewc_fisher is not None and ewc_reference is not None:
            for name, param in ewc_reference.named_parameters():
                ref_params[name] = param.data.clone().detach()

        total_loss = 0.0
        n_steps = 0

        for epoch in range(self.max_epochs):
            for x, y in forget_loader:
                if x.size(0) < 2:
                    # Skip trailing mini-batches of size 1 — BatchNorm1d
                    # cannot compute variance from a single sample in
                    # train() mode. forget_loader's final batch size
                    # depends on dataset size % batch_size and is not
                    # otherwise guaranteed to be ≥ 2.
                    continue
                x, y = x.to(self.device), y.to(self.device)

                optimizer.zero_grad()
                logits = self.model(x)

                # ── Gradient ascent: maximise forget loss ──────────────────
                forget_loss = criterion(logits, y)
                loss = -self.strength * forget_loss   # negate → ascent

                # ── EWC penalty: preserve retain-important weights ─────────
                if ewc_fisher is not None and ref_params:
                    ewc_loss = self._ewc_penalty(ewc_fisher, ref_params)
                    loss = loss + ewc_lambda * ewc_loss

                loss.backward()

                # ── Selective Gradient Ascent (IDEAS.md Idea 3) ─────────────
                # Scale AFTER backward() (so it acts on the real computed
                # gradient, including any EWC contribution) and BEFORE
                # clip_grad_norm_ (which rescales the whole gradient
                # vector by one global scalar if it exceeds max_grad_norm
                # — applying selective scaling first means clipping
                # preserves the RELATIVE per-parameter differences this
                # mechanism introduces, only capping the overall scale).
                if ascent_weights is not None:
                    self._scale_ascent_gradients(ascent_weights)

                torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(), self.max_grad_norm
                )
                optimizer.step()

                total_loss += forget_loss.item()
                n_steps    += 1

        # ── Noise injection after ascent ────────────────────────────────────
        if self.noise_scale > 0.0:
            self._inject_noise(selectivity_weights)

        avg_loss = total_loss / max(n_steps, 1)
        self.loss_history.append(avg_loss)

        return {"avg_forget_loss": avg_loss, "epochs_run": self.max_epochs}

    # ──────────────────────────────────────────────────────────────────────────

    def _ewc_penalty(
        self,
        fisher:     Dict[str, Tensor],
        ref_params: Dict[str, Tensor],
    ) -> Tensor:
        """Compute EWC penalty: Σ F_i · (θ_i - θ_i*)²"""
        penalty = torch.tensor(0.0, device=self.device)
        for name, param in self.model.named_parameters():
            if name in fisher and name in ref_params:
                f = fisher[name].to(self.device)
                r = ref_params[name].to(self.device)
                penalty = penalty + (f * (param - r) ** 2).sum()
        return penalty

    def _scale_ascent_gradients(self, ascent_weights: Dict[str, Tensor]) -> None:
        """
        Multiply each parameter's gradient in-place by its ascent weight
        (IDEAS.md Idea 3). Called after loss.backward() populates
        param.grad, before clip_grad_norm_/optimizer.step(). Parameters
        with no gradient (e.g. frozen, or not touched by this loss) are
        skipped, not errored on.
        """
        with torch.no_grad():
            for name, param in self.model.named_parameters():
                if param.grad is None:
                    continue
                weight = ascent_weights.get(name)
                if weight is None:
                    continue
                param.grad.mul_(weight.to(param.grad.device))

    def _inject_noise(
        self, selectivity_weights: Optional[Dict[str, Tensor]] = None,
    ) -> None:
        """
        Add Gaussian noise, optionally weighted by selectivity.

        When selectivity_weights is None (default), behavior is identical
        to the original uniform-noise implementation. When provided, each
        parameter's noise is scaled by the corresponding selectivity weight
        (~1.0 for forget-specific, ~0.0 for retain-critical), connecting
        MemoryTraceMapper's analysis to actual weight perturbation.
        """
        with torch.no_grad():
            if selectivity_weights is None:
                for param in self.model.parameters():
                    param.data.add_(
                        torch.randn_like(param.data) * self.noise_scale
                    )
            else:
                for name, param in self.model.named_parameters():
                    weight = selectivity_weights.get(name)
                    noise = torch.randn_like(param.data) * self.noise_scale
                    if weight is not None:
                        noise = noise * weight.to(param.device)
                    param.data.add_(noise)
