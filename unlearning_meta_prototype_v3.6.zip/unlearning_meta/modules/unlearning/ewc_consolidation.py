"""
modules/unlearning/ewc_consolidation.py
=========================================
Elastic Weight Consolidation (EWC) Consolidation

Adds an EWC regularisation loss that penalises changes to parameters
that are important for the retain set (as measured by Fisher Information).

EWC Loss
---------
  L_EWC(θ) = λ/2 · Σ_i  F_i · (θ_i - θ_i*)²

where:
  θ_i   = current parameter
  θ_i*  = reference parameter (snapshot taken on retain set)
  F_i   = diagonal Fisher coefficient (importance)
  λ     = regularisation strength (ewc_lambda)
"""

from __future__ import annotations
from typing import Dict

import torch
import torch.nn as nn
from torch import Tensor


class EWCConsolidation:
    """
    Stores EWC state and computes the regularisation loss.

    Typical workflow::

        ewc = EWCConsolidation(model, ewc_lambda=400)
        ewc.register(fisher.fisher)   # after computing Fisher on retain set
        # ... during any training loop:
        loss = task_loss + ewc.penalty(model)
    """

    def __init__(
        self,
        reference_model: nn.Module,
        ewc_lambda:      float = 400.0,
        device:          str   = "cpu",
    ) -> None:
        self.ewc_lambda = ewc_lambda
        self.device     = device

        # Snapshot reference parameters
        self.reference: Dict[str, Tensor] = {}
        for name, param in reference_model.named_parameters():
            self.reference[name] = param.data.clone().detach().to(device)

        self.fisher: Dict[str, Tensor] = {}

    # ──────────────────────────────────────────────────────────────────────────

    def register(self, fisher: Dict[str, Tensor]) -> None:
        """
        Store the Fisher Information matrix.

        Args:
            fisher: Dict[param_name → diagonal Fisher tensor]
        """
        self.fisher = {k: v.clone().to(self.device) for k, v in fisher.items()}

    def penalty(self, model: nn.Module) -> Tensor:
        """
        Compute EWC penalty for the current model.

        Args:
            model: Current (partially updated) model.

        Returns:
            Scalar EWC penalty term.
        """
        if not self.fisher:
            return torch.tensor(0.0, device=self.device)

        loss = torch.tensor(0.0, device=self.device)
        for name, param in model.named_parameters():
            if name in self.fisher and name in self.reference:
                f = self.fisher[name]
                r = self.reference[name]
                loss = loss + (f * (param - r) ** 2).sum()

        return (self.ewc_lambda / 2.0) * loss

    def update_reference(self, model: nn.Module) -> None:
        """Update the reference snapshot (call after full unlearning cycle)."""
        for name, param in model.named_parameters():
            self.reference[name] = param.data.clone().detach().to(self.device)

    def importance_weighted_distance(self, model: nn.Module) -> float:
        """
        Fisher-weighted L2 distance from reference.
        Measures how much important parameters have changed.
        """
        if not self.fisher:
            return 0.0
        total = 0.0
        for name, param in model.named_parameters():
            if name in self.fisher and name in self.reference:
                f = self.fisher[name]
                r = self.reference[name]
                total += (f * (param.data - r) ** 2).sum().item()
        return float(total) ** 0.5
