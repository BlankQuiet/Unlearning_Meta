"""
modules/unlearning/evaluator.py
=================================
Unlearning Evaluation

Computes all six metrics required by the system:

  forget_acc      — model accuracy on the forget set (↓ better)
  retain_acc      — model accuracy on the retain set (↑ better)
  accuracy        — overall test accuracy             (↑ better)
  privacy         — MIA-based privacy score           (↑ better)
  hallucination   — confident-wrong prediction rate   (↓ better)
  stability       — param distance from pre-unlearn checkpoint (↑ better
                    when calibrated; 1 − normalised Δθ)
"""

from __future__ import annotations
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.utils.data import DataLoader

from unlearning_meta.schemas import UnlearningMetrics


class UnlearningEvaluator:
    """Computes all six unlearning metrics in a single pass."""

    def __init__(
        self,
        model:          nn.Module,
        device:         str = "cpu",
        batch_size:     int = 256,
        halluc_thresh:  float = 0.90,   # confidence > this = "hallucination"
    ) -> None:
        self.model         = model
        self.device        = device
        self.batch_size    = batch_size
        self.halluc_thresh = halluc_thresh

    # ──────────────────────────────────────────────────────────────────────────

    @torch.no_grad()
    def evaluate(
        self,
        forget_loader:     DataLoader,
        retain_loader:     DataLoader,
        test_loader:       DataLoader,
        reference_model:   Optional[nn.Module] = None,
        cycle:             int = 0,
    ) -> UnlearningMetrics:
        """
        Run full evaluation.

        Args:
            forget_loader:   DataLoader for forget set.
            retain_loader:   DataLoader for retain/validation set.
            test_loader:     DataLoader for held-out test set.
            reference_model: Pre-unlearning snapshot for stability.
            cycle:           Current training cycle number.

        Returns:
            UnlearningMetrics dataclass.
        """
        self.model.eval()
        self.model.to(self.device)

        forget_acc   = self._accuracy(forget_loader)
        retain_acc   = self._accuracy(retain_loader)
        accuracy     = self._accuracy(test_loader)
        hallucination = self._hallucination_rate(test_loader)
        privacy      = self._mia_privacy_score(forget_loader, test_loader)
        stability    = self._stability_score(reference_model)

        return UnlearningMetrics(
            forget_acc    = forget_acc,
            retain_acc    = retain_acc,
            accuracy      = accuracy,
            privacy       = privacy,
            hallucination = hallucination,
            stability     = stability,
            cycle         = cycle,
        )

    # ──────────────────────────────────────────────────────────────────────────
    # Individual metric methods
    # ──────────────────────────────────────────────────────────────────────────

    def _accuracy(self, loader: DataLoader) -> float:
        correct = total = 0
        for x, y in loader:
            x, y = x.to(self.device), y.to(self.device)
            logits = self.model(x)
            correct += (logits.argmax(dim=-1) == y).sum().item()
            total   += y.size(0)
        return correct / max(total, 1)

    def _hallucination_rate(self, loader: DataLoader) -> float:
        """Fraction of wrong predictions made with high confidence."""
        high_conf_wrong = total_wrong = 0
        for x, y in loader:
            x, y = x.to(self.device), y.to(self.device)
            probs  = F.softmax(self.model(x), dim=-1)
            conf, pred = probs.max(dim=-1)
            wrong_mask = pred != y
            total_wrong      += wrong_mask.sum().item()
            high_conf_wrong  += (wrong_mask & (conf > self.halluc_thresh)).sum().item()
        if total_wrong == 0:
            return 0.0
        return high_conf_wrong / max(total_wrong, 1)

    @torch.no_grad()
    def _mia_privacy_score(
        self,
        forget_loader: DataLoader,
        test_loader:   DataLoader,
        max_samples:   int = 500,
    ) -> float:
        """
        Confidence-based Membership Inference Attack (MIA) privacy score.

        Intuition: After unlearning, the model's confidence on forget samples
        should be *indistinguishable* from its confidence on unseen test samples.
        AUC of the MIA classifier = 0.5 → perfect forgetting (privacy = 1.0).

        Returns:
            Privacy score in [0, 1].  Higher is better.
        """
        def collect_confs(loader: DataLoader, n: int) -> Tensor:
            confs = []
            total = 0
            for x, _ in loader:
                x = x.to(self.device)
                probs = F.softmax(self.model(x), dim=-1)
                confs.append(probs.max(dim=-1).values.cpu())
                total += x.size(0)
                if total >= n:
                    break
            if not confs:
                return torch.zeros(1)
            return torch.cat(confs, dim=0)[:n]

        n = min(max_samples, 500)
        forget_conf = collect_confs(forget_loader, n)
        test_conf   = collect_confs(test_loader,   n)

        # Simple threshold-based AUC approximation
        all_confs  = torch.cat([forget_conf, test_conf], dim=0).numpy()
        all_labels = torch.cat([
            torch.ones(len(forget_conf)),
            torch.zeros(len(test_conf))
        ], dim=0).numpy()

        try:
            from sklearn.metrics import roc_auc_score
            auc = roc_auc_score(all_labels, all_confs)
        except Exception:
            # Fallback: mean confidence distance
            auc = 0.5 + abs(forget_conf.mean().item() - test_conf.mean().item()) * 0.5

        # Perfect forgetting → AUC = 0.5; perfect membership → AUC = 1.0
        # Privacy score: closer to 0.5 = better
        privacy = 1.0 - 2.0 * abs(auc - 0.5)
        return float(max(0.0, min(1.0, privacy)))

    def _stability_score(
        self, reference_model: Optional[nn.Module]
    ) -> float:
        """
        Stability = 1 − normalised parameter distance from reference.
        Range [0, 1]; 1.0 = no change (perfect stability).
        """
        if reference_model is None:
            return 1.0

        total_change = total_norm = 0.0
        for (_, p_cur), (_, p_ref) in zip(
            self.model.named_parameters(),
            reference_model.named_parameters(),
        ):
            total_change += (p_cur.data - p_ref.data).norm(2).item() ** 2
            total_norm   += p_ref.data.norm(2).item() ** 2

        if total_norm < 1e-8:
            return 1.0

        rel_change = (total_change ** 0.5) / (total_norm ** 0.5)
        return float(max(0.0, 1.0 - rel_change))
