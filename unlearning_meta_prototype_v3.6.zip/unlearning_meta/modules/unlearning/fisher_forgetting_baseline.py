"""
modules/unlearning/fisher_forgetting_baseline.py
====================================================
Fisher Forgetting — a literature baseline (Golatkar, Achille & Soatto,
"Eternal Sunshine of the Spotless Net: Selective Forgetting in Deep
Networks", CVPR 2020), implemented for comparison against this project's
dual-engine system. Flagged as a needed comparison since external review
round 2 (§9's related-work table already cites this paper) but never
actually implemented until now — see ARCHITECTURE.md §19.

Algorithm (simplified single-shot scrubbing)
-----------------------------------------------
Unlike this project's iterative, multi-cycle dual-engine approach, Fisher
Forgetting is fundamentally a ONE-SHOT procedure:

  1. Compute the diagonal Fisher Information Matrix F on the RETAIN set.
  2. Perturb every parameter with noise scaled INVERSELY to its Fisher
     information:
         theta_scrubbed = theta + (noise_scale / sqrt(F + eps)) * N(0, 1)
     Parameters important for the retain set (high F) are protected
     (small effective noise); parameters not important for retain
     knowledge (low F — plausibly including forget-set-specific
     information) are scrambled more freely.
  3. No gradient ascent, no replay, no iteration — this is a single
     scrub-and-done operation, run once.

This is a deliberately faithful-but-simplified implementation (the
original paper's full NTK-based treatment is more involved); it captures
the core mechanism — Fisher-inverse-weighted noise — that distinguishes
this baseline's approach from both naive uniform noise injection (this
project's GradientAscentForgetter) and doing nothing adaptive (§17's
condition A).
"""

from __future__ import annotations
import copy

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from unlearning_meta.modules.unlearning.fisher_information import FisherInformation


class FisherForgettingBaseline:
    """
    Single-shot Fisher-inverse-weighted noise scrubbing (Golatkar et al. 2020).
    """

    def __init__(self, noise_scale: float = 0.1, epsilon: float = 1e-10,
                device: str = "cpu", per_layer_normalize: bool = False,
                per_layer_eps_fraction: float = 0.01) -> None:
        """
        Args:
            noise_scale: Overall noise magnitude multiplier.
            epsilon:     Numerical-stability floor added to Fisher values
                        before the inverse-sqrt. Must be well below the
                        typical Fisher magnitude for the architecture in
                        use, or it dominates 1/sqrt(F+eps) uniformly and
                        the "protect important parameters" mechanism this
                        method is supposed to implement degenerates into
                        an undifferentiated constant multiplier instead.
                        Found by actually running this on the project's
                        MLP: Fisher values here have median ~1.9e-8 and
                        max ~8.2e-6, so the previous default (1e-6) was
                        LARGER than the median Fisher value across ~98%
                        of parameters — every noise_std collapsed to
                        roughly noise_scale/sqrt(epsilon) regardless of
                        each parameter's actual importance, which is why
                        even noise_scale=0.001 caused catastrophic retain
                        damage (min_retain~0.10) during calibration.
            device:      torch device.
            per_layer_normalize: If False (default), epsilon is used as a
                        single global floor for every parameter tensor in
                        the model, exactly as originally implemented and
                        as validated in ARCHITECTURE.md §19. If True,
                        each named parameter tensor gets its own floor
                        (see `_effective_epsilon`), addressing the
                        robustness gap identified in §19.3: a single
                        global epsilon is a compromise that cannot be
                        simultaneously well-calibrated for every layer
                        when layers have meaningfully different typical
                        Fisher magnitudes (e.g. an early layer vs. the
                        output layer, or the same layer across different
                        random-init seeds) — a layer whose Fisher values
                        happen to be small for a given seed gets an
                        epsilon too large relative to its own scale
                        (swamping differentiation) or, more relevantly to
                        the seed=1004 failure, entries near zero within
                        one layer get insufficiently floored by a global
                        epsilon tuned for the *whole model's* typical
                        scale, producing an outsized noise_std for that
                        layer specifically. Default is False so existing
                        callers and every result already reported in
                        ARCHITECTURE.md are completely unaffected.
            per_layer_eps_fraction: Only used when per_layer_normalize is
                        True. The per-layer floor is
                        `max(epsilon, per_layer_eps_fraction * median(F_layer))`
                        — a small fraction of that layer's own median
                        Fisher value, falling back to the global `epsilon`
                        floor when a layer's median is itself ~0 (e.g. a
                        dead layer). Default 0.01 is a first, untuned
                        choice — deliberately conservative (close to the
                        original global epsilon in the "typical" case
                        measured in §19.1) rather than aggressively tuned
                        on this project's own failure case, since tuning
                        it specifically to fix seed=1004 would risk
                        overfitting the fix to the one seed that is
                        already known to fail.
        """
        self.noise_scale            = noise_scale
        self.epsilon                = epsilon
        self.device                 = device
        self.per_layer_normalize    = per_layer_normalize
        self.per_layer_eps_fraction = per_layer_eps_fraction
        self.fisher                 = FisherInformation(device=device)

    def _effective_epsilon(self, f: torch.Tensor) -> float:
        """
        Epsilon floor used for one parameter tensor's inverse-sqrt
        weighting. Pulled out as its own method (rather than inlined in
        `scrub()`) specifically so default-preservation is directly
        unit-testable without needing to reproduce `scrub()`'s stochastic
        noise draws: when `per_layer_normalize` is False this must return
        exactly `self.epsilon`, unconditionally, with no dependence on f.

        Args:
            f: This parameter tensor's diagonal Fisher values.

        Returns:
            The epsilon to add to f before the inverse-sqrt.
        """
        if not self.per_layer_normalize:
            return self.epsilon
        layer_median = torch.median(f).item()
        return max(self.epsilon, self.per_layer_eps_fraction * layer_median)

    def scrub(
        self,
        model:         nn.Module,
        retain_loader: DataLoader,
        fisher_samples: int = 200,
    ) -> nn.Module:
        """
        Apply Fisher Forgetting scrubbing to a COPY of the given model
        (the original is left untouched, matching how this project's
        other conditions each work from a fresh deep-copy).

        Args:
            model:          Pretrained model to scrub.
            retain_loader:  DataLoader for the retain set (Fisher is
                            computed here, not on the forget set).
            fisher_samples: Samples used for the Fisher estimate.

        Returns:
            A new, scrubbed model (deep copy of the input, perturbed).
        """
        scrubbed = copy.deepcopy(model).to(self.device)
        # NOT wrapped in torch.no_grad() — FisherInformation.compute()
        # needs gradients enabled internally (it calls loss.backward()).
        # An earlier version wrapped this whole method in @torch.no_grad(),
        # which silently broke that internal backward() call with
        # "element 0 of tensors does not require grad" — found by actually
        # running this baseline rather than assuming it worked.
        self.fisher.compute(scrubbed, retain_loader, max_samples=fisher_samples)

        with torch.no_grad():
            for name, param in scrubbed.named_parameters():
                if name not in self.fisher.fisher:
                    continue
                f = self.fisher.fisher[name].to(self.device)
                eps = self._effective_epsilon(f)
                noise_std = self.noise_scale / torch.sqrt(f + eps)
                noise = torch.randn_like(param.data) * noise_std
                param.data.add_(noise)

        return scrubbed
