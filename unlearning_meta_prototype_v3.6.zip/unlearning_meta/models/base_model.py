"""
models/base_model.py
====================
MLP backbone used throughout the unlearning experiments.
Designed for easy per-layer activation extraction and parameter analysis.
"""

from __future__ import annotations
import copy
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class MLP(nn.Module):
    """
    Configurable Multi-Layer Perceptron.

    Extra affordances for unlearning research:
      • get_activations()  – returns per-layer activation tensors
      • parameter_diff()   – computes Δθ between two checkpoints
      • clone()            – deep-copy for checkpointing
    """

    def __init__(
        self,
        input_dim: int = 784,
        hidden_dims: Optional[List[int]] = None,
        output_dim: int = 10,
        dropout_rate: float = 0.2,
        use_batch_norm: bool = True,
    ) -> None:
        super().__init__()

        if hidden_dims is None:
            hidden_dims = [512, 256, 128]

        self.input_dim = input_dim
        self.hidden_dims = hidden_dims
        self.output_dim = output_dim

        # Build hidden layers
        self.linears    = nn.ModuleList()
        self.bns        = nn.ModuleList()
        self.dropouts   = nn.ModuleList()

        prev = input_dim
        for h in hidden_dims:
            self.linears.append(nn.Linear(prev, h))
            if use_batch_norm:
                self.bns.append(nn.BatchNorm1d(h))
            self.dropouts.append(nn.Dropout(dropout_rate))
            prev = h

        self.use_batch_norm = use_batch_norm
        self.output_layer   = nn.Linear(prev, output_dim)

        self._init_weights()

    # ──────────────────────────────────────────────────────────────────────────
    # Initialisation
    # ──────────────────────────────────────────────────────────────────────────

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
                nn.init.zeros_(m.bias)

    # ──────────────────────────────────────────────────────────────────────────
    # Forward pass
    # ──────────────────────────────────────────────────────────────────────────

    def forward(
        self,
        x: torch.Tensor,
        return_features: bool = False,
    ) -> torch.Tensor | Tuple[torch.Tensor, List[torch.Tensor]]:
        """
        Args:
            x:               [B, input_dim] or [B, C, H, W] (auto-flattened)
            return_features: whether to also return hidden activations

        Returns:
            logits  (or  (logits, [h_0, h_1, ...]) when return_features=True)
        """
        if x.dim() > 2:
            x = x.view(x.size(0), -1)

        features: List[torch.Tensor] = []

        for i, linear in enumerate(self.linears):
            x = linear(x)
            if self.use_batch_norm and i < len(self.bns):
                x = self.bns[i](x)
            x = F.relu(x)
            x = self.dropouts[i](x)
            if return_features:
                features.append(x)

        logits = self.output_layer(x)

        if return_features:
            return logits, features
        return logits

    # ──────────────────────────────────────────────────────────────────────────
    # Analysis utilities
    # ──────────────────────────────────────────────────────────────────────────

    @torch.no_grad()
    def get_activations(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Run a forward pass in eval mode and collect activations.

        Returns:
            {"layer_0": Tensor[B, h0], "layer_1": ..., "output": logits}
        """
        was_training = self.training
        self.eval()

        if x.dim() > 2:
            x = x.view(x.size(0), -1)

        activations: Dict[str, torch.Tensor] = {}

        for i, linear in enumerate(self.linears):
            x = linear(x)
            if self.use_batch_norm and i < len(self.bns):
                x = self.bns[i](x)
            x = F.relu(x)
            activations[f"layer_{i}"] = x.clone()

        logits = self.output_layer(x)
        activations["output"] = logits.clone()

        if was_training:
            self.train()

        return activations

    def get_named_layer_params(self) -> Dict[str, List[nn.Parameter]]:
        """Return parameters grouped by layer name."""
        groups: Dict[str, List[nn.Parameter]] = {}
        for i, lin in enumerate(self.linears):
            groups[f"layer_{i}"] = list(lin.parameters())
        groups["output"] = list(self.output_layer.parameters())
        return groups

    def clone(self) -> "MLP":
        """Return a deep copy (detached from computation graph)."""
        return copy.deepcopy(self)

    @torch.no_grad()
    def parameter_diff(self, reference: "MLP") -> Dict[str, torch.Tensor]:
        """Compute named parameter differences self − reference."""
        diffs: Dict[str, torch.Tensor] = {}
        for (n1, p1), (_, p2) in zip(
            self.named_parameters(), reference.named_parameters()
        ):
            diffs[n1] = (p1.data - p2.data).clone()
        return diffs

    @torch.no_grad()
    def parameter_l2_change(self, reference: "MLP") -> float:
        """Compute total L2 distance in parameter space from a reference."""
        total = 0.0
        for (_, p1), (_, p2) in zip(
            self.named_parameters(), reference.named_parameters()
        ):
            total += (p1.data - p2.data).norm(2).item() ** 2
        return total ** 0.5

    @torch.no_grad()
    def add_noise(self, std: float) -> None:
        """Add Gaussian noise to all parameters in-place."""
        for p in self.parameters():
            p.data.add_(torch.randn_like(p.data) * std)

    def num_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def __repr__(self) -> str:
        return (
            f"MLP(in={self.input_dim}, hidden={self.hidden_dims}, "
            f"out={self.output_dim}, params={self.num_parameters():,})"
        )
