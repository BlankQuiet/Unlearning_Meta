"""
engines/unlearning_engine.py
==============================
Unlearning Engine  (Layer 1)

Responsibilities:
  • Forgetting         — gradient ascent on forget set
  • Privacy Protection — noise injection + optional DP
  • Retention          — dream replay + EWC consolidation
  • Accuracy Recovery  — correction replay
  • Evaluation         — produces UnlearningMetrics

Critical constraint:
  This is the ONLY component that modifies model weights.
  It receives StrategyUpdate proposals from the Experience Engine
  and decides how to apply them to its own hyperparameters.
"""

from __future__ import annotations
import copy
import os
from typing import Dict, Optional

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from unlearning_meta.config import UnlearningConfig
from unlearning_meta.schemas import UnlearningMetrics, StrategyUpdate
from unlearning_meta.modules.unlearning.memory_trace    import MemoryTraceMapper
from unlearning_meta.modules.unlearning.fisher_information import FisherInformation
from unlearning_meta.modules.unlearning.gradient_ascent  import GradientAscentForgetter
from unlearning_meta.modules.unlearning.dream_replay     import DreamReplayer
from unlearning_meta.modules.unlearning.correction_replay import CorrectionReplayer
from unlearning_meta.modules.unlearning.ewc_consolidation import EWCConsolidation
from unlearning_meta.modules.unlearning.evaluator        import UnlearningEvaluator


class UnlearningEngine:
    """
    Layer-1 engine: owns the model and all weight-update logic.

    Data flow per cycle::

        run_cycle()
          ├─ MemoryTraceMapper.compute()
          ├─ FisherInformation.compute()  (on retain set)
          ├─ GradientAscentForgetter.run()
          ├─ DreamReplayer.run()
          ├─ CorrectionReplayer.run()
          └─ UnlearningEvaluator.evaluate()  →  UnlearningMetrics
    """

    def __init__(
        self,
        model:  nn.Module,
        config: UnlearningConfig,
        device: str = "cpu",
    ) -> None:
        self.model  = model.to(device)
        self.config = config
        self.device = device

        # Snapshot of pre-cycle weights for stability measurement
        self._reference_model: Optional[nn.Module] = None

        # θ_0: snapshot of weights at the START of unlearning (before cycle 0),
        # kept fixed for the entire run. Used to compute cumulative_drift — a
        # "momentum feature" distinguishing a lightly-perturbed model from one
        # that has accumulated large total displacement across many cycles,
        # which the per-cycle `stability` metric alone cannot distinguish
        # (two models can have identical per-cycle stability at cycle N while
        # having taken very different cumulative paths to get there).
        self._theta_zero: Optional[nn.Module] = None

        # Persistent Fisher and EWC (updated once per cycle)
        self.fisher = FisherInformation(device=device)
        self.ewc:    Optional[EWCConsolidation] = None

        # Memory trace (updated each cycle)
        self.trace = MemoryTraceMapper(
            top_k=config.trace_top_k, device=device
        )

        # Evaluator
        self.evaluator = UnlearningEvaluator(
            model=self.model,
            device=device,
            batch_size=config.eval_batch_size,
        )

        self._cycle_log: list[Dict] = []

    # ──────────────────────────────────────────────────────────────────────────
    # Main cycle
    # ──────────────────────────────────────────────────────────────────────────

    def run_cycle(
        self,
        forget_loader: DataLoader,
        retain_loader: DataLoader,
        test_loader:   DataLoader,
        cycle:         int,
    ) -> UnlearningMetrics:
        """
        Execute one full unlearning cycle.

        Args:
            forget_loader: DataLoader for data to forget.
            retain_loader: DataLoader for data to retain.
            test_loader:   DataLoader for evaluation.
            cycle:         Current cycle index.

        Returns:
            UnlearningMetrics for this cycle.
        """
        # ── 0. Snapshot reference model ────────────────────────────────────
        self._reference_model = copy.deepcopy(self.model)
        if self._theta_zero is None:
            self._theta_zero = copy.deepcopy(self.model)   # fixed for the whole run

        # ── 1. Memory Trace ────────────────────────────────────────────────
        self.trace.compute(self.model, forget_loader, retain_loader)

        # ── 2. Fisher Information (on retain set) ─────────────────────────
        self.fisher.compute(
            self.model,
            loader      = retain_loader,
            max_samples = self.config.fisher_samples,
        )

        # ── 3. Initialise / refresh EWC ───────────────────────────────────
        if self.config.ewc_enabled:
            self.ewc = EWCConsolidation(
                reference_model = self._reference_model,
                ewc_lambda      = self.config.ewc_lambda,
                device          = self.device,
            )
            self.ewc.register(self.fisher.fisher)

        # ── 4. Gradient Ascent Forgetting ──────────────────────────────────
        forgetter = GradientAscentForgetter(
            model          = self.model,
            forget_lr      = self.config.forget_lr,
            strength       = self.config.gradient_ascent_strength,
            max_epochs     = self.config.forget_epochs,
            max_grad_norm  = self.config.max_grad_norm,
            noise_scale    = self.config.noise_scale,
            device         = self.device,
        )
        if not self.config.selective_noise_enabled:
            selectivity_weights = None
        elif self.config.selective_noise_normalization == "mean":
            selectivity_weights = self.trace.to_parameter_weights_mean_normalized(self.model)
        else:
            selectivity_weights = self.trace.to_parameter_weights(self.model)

        if not self.config.selective_ascent_enabled:
            ascent_weights = None
        elif self.config.selective_ascent_normalization == "mean":
            ascent_weights = self.trace.to_ascent_weights_mean_normalized(
                self.model,
                alpha = self.config.selective_ascent_alpha,
                beta  = self.config.selective_ascent_beta,
            )
        else:
            ascent_weights = self.trace.to_ascent_weights(
                self.model,
                alpha = self.config.selective_ascent_alpha,
                beta  = self.config.selective_ascent_beta,
            )
        forget_stats = forgetter.run(
            forget_loader        = forget_loader,
            ewc_fisher           = self.fisher.fisher if self.config.ewc_enabled else None,
            ewc_reference        = self._reference_model,
            ewc_lambda           = self.config.ewc_lambda,
            selectivity_weights  = selectivity_weights,
            ascent_weights       = ascent_weights,
        )

        # ── 5. Dream Replay ────────────────────────────────────────────────
        if self.config.dream_replay_enabled:
            dreamer = DreamReplayer(
                model              = self.model,
                replay_lr          = self.config.dream_replay_lr,
                replay_epochs      = self.config.dream_replay_epochs,
                confidence_thresh  = self.config.dream_confidence_thresh,
                strength           = self.config.dream_replay_strength,
                device             = self.device,
            )
            dream_stats = dreamer.run(retain_loader)
        else:
            dream_stats = {"dream_count": 0, "avg_loss": 0.0}

        # ── 6. Correction Replay ───────────────────────────────────────────
        if self.config.correction_replay_enabled:
            corrector = CorrectionReplayer(
                model    = self.model,
                lr       = self.config.correction_lr,
                epochs   = self.config.correction_epochs,
                strength = self.config.correction_strength,
                device   = self.device,
            )
            corr_stats = corrector.run(
                retain_loader   = retain_loader,
                fisher          = self.fisher.fisher if self.config.ewc_enabled else None,
                reference_model = self._reference_model,
                ewc_lambda      = self.config.ewc_lambda,
            )
        else:
            corr_stats = {"avg_loss": 0.0, "epochs_run": 0}

        # ── 7. Evaluate ────────────────────────────────────────────────────
        metrics = self.evaluator.evaluate(
            forget_loader   = forget_loader,
            retain_loader   = retain_loader,
            test_loader     = test_loader,
            reference_model = self._reference_model,
            cycle           = cycle,
        )

        # ── 7b. Cumulative drift from theta_0 (momentum feature) ───────────
        # Same normalisation convention as UnlearningEvaluator._stability_score
        # (relative L2 distance in parameter space), but measured against the
        # fixed start-of-run snapshot rather than the previous cycle, so it
        # accumulates monotonically instead of resetting each cycle. This is
        # NOT one of the six original spec'd metrics — it's stored under
        # metrics.extra so it doesn't change the required output contract.
        with torch.no_grad():
            total_change = total_norm = 0.0
            for (_, p_cur), (_, p_zero) in zip(
                self.model.named_parameters(), self._theta_zero.named_parameters()
            ):
                total_change += (p_cur.data - p_zero.data).norm(2).item() ** 2
                total_norm   += p_zero.data.norm(2).item() ** 2
            metrics.extra["cumulative_drift"] = (
                (total_change ** 0.5) / (total_norm ** 0.5) if total_norm > 1e-8 else 0.0
            )

        # ── 8. Log internal stats ─────────────────────────────────────────
        self._cycle_log.append({
            "cycle":        cycle,
            "forget_stats": forget_stats,
            "dream_stats":  dream_stats,
            "corr_stats":   corr_stats,
            "metrics":      metrics.to_dict(),
        })

        return metrics

    # ──────────────────────────────────────────────────────────────────────────
    # Strategy application  (receives proposals from Experience Engine)
    # ──────────────────────────────────────────────────────────────────────────

    def apply_strategy(self, update: StrategyUpdate) -> bool:
        """
        Apply a hyperparameter change proposed by the Experience Engine.

        CRITICAL: This method only modifies config hyperparameters.
        It does NOT modify model weights.  Weight changes happen only
        inside run_cycle().

        Args:
            update: StrategyUpdate from ExperienceEngine.

        Returns:
            True if the update was applied; False if it was rejected.
        """
        if update.is_noop():
            return False

        action = update.action
        delta  = update.delta * action.sign    # sign encodes increase/decrease

        attr = action.config_attr
        if attr is None:
            return False

        if not hasattr(self.config, attr):
            return False

        current_val = getattr(self.config, attr)

        # Type-aware update. max_grad_norm is special-cased to multiplicative
        # scaling rather than additive: §12.3 found its useful range spans
        # roughly 1.0 to 50+ (orders of magnitude), unlike e.g.
        # gradient_ascent_strength (0.1-5.0) or noise_scale (0-0.2), where
        # the existing ~0.05-0.5 delta range used across all three proposal
        # tiers is already a sensible fraction of the parameter's range. The
        # same additive delta applied to max_grad_norm would take hundreds
        # of cycles to matter.
        if attr == "max_grad_norm":
            factor = 1.0 + update.delta   # e.g. delta=0.5 -> 1.5x per step
            if action.sign < 0:
                new_val = float(current_val) / factor
            else:
                new_val = float(current_val) * factor
        elif isinstance(current_val, int):
            new_val = max(1, int(current_val + round(delta)))
        else:
            new_val = float(current_val + delta)

        # Safety clamps to prevent runaway values
        new_val = self._clamp(attr, new_val)
        setattr(self.config, attr, type(current_val)(new_val))

        return True

    def _clamp(self, attr: str, value: float) -> float:
        """Clamp config values to safe operating ranges."""
        bounds = {
            "gradient_ascent_strength": (0.1, 5.0),
            "noise_scale":              (0.0, 0.2),
            "dream_replay_epochs":      (1, 20),
            "correction_epochs":        (1, 20),
            "ewc_lambda":               (10.0, 10000.0),
            "forget_lr":                (1e-5, 0.1),
            "correction_lr":            (1e-5, 0.05),
            # Default is 1.0. Upper bound of 50 is generous enough to
            # effectively neutralise the clip for a model this size (see
            # ARCHITECTURE.md §12.3 — a raised-to-1000 test unlocked clean
            # forgetting), while still keeping a nominal ceiling rather
            # than being literally unbounded.
            "max_grad_norm":            (0.1, 50.0),
        }
        lo, hi = bounds.get(attr, (-1e9, 1e9))
        return max(lo, min(hi, value))

    # ──────────────────────────────────────────────────────────────────────────
    # Persistence helpers
    # ──────────────────────────────────────────────────────────────────────────

    def save_checkpoint(self, path: str) -> None:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            "model_state":  self.model.state_dict(),
            "fisher_state": self.fisher.state_dict(),
        }, path)

    def load_checkpoint(self, path: str) -> None:
        ckpt = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ckpt["model_state"])
        self.fisher.load_state_dict(ckpt["fisher_state"])

    def config_snapshot(self) -> Dict:
        """Return a snapshot of the current UnlearningConfig values."""
        import dataclasses
        return dataclasses.asdict(self.config)
