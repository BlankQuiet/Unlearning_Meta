"""
engines/experience_engine.py
==============================
Experience Engine  (Layer 2)

Responsibilities:
  • Reflection         — analyse failure modes from recent history
  • Self Explanation   — generate natural language cycle logs
  • Hypothesis         — form if-then rules from observations
  • Strategy Learning  — maintain long-term strategy memory
  • Meta-Learning      — learn *how* to unlearn optimally

Critical constraint:
  This engine has NO access to model weights.
  It receives only UnlearningMetrics and produces StrategyUpdate proposals.

Data flow::

  process(metrics)
    ├─ journal.add(metrics)
    ├─ SelfReflection.reflect()
    ├─ RuleExtractor.extract()
    ├─ StrategyEvolution.evolve()
    ├─ StrategyMemory.run_lifecycle()
    ├─ _propose_strategy()
    ├─ SelfExplainer.explain()
    └─ MetaKnowledge.update()
         → returns StrategyUpdate
"""

from __future__ import annotations
import random
from typing import Dict, List, Optional

from unlearning_meta.config import ExperienceConfig
from unlearning_meta.schemas import (
    UnlearningMetrics, StrategyUpdate, StrategyAction, StrategyRecord
)
from unlearning_meta.modules.experience.memory_journal   import MemoryJournal
from unlearning_meta.modules.experience.self_reflection  import SelfReflection, ReflectionReport
from unlearning_meta.modules.experience.self_explanation import SelfExplainer
from unlearning_meta.modules.experience.rule_extraction  import RuleExtractor
from unlearning_meta.modules.experience.strategy_memory  import StrategyMemory
from unlearning_meta.modules.experience.strategy_evolution import StrategyEvolution
from unlearning_meta.modules.experience.meta_knowledge   import MetaKnowledge
from unlearning_meta.modules.experience.contextual_bandit import ContextualBanditSelector


class ExperienceEngine:
    """
    Layer-2 engine: accumulates experience and proposes unlearning strategies.

    This engine NEVER modifies model weights. It only produces StrategyUpdate
    objects that the UnlearningEngine may choose to apply.
    """

    def __init__(
        self,
        config:        ExperienceConfig,
        score_weights: Optional[Dict[str, float]] = None,
        seed:          int = 42,
    ) -> None:
        self.config        = config
        self.score_weights = score_weights
        self.target_forget_acc = config.target_forget_acc
        self.retain_floor      = config.retain_floor
        self._rng          = random.Random(seed)
        self._cycle        = 0
        self._prev_score:  Optional[float] = None
        self._last_proposal: Optional[StrategyUpdate] = None

        # Sub-modules
        self.journal    = MemoryJournal(max_entries=config.journal_max_entries)
        self.reflector  = SelfReflection(window=config.reflection_window)
        self.explainer  = SelfExplainer()
        self.extractor  = RuleExtractor(
            min_observations  = config.min_observations,
            confidence_thresh = config.rule_confidence_thresh,
            window            = config.pattern_window,
        )
        self.memory = StrategyMemory(
            max_active           = config.max_active,
            max_dormant          = config.max_dormant,
            max_archive          = config.max_archive,
            importance_threshold = config.importance_threshold,
            dormant_after        = config.dormant_after_cycles,
            archive_after        = config.archive_after_cycles,
            w_success            = config.w_success,
            w_gen                = config.w_generalization,
            w_recency            = config.w_recency,
            w_usage              = config.w_usage,
        )
        self.evolver = StrategyEvolution(
            similarity_thresh = config.similarity_thresh,
            max_rounds        = config.max_merge_rounds,
        )
        self.meta = MetaKnowledge(
            exploration_rate = config.exploration_rate,
            history_window   = config.journal_max_entries,
        )

        self.bandit: Optional[ContextualBanditSelector] = None
        if config.use_contextual_bandit:
            self.bandit = ContextualBanditSelector(
                beta              = config.bandit_beta,
                epsilon           = config.exploration_rate,
                cooldown_after    = config.bandit_cooldown_after,
                momentum_patience = config.bandit_momentum_patience,
                seed              = seed,
            )

    # ──────────────────────────────────────────────────────────────────────────
    # Main entry point
    # ──────────────────────────────────────────────────────────────────────────

    def process(
        self,
        metrics: UnlearningMetrics,
    ) -> StrategyUpdate:
        """
        Process one cycle of UnlearningMetrics and emit a StrategyUpdate.

        This method has NO side-effects on model parameters.

        Args:
            metrics: Output of UnlearningEngine.run_cycle().

        Returns:
            StrategyUpdate proposal (may be NOOP if no change is needed).
        """
        cycle = metrics.cycle
        self._cycle = cycle
        current_score = metrics.composite_score(
            self.score_weights,
            target_forget_acc=self.target_forget_acc,
            retain_floor=self.retain_floor,
        )

        # ── 1. Record outcome of last proposal ────────────────────────────
        if self._last_proposal is not None and self._prev_score is not None:
            delta   = current_score - self._prev_score
            success = delta > 0.02
            self.meta.update(
                action       = self._last_proposal.action,
                metrics      = metrics,
                score_delta  = delta,
                success      = success,
                score        = current_score,
            )
            # Update strategy memory with outcome
            if self._last_proposal.source_rule is not None:
                self.memory.record_outcome(
                    record_id   = self._last_proposal.source_rule,
                    success     = success,
                    cycle       = cycle,
                    score_delta = delta,
                )
        else:
            self.meta.update(None, metrics, 0.0, False, score=current_score)

        # ── 2. Reflect on recent history ────────────────────────────────────
        # (moved ahead of journal logging so the logged failure_types match
        # what actually drove the strategy decision below, including the
        # journal-aware forget_progress_stalled check that a metrics-only
        # pass can't see — see SelfReflection's module docstring)
        reflection = self.reflector.reflect(self.journal, cycle)

        # ── 3. Propose next strategy ──────────────────────────────────────
        proposal = self._propose_strategy(metrics, reflection, cycle, current_score)

        # ── 4. Generate natural language explanation ───────────────────────
        explanation = self.explainer.explain(
            metrics       = metrics,
            reflection    = reflection,
            proposal      = proposal,
            prev_score    = self._prev_score,
            current_score = current_score,
        )

        # ── 5. Record in journal ───────────────────────────────────────────
        self.journal.add(
            cycle            = cycle,
            metrics          = metrics,
            strategy_applied = self._last_proposal,   # LAST cycle's proposal
            score_weights    = self.score_weights,
            failure_types    = reflection.active_failures,
            explanation      = explanation,
            composite_score  = current_score,
        )

        # ── 6. Extract new rules every 5 cycles ───────────────────────────
        if cycle % 5 == 0 and cycle > 0:
            new_rules = self.extractor.extract(self.journal, cycle)
            for rule in new_rules:
                self.memory.add(rule)

        # ── 7. Evolve (merge similar) strategies every 10 cycles ──────────
        # Return value intentionally discarded: self.evolver.merge_log already
        # records every merge event in full (cycle, merged record IDs,
        # resulting rule text) and is what report()/main.py consume — a
        # bare count here would just be redundant, lower-detail information.
        if cycle % 10 == 0 and cycle > 0:
            self.evolver.evolve(self.memory, cycle)

        # ── 8. Lifecycle management ───────────────────────────────────────
        if cycle % 5 == 0:
            self.memory.run_lifecycle(cycle)

        # ── 9. Cache for next cycle ──────────────────────────────────────
        self._last_proposal = proposal
        self._prev_score    = current_score

        return proposal

    # ──────────────────────────────────────────────────────────────────────────
    # Strategy proposal
    # ──────────────────────────────────────────────────────────────────────────

    def _propose_strategy(
        self,
        metrics:       UnlearningMetrics,
        reflection:    ReflectionReport,
        cycle:         int,
        current_score: Optional[float] = None,
    ) -> StrategyUpdate:
        """
        Select the next strategy action.

        If config.use_contextual_bandit is set, delegates to
        ContextualBanditSelector (a single unified score over the full
        action space — ARCHITECTURE.md §14). Otherwise falls back to the
        original three-tier heuristic below, kept as the default and as a
        documented rollback path:

        Tier 1 (exploit): Query Strategy Memory for matching rules.
        Tier 2 (exploit): Use MetaKnowledge UCB recommendation.
        Tier 3 (explore): ε-random exploration of strategy space.

        The explore/exploit coin flip is sampled exactly ONCE per call and
        reused across all three tier checks below. An earlier version called
        self._should_explore() independently at each tier (up to 3 separate
        Bernoulli(ε) draws per cycle); because reaching Tier 3 required
        multiple independent draws to compound favourably, the *actual*
        empirical probability of random exploration was roughly 4x lower
        than the configured exploration_rate, not matching its own
        docstring. Sampling once fixes this.
        """
        if self.bandit is not None:
            return self.bandit.select(metrics, reflection, self.memory,
                                       self.meta, cycle,
                                       current_score=current_score)

        explore = self._should_explore()

        # ── Tier 1: Memory-based rule matching ───────────────────────────
        if not explore:
            best_rec = self.memory.best_strategy(metrics, cycle)
            if best_rec is not None and best_rec.confidence >= 0.55:
                return self._record_to_update(best_rec, cycle)

        # ── Tier 2: Meta-knowledge recommendation ─────────────────────────
        focus = reflection.suggested_focus
        if focus != "noop" and not explore:
            action = self.meta.best_action_for(focus, use_meta=(cycle > 10))
            delta  = self.meta.recommended_delta(action)
            return StrategyUpdate(
                action       = action,
                delta        = delta,
                rationale    = f"Meta-KB: addressing {focus}",
                confidence   = reflection.confidence * 0.8,
                source_rule  = None,
                cycle        = cycle,
            )

        # ── Tier 3: ε-random exploration ──────────────────────────────────
        if explore:
            action = self._rng.choice([
                a for a in StrategyAction if a != StrategyAction.NOOP
            ])
            return StrategyUpdate(
                action      = action,
                delta       = 0.1 + self._rng.random() * 0.2,
                rationale   = "ε-explore: random strategy",
                confidence  = 0.3,
                source_rule = None,
                cycle       = cycle,
            )

        # ── No change needed ───────────────────────────────────────────────
        return StrategyUpdate(
            action    = StrategyAction.NOOP,
            delta     = 0.0,
            rationale = "No improvement strategy identified.",
            confidence = 0.9,
            cycle     = cycle,
        )

    def _should_explore(self) -> bool:
        return self._rng.random() < self.config.exploration_rate

    @staticmethod
    def _record_to_update(
        rec: StrategyRecord, cycle: int
    ) -> StrategyUpdate:
        return StrategyUpdate(
            action      = rec.action,
            delta       = 0.2,   # standard step; refined by UnlearningEngine
            rationale   = f"Memory rule [{rec.id}]: {rec.rule[:80]}",
            confidence  = rec.confidence,
            source_rule = rec.id,
            cycle       = cycle,
        )

    # ──────────────────────────────────────────────────────────────────────────
    # Reporting
    # ──────────────────────────────────────────────────────────────────────────

    def report(self) -> Dict:
        """Return a structured report of the Experience Engine state."""
        return {
            "journal_entries":  len(self.journal),
            "memory_stats":     self.memory.stats(),
            "extracted_rules":  len(self.extractor.extracted_rules),
            "merge_log":        self.evolver.merge_log[-10:],
            "meta_summary":     self.meta.summary(),
        }

    def top_rules(self, n: int = 10) -> List[Dict]:
        """Return top-n rules by confidence from strategy memory."""
        active = sorted(
            [r for r in self.memory.records.values()
             if r.state.value in ("active", "dormant")],
            key=lambda r: r.confidence,
            reverse=True,
        )
        return [
            {
                "id":          r.id,
                "rule":        r.rule,
                "action":      r.action.value,
                "success_rate": round(r.success_rate, 3),
                "confidence":  round(r.confidence, 3),
                "usage":       r.usage_frequency,
                "state":       r.state.value,
            }
            for r in active[:n]
        ]
