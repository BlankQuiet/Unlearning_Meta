# Project Context — v3.6 Repository Anatomy

Status: DRAFT. Not CLAUDE.md. Produced per explicit request: observe v3.6
as primary source, do not trust prior narrative (ARCHITECTURE.md/IDEAS.md)
as evidence of current code correctness, distinguish Confirmed / Potential
/ Risk throughout, stop after this document — no next-phase work follows
automatically.

Everything below was checked directly against the current v3.6 source in
this session (file reads, greps, and one live re-run of the full test
suite), not recalled from ARCHITECTURE.md's own account of past sections.
Where ARCHITECTURE.md is cited, it is cited as *a claim being checked*,
not as evidence in itself.

**Incident log for this session** (recorded per explicit instruction):
two full sandbox resets occurred (`/home/claude/project` wiped both
times, mid-session); both recovered from the last packaged
`/mnt/user-data/outputs/unlearning_meta_prototype_v3.6.zip` with no
change to shipped state. One disk-space exhaustion during dependency
reinstall, resolved via `pip cache purge`. No code in v3.6 was modified
during this recovery — restoration only. Final state re-verified:
73/73 tests passing, file list identical to the shipped v3.6 zip.

---

## A. Repository Map

```
unlearning_meta/
├── config.py                 -- UnlearningConfig, ExperienceConfig, ModelConfig,
│                                 TrainingConfig, top-level Config (dataclasses)
├── schemas.py                 -- UnlearningMetrics, StrategyUpdate, StrategyRecord,
│                                 StrategyAction (+ .opposite, .config_attr), StrategyState
├── main.py                    -- set_seed(), pretrain(); also an older end-to-end
│                                 demo entry point that calls MIAEvaluator directly
├── models/base_model.py       -- MLP (the only model architecture in use)
├── data/dataset_utils.py      -- 4 load_* functions + compute_retrain_baseline_forget_acc
│                                 + _collect_model_outputs (shared helper)
├── modules/unlearning/        -- Layer 1 (execution): memory_trace, fisher_information,
│                                 gradient_ascent, dream_replay, correction_replay,
│                                 ewc_consolidation, evaluator, fisher_forgetting_baseline
├── modules/experience/        -- Layer 2 (adaptation): memory_journal, self_reflection,
│                                 self_explanation, rule_extraction, strategy_memory,
│                                 strategy_evolution, meta_knowledge, contextual_bandit
├── engines/                   -- unlearning_engine.py (owns model + config; run_cycle,
│                                 apply_strategy), experience_engine.py (owns journal/
│                                 memory/bandit; process, never touches model)
├── evaluation/mia_evaluator.py -- ConfidenceMIA, ShadowMIA, MIAEvaluator (diagnostic,
│                                 NOT on the composite_score path — see D.4)
├── run_baseline_comparison.py -- build_base_config(), run_condition() -- the shared
│                                 infrastructure nearly every other run_*.py script reuses
├── run_*.py (15 scripts)      -- one per pre-registered or exploratory comparison;
│                                 each is an entry point, not a library import target
├── precommit/ (7 files)       -- pre-registration text, written before their data
├── seed_results/ (10 .jsonl)  -- raw per-seed outputs, the empirical record
├── tests/ (10 files, 73 tests) -- see D below for what each actually confirms
└── docs/
    ├── ARCHITECTURE.md         -- verified findings only (this project's own rule)
    ├── IDEAS.md                -- unverified hypotheses / metaphors
    └── external_reviews/       -- 9 rounds of archived raw review text
```

**Entry points** (scripts meant to be run, not imported): every
`run_*.py` at the package root. `main.py`, `run_real_experiment.py`, and
`run_instance_level_experiment.py` are the three call sites for
`MIAEvaluator` (see B and D.4) — older, still-functional demo/validation
scripts, distinct in role from the `run_*_comparison.py` /
`run_*_check.py` family that everything in ARCHITECTURE.md §17 onward
actually uses.

**Not yet inventoried in this pass**: `modules/experience/self_explanation.py`
and `utils/` were not re-read line-by-line this session (low centrality
to the invariants this request asked about — natural-language output
generation and logging, not data flow or scoring). Flagged here rather
than silently omitted.

---

## B. Execution / Data Flow (traced this session, not assumed)

```
load_*_forgetting(seed, forget_fraction/forget_classes)
    -> (forget_loader, retain_loader, test_loader, full_loader)
    [independence of these three: see D.1/D.2, E.1]

pretrain(model, full_loader)  -- main.py
    -> pretrained model M0

compute_retrain_baseline_forget_acc(...)  -- retrain-from-scratch gold standard,
    used as target_forget_acc downstream (data/dataset_utils.py)

UnlearningEngine(model, config).run_cycle(forget, retain, test, cycle):
    1. MemoryTraceMapper.compute(model, forget, retain) -> selectivity
    2. FisherInformation.compute(model, retain) -> F
    3. EWCConsolidation (registers F, reference weights)
    4. GradientAscentForgetter.run(forget, ewc, [ascent_weights]) -- model weights change HERE
    5. noise injection (uniform or selectivity-weighted -- selective_noise_enabled)
    6. DreamReplayer.run(retain) -- high-confidence self-replay
    7. CorrectionReplayer.run(retain)
    8. UnlearningEvaluator.evaluate(forget, retain, test, reference_model=M0)
       -> UnlearningMetrics{forget_acc, retain_acc, accuracy, privacy,
                            hallucination, stability}
       -- .privacy here comes from _mia_privacy_score(), a SEPARATE,
          sklearn-roc_auc_score-based confidence calculation -- NOT ShadowMIA.
    return UnlearningMetrics

ExperienceEngine(config).process(metrics) -- NEVER receives the model:
    1. MemoryJournal.add(cycle, metrics, last_proposal)
    2. SelfReflection.reflect(journal)
    3. RuleExtractor.extract(journal) -> candidate StrategyRecords
    4. StrategyMemory.add(...); StrategyEvolution.evolve(...); run_lifecycle(...)
    5. selection: Tier 1/2/3 hierarchy (default) OR ContextualBanditSelector
       (use_contextual_bandit=True) -- see D.6, F.4
    6. MetaKnowledge.update(action, metrics, delta, success)
    return StrategyUpdate{action, delta, source_rule, ...}

UnlearningEngine.apply_strategy(update):
    -- mutates ONLY UnlearningConfig fields (noise_scale, forget_lr, ewc_lambda,
       max_grad_norm, ...) via StrategyAction.config_attr. Confirmed (D.3) to
       never touch model.parameters().

[separately, NOT in the above loop:]
MIAEvaluator(model).evaluate(forget, retain, test) -- main.py /
    run_real_experiment.py / run_instance_level_experiment.py ONLY:
    - ConfidenceMIA: entropy/confidence gap, forget vs. test
    - ShadowMIA: trains a meta-classifier on (retain=member,
      test-half-A=non-member), evaluates on (forget=member,
      test-half-B=non-member) -- see D.4 for the independence check
    -> printed as a supplementary diagnostic; not stored in seed_results/,
       not read back into composite_score or any StrategyUpdate decision.
```

The two "MIA" paths (`_mia_privacy_score` inside the scored loop, and
`MIAEvaluator` outside it) are structurally separate code, confirmed by
reading both this session — not two views of the same mechanism.

---

## C. Dependency Map

```
config.py, schemas.py, models/base_model.py, data/dataset_utils.py  -- no internal deps
modules/unlearning/*  -- depend on schemas; fisher_forgetting_baseline
                          depends on fisher_information
modules/experience/*  -- depend on schemas; self_explanation depends on
                          self_reflection; strategy_evolution depends on
                          strategy_memory; contextual_bandit depends on
                          schemas + meta_knowledge
engines/unlearning_engine.py   -- config, schemas, modules/unlearning/*
engines/experience_engine.py   -- config, schemas, modules/experience/*
                                  (does NOT import modules/unlearning/* or
                                   models/* -- confirmed no model-facing
                                   import exists in this file)
evaluation/mia_evaluator.py    -- no internal deps (self-contained; does
                                  NOT import modules/unlearning/evaluator.py
                                  or vice versa -- confirmed by grep)
run_*.py                        -- import from run_baseline_comparison.py
                                   (build_base_config, run_condition) plus
                                   whichever engines/loaders that script needs
```

Dependency direction is downward, no cycles observed. This matches
ARCHITECTURE.md §2's claim; re-confirmed independently via grep rather
than assumed from that section.

---

## D. Confirmed Invariants (backed by a specific test or direct code trace this session)

1. **Forget ∩ Retain = ∅ within the training split**, for all three
   `load_*_forgetting` loaders — guaranteed by construction
   (complementary boolean masks: `forget_mask` / `~forget_mask` over the
   same array). Traced directly in `load_digits_unlearning_datasets`,
   `load_digits_instance_forgetting`, `load_wine_instance_forgetting`.
2. **(Forget ∪ Retain) ∩ Test = ∅** — guaranteed by `sklearn.
   train_test_split` being applied *before* the forget/retain split, in
   all three loaders, traced directly.
3. **`ExperienceEngine.process()` never mutates model weights** —
   `tests/test_integration.py`'s weight-snapshot test does not just
   check the method signature; it snapshots actual parameter tensors,
   calls `process()`, and asserts `torch.equal` on every parameter
   after. Strong, value-level confirmation, re-read this session.
4. **`ShadowMIA`'s train-side and eval-side non-member samples are
   disjoint** — re-verified directly from the current
   `evaluation/mia_evaluator.py` this session (not from ARCHITECTURE.md's
   account of the §29 fix): `_split_test_outputs` uses `torch.randperm`
   to produce two index sets from a single permutation, split at the
   midpoint — mathematically non-overlapping. Confirmed with a caveat:
   the degenerate case (`len(t_probs) < 2`) returns the *same* tensor
   for both sides; this is surfaced via a `strict_split` return field,
   not silently hidden, but a caller that ignores that field can still
   receive a non-independent result.
5. **`composite_score`'s privacy term is independent of `ShadowMIA`** —
   `modules/unlearning/evaluator.py`'s `_mia_privacy_score` calls
   `sklearn.metrics.roc_auc_score` directly; grepped this session for
   any import of `evaluation.mia_evaluator` inside `modules/unlearning/`
   — none found.
6. **New mechanisms default to prior behavior when their flag is off** —
   this pattern (not just claimed but actually enforced by a dedicated
   test per mechanism) holds for: `selective_noise_enabled`,
   `selective_ascent_enabled`, `per_layer_normalize`,
   `selective_noise_normalization`/`selective_ascent_normalization`.
   Each has its own "default path produces the exact original formula"
   test, not only an integration smoke test.
7. **`retain_floor` guardrail** — `composite_score(retain_floor=X)`
   returns a fixed heavy penalty when `retain_acc < X`; exercised
   (not merely unit-tested in isolation) across many real comparisons
   in ARCHITECTURE.md §22-31, where the penalty's firing/non-firing is
   itself part of the reported result.
8. **73/73 tests pass**, reproduced fresh this session, twice, after two
   independent environment restorations.

---

## E. Potential Invariants (believed important; NOT fully guaranteed by current tests)

1. **Forget/Retain/Test independence at the *identity* level, for the
   digits loaders specifically.** The property is guaranteed by code
   construction (D.1/D.2), but the only existing overlap test
   (`test_no_overlap_between_forget_and_retain`, in
   `tests/test_dataset_utils.py`) is for the **wine** loader only, and
   even that test is a *count* check (`forget_n + retain_n == full_n`),
   not an identity/feature-vector check. A future edit that broke the
   digits loaders' masking logic in a way that preserved counts would
   not be caught by any current test.
2. **No cross-run experience persistence.** Confirmed once, by reading
   `StrategyMemory.__init__` (no path/file argument, empty dicts) —
   this is a code-reading fact, not something a dedicated test asserts
   ("no save/load path exists anywhere"). A future contributor adding
   persistence would not trip any existing test.
3. **Reproducibility given a fixed seed** is real but *conditional* on
   an unstated shared assumption: `set_seed()` seeds the *global* RNG
   once, and every subsequent call in that process shares one stream.
   ARCHITECTURE.md §31 documents a concrete case where two otherwise-
   correct code paths produced different numbers for "the same seed"
   purely from call-order differences. Nothing in the codebase enforces
   or checks the canonical call order automatically; it is currently a
   convention, not a guarantee.
4. **MIA/scoring separation remains true only because no one has wired
   them together.** D.5 is a true fact about the current code, not a
   structural barrier — nothing prevents a future change from importing
   `ShadowMIA` into `evaluator.py` without any test flagging the loss of
   separation, since no test currently asserts "these two must stay
   apart."

---

## F. Violations / Risks (identified from direct inspection this session, and from the project's own recorded history)

1. **Calibration mismatch is a recurring, not a one-off, failure mode.**
   Documented independently at least three times in this project's own
   history: Fisher Forgetting's global `epsilon` (ARCHITECTURE.md §19,
   §22), selective noise/ascent's normalization gap (§26-§28), and the
   wine-dataset exploration hyperparameters (§31). Same shape each time:
   an absolute constant or step size calibrated against one setting's
   typical scale, applied unchanged to a different scale. This is a
   standing risk for *any* future new mechanism or new dataset/model
   size, not a closed issue.
2. **Test coverage is uneven across the codebase's history.** Modules
   built more recently in this project's timeline (`mia_evaluator.py`,
   `memory_trace.py`, `gradient_ascent.py`, `dataset_utils.py`) have
   thorough, dedicated test files. Older, foundational orchestration
   (`main.py`'s `pretrain`, the engines' own cycle-loop wiring beyond
   what integration tests happen to exercise) has comparatively thin
   direct coverage — confirmed by file size vs. test-file existence in
   A above, not merely assumed.
3. **Config surface has grown to 9 boolean toggles** (confirmed count,
   `config.py`) plus several numeric ones, with no automatic
   "experiment fingerprint" saved per run (`IDEAS.md` Idea 5, proposed,
   not implemented). Every result in ARCHITECTURE.md has so far been
   manually and carefully documented with its exact configuration, but
   that discipline is a *practice*, not something the codebase enforces.
4. **RNG-stream ordering sensitivity** (E.3) is a live risk for any new
   diagnostic or instrumentation script, not just a historical incident
   — the exact trap that produced it in §31 (skip a step that the
   "canonical" sequence includes) is easy to reproduce by accident in
   any new script that doesn't happen to replicate the full call chain.
5. **MIA/ShadowMIA's disconnection from decision-making cuts both
   ways.** It is why §29-30's bugs there provably didn't taint any
   reported result — but it also means this project's more rigorous
   privacy attack currently provides no runtime signal to
   `ExperienceEngine` at all; it is a standalone diagnostic, not a
   safety net influencing any unlearning decision today.
6. **Environment fragility, observed directly this session**: two full
   sandbox resets and one disk-space exhaustion in a single working
   session. Current mitigation is entirely manual (re-packaging to
   `/mnt/user-data/outputs` after each meaningful milestone) — there is
   no automated checkpointing.

---

## G. Absolute Protection (properties, not files)

- Forget / Retain / Test mutual exclusivity (D.1, D.2 — and see E.1 for
  where this is *not yet* fully test-guaranteed).
- Independence between any privacy-attack classifier's own
  training data and the data it is evaluated against (D.4).
- `ExperienceEngine` must never directly mutate model weights (D.3).
- The `retain_floor` guardrail must remain enforced wherever
  `composite_score` drives a decision.
- Comparability with prior results: `run_condition()`,
  `composite_score()`, and `build_base_config()`'s defaults are load-
  bearing for every historical number in ARCHITECTURE.md — a change to
  their behavior without preserving a verified default path would
  silently invalidate the existing record, not just future runs.
- Pre-registration discipline itself (write the analysis plan before
  seeing comparison data) — this is a process invariant, not a code
  invariant, but it is the property that makes every confirmatory claim
  in ARCHITECTURE.md meaningful.

---

## H. Core with Review

`UnlearningEngine`, `GradientAscentForgetter`, `EWCConsolidation`,
`FisherInformation`, `MemoryTraceMapper`, `ExperienceEngine`,
`ContextualBanditSelector`, `StrategyMemory`, `RuleExtractor`,
`StrategyEvolution`, `MetaKnowledge`, `UnlearningEvaluator`
(`composite_score`, `_mia_privacy_score`), `evaluation/mia_evaluator.py`
in full, `data/dataset_utils.py`'s `load_*` functions, `config.py` /
`schemas.py`. Any change here should carry: reason, which invariant
(G) it touches, a regression test, a before/after comparison, and an
explicit statement of impact on existing scored results — mirroring
what §22, §24, §29, §30 already did for past Core changes.

---

## I. Freely Experimental

New `IDEAS.md` entries prior to pre-registration; new `run_*.py`
exploratory/diagnostic scripts that read Core but don't modify it; new
dataset loaders following the independence pattern in D.1/D.2 (with
their own explicit overlap test, closing the E.1 gap for that loader at
least); new conceptual metaphors as documentation only (Idea 2, Idea
13). This is where a metaphor or an AI-review suggestion should live
first, per the Evidence Boundary below.

---

## J. Soil

`IDEAS.md` (resolved/held ideas kept as trimmed stubs, not deleted —
already this file's own stated policy); `docs/external_reviews/` (9
rounds archived verbatim); `precommit/` (7 files — immutable historical
record of what was decided before data collection); `seed_results/` (10
`.jsonl` files — raw empirical record); `main.py` /
`run_real_experiment.py` / `run_instance_level_experiment.py` — still
functional, still the only call sites for `MIAEvaluator`, but outside
the active pre-registered-comparison workflow every `run_*_comparison.py`
script uses.

---

## Evidence Boundary — applied to this document

- **Verified Fact** (this session, direct observation): D.1-D.8.
- **Potential / Not Yet Guaranteed**: E.1-E.4 — stated as gaps, not
  claimed as either present or absent.
- **Risk** (pattern observed, not yet mitigated): F.1-F.6.
- **Hypothesis** (untested): whether the calibration-mismatch pattern
  (F.1) would also appear in some *fourth* not-yet-tried mechanism —
  plausible given three prior instances, not confirmed as general.
- **Metaphor**: none introduced in this document. The Core/Experimental/
  Soil framing itself is treated here as an *organizational lens*
  applied to already-observed code facts, not as a claim about the
  code having ecological properties.
- **AI Review vs. Evidence**: this document does not cite any external
  review's *opinion* as support for any claim above — every D/E/F item
  above traces to a specific file, test, or grep run this session.
  Where ARCHITECTURE.md's own past sections are mentioned (F.1, F.4),
  they are cited as *prior findings already backed by their own
  evidence*, not as authority in themselves.

---

## Open Questions / Remaining Gaps (for review, not for autonomous action)

1. Should E.1 (identity-level forget/retain/test overlap tests for the
   digits loaders) be closed before any other Core work, given it's the
   most direct gap relative to this request's explicit invariant list?
2. Should E.2 get an explicit regression test (e.g., asserting
   `StrategyMemory` exposes no persistence method) so an architectural
   change would fail loudly rather than silently?
3. Is F.3 (config fingerprinting, `IDEAS.md` Idea 5) worth promoting
   ahead of new research threads, given it's infrastructure that makes
   *every future* Core change safer to reason about?
4. How should F.6 (environment fragility) be handled going forward —
   more frequent manual checkpointing, or is the current practice
   sufficient given no shipped state has actually been lost?
5. Whether the Absolute Protection / Core / Experimental / Soil
   boundaries proposed in G-J are the right cut, or need adjustment
   once reviewed externally.

This document stops here, per instruction. No code changes were made.
No next-phase design (Loop Engineering, new architecture, CLAUDE.md
finalization, new experiments) follows automatically.
