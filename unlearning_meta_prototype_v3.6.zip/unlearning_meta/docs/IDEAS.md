# IDEAS.md — Unverified Hypotheses and Future Directions

Companion to `ARCHITECTURE.md`. Split out on 2026-08-11 so the two
documents can serve different purposes cleanly:

- **ARCHITECTURE.md** records only what has actually been implemented
  and empirically checked — design decisions, code, tests, and results
  from runs that have actually happened. If it's in ARCHITECTURE.md, it
  ran, and the numbers are what that run produced.
- **IDEAS.md** (this file) holds proposed mechanisms, open questions,
  and pre-registered-but-not-yet-executed study designs — things that
  are plausible, motivated, and possibly already partially scoped, but
  not yet backed by a completed result. An idea graduates out of this
  file into ARCHITECTURE.md once it has one (with data, either way —
  a clean null result is still a graduation, not a failure to record).

Previously, sections like §20 mixed "what we built and checked" with
"what we plan to check next" in the same narrative. That's still fine
for the *implementation* half (design rationale belongs with the code
it explains), but forward-looking hypotheses and not-yet-run
pre-registrations now live here instead, so a reader of ARCHITECTURE.md
is never left guessing whether a given claim is a finding or a plan.

**Status tags:** 🔵 proposed, not started · 🟡 pre-registered / scoped, not yet run · ✅ resolved, see ARCHITECTURE.md § — · ❌ tested, no meaningful effect found, see ARCHITECTURE.md § —

---

## Idea 1 — Per-layer epsilon normalization: does it improve *average* performance, not just fix the one known failure? ❌ resolved — see ARCHITECTURE.md §23

**Resolution (2026-08-11):** Stage 1 (n=15 fresh seeds, 7000-7014) found
Cohen's d=-0.1834 — small and directionally negative — implying a Stage 2
n of 233 against the pre-registered ceiling of 80. Per the plan's own
advance instruction, this is "no practically meaningful effect detected"
and Stage 2 was not run. Zero catastrophic failures in either condition
on this fresh batch, so the read is clean and uncontaminated by the
seed=1004 case.

This does not reopen the seed=1004 fix itself (ARCHITECTURE.md §22),
which remains verified independently of this result. Full writeup,
pre-registration text, and the honest combined picture:
ARCHITECTURE.md §23.

*(Detail trimmed here now that this has a result — see the philosophy
note at the top of this file. Kept as a stub rather than deleted, so
this file's history of what was proposed and how it resolved stays
intact.)*

---

## Idea 2 — 💡 概念モデル: Glymphatic-inspired Clearance Hypothesis（グリンパティックに着想を得たクリアランス仮説）🔵

**ステータス:** 未検証・将来の拡張アイデア（※本番コード・ARCHITECTURE.mdには未反映）
**目的:** 選択的忘却（Unlearning）をより高度に抽象化し、システム全体の恒常性を維持するための次世代アーキテクチャの理論的基盤とする。

### 概要
生物学におけるGlymphatic system（脳内の老廃物クリアランスと恒常性維持機構）の知見を、AIの選択的アンラーニング（忘却）を設計するための概念的アナロジーとして導入する構想。
本システムにおける「忘却」を、単純なデータの削除ではなく、「学習系から不要な情報を選択的に排出し、システムの可塑性と恒常性（Homeostasis）を維持する」ための **Memory Clearanceプロセス** として位置づける。

### 1. メタファーのマッピング（具体と抽象の対応）
* **不要物 (Waste):** Forget対象のMemory Trace（`selectivity_weights` が高いパラメータ）
* **AQP4 / 透過性:** Clearance Gate（選択性の強度マスク）
* **Glymphatic Wash (流れ):** Gradient Ascentによる忘却エネルギー（勾配の更新）
* **恒常性 (Homeostasis):** Retain性能（保持精度）の維持

### 2. システムアーキテクチャへの統合構想（抽象レイヤー）
将来的な拡張として、忘却エンジンを巨大な単一モジュールとするのではなく、`MemoryClearancePolicy` という抽象インターフェース（Strategyパターン）として再設計するアイデア。
これにより、複数のクリアランス手法を同一の枠組みで評価・比較可能にすることを目指す。

```python
class MemoryClearancePolicy:
    """記憶の排出と恒常性維持を司る抽象基底クラス"""
    pass

class SelectiveClearancePolicy(MemoryClearancePolicy):
    """勾配への選択的マスクに基づくクリアランス (現在のStage 1のアプローチ相当)"""
    pass

class FisherClearancePolicy(MemoryClearancePolicy):
    """Fisher情報量に基づくクリアランス"""
    pass
```

### 3. 情報と忘却のフロー構造
システム内における経験から忘却までのプロセスを、以下のフローとして構造化する。現在検証中の「Gradient Ascentへの選択的適用」は、将来的にClearanceプロセスの中核（Selectivity → Gradient Ascent）として位置づけられる。

```
                Experience
                     │
                     ▼
              Memory Trace
                     │
          ┌──────────┴──────────┐
          ▼                     ▼
    Consolidation          Clearance
    (記憶の保持)             (不要物の排出)
          │                     │
          │              ┌──────┴──────┐
          │              │             │
          │          Selectivity    Retain Guard
          │          (排出経路の選択)  (恒常性の保護)
          │              │             │
          │              ▼             │
          │        Gradient Ascent ◄───┘
          │        (勾配による洗い流し)
          └──────┬───────┘
                 ▼
             Reflection
                 │
                 ▼
          Strategy Evolution
```

### 4. 計算ロジックへの落とし込み（具体レイヤー）
最下層のテンソル計算レベルにおいて、このクリアランス機構は「勾配に対する非線形または線形なマスク処理」として具現化される想定。
オプティマイザの更新直前に、各パラメータの重要度（老廃物スコア）に基づき、洗い流しの経路を動的に開閉する。

```python
# エンジンルーム（PyTorch）におけるクリアランスの将来的な具体実装イメージ
# param.grad *= clearance_rate (0.0=保護, 1.0=完全排出)
```

*(この節はユーザー提供の構想を内容そのまま記録したものです。見出し階層とコードフェンスのみ、このファイル内での表示崩れを防ぐために補完しました。用語・生物学的アナロジーの妥当性、およびコード例はいずれも未検証であり、ARCHITECTURE.mdの記録基準〔実装・実行済みの事実のみ〕の対象外です。)*

---

## External Review Round 3 (2026-08-11) — Gemini and ChatGPT

Both reviewers were given ARCHITECTURE.md (through §23) and IDEAS.md
(Idea 1 resolved; Idea 2). Full raw text archived at
`docs/external_reviews/round3_gemini.txt` and
`docs/external_reviews/round3_chatgpt.txt`. Both independently converged
on the same headline recommendation — and it happens to match what this
project's own §21.3 already flagged as the natural next question,
before either review was requested: does wiring `selectivity_weights`
into the gradient ascent step itself (not just noise injection, §20's
approach) produce a detectable effect where §21's noise-only
application did not? That convergence — one internal source (§21.3) and
two independent external reviewers, arriving at the same next step by
different routes — is a reasonable basis for prioritizing it. Logged as
**Idea 3** below.

The two reviews otherwise emphasized different things. The ChatGPT
review is the more actionable one for this project's existing empirical
machinery — it engages directly with specific numbers already in this
document (Cohen's d=-0.114 from §21, d=-0.1834 from §23, Kendall's
W=0.044 for Rule Extraction) and proposes a concrete factorial design
(folded into Idea 3) plus several methodology/tooling improvements
(Ideas 4-6). The Gemini review engages more with Idea 2's Glymphatic
metaphor directly and proposes formalizing it into a
`MemoryClearancePolicy` abstraction now (Idea 7) — see that idea's entry
for why this project is holding off on the timing, not the idea itself.

Where both reviews land on already-settled ground, no new idea was
opened: both independently validate the §22/§23 Fisher Forgetting
discipline ("seed=1004 fixed" ≠ "generally improved" — exactly what the
pre-registered fresh-seed design in §23 was built to avoid claiming),
and the ChatGPT review independently reaches the same conclusion this
project already had for Rule Extraction (Kendall's W=0.044, weak
contribution, not worth sophisticating further) and for speculative
extensions generally — explicitly recommending they be isolated in
IDEAS.md rather than built, which is exactly this file's purpose.

---

## Idea 3 — Selective Gradient Ascent: wire `selectivity_weights` into the ascent step itself ❌ resolved — see ARCHITECTURE.md §24

**Resolution (2026-08-11):** Implemented as `selective_ascent_enabled`
(calibrated: raw selectivity measured at ~0.5±0.03, so normalized to
[0,1] before applying alpha/beta — see §24.1 for why the raw range would
have been too narrow to fairly test), covered by 13 new tests. Tested
via a pre-registered 2x2 factorial isolating ascent selectivity's effect
from noise selectivity's (exactly the design proposed below). Stage 1
(n=15) found Cohen's d=+0.0842 for the primary Effect_ascent contrast,
implying a Stage 2 n of 1,105 against the pre-registered ceiling of 80 —
"no practically meaningful effect detected," Stage 2 not run.

This is despite both external reviews below AND ARCHITECTURE.md §21.3
converging on this as the well-motivated next step — worth sitting with
rather than glossing over: convergent expert prediction is a reasonable
basis for prioritizing what to test, not evidence about what the test
will find. §24.4 offers a specific next hypothesis (the null may reflect
this benchmark's instance-level forget/retain split giving
`MemoryTraceMapper` little genuine signal in the first place, independent
of noise vs. ascent) — untested, points toward class-level generalization
(§19.4) rather than a further noise/ascent variant.

Full writeup, pre-registration text, and the 2x2 result table:
ARCHITECTURE.md §24.

*(Detail trimmed here now that this has a result — see the philosophy
note at the top of this file.)*

---

## Idea 4 — Failure-mode-centric metrics as standard practice, not just mean/std 🔵

**Origin:** ChatGPT review. §22/§23 already tracked catastrophic-failure
counts descriptively for Fisher Forgetting specifically. This idea is
about making `P(retain_acc < retain_floor)` — not just mean score and
its std — a standard tracked quantity for *every* future comparison in
this project, on the reasoning that "good on average" and "safe in the
worst case" are different claims, and this project's own retain_floor
guardrail exists precisely because the worst case matters here.

**Status:** Proposed. Cheap to adopt (it's a reporting/analysis
convention, not new machinery) — natural to fold into whichever
comparison script Idea 3 ends up using.

---

## Idea 5 — Per-cycle observability logging + experiment config fingerprinting 🔵

**Origin:** ChatGPT review. Two related tooling proposals: (1) log full
per-cycle state (selected_action, score before/after, forget_acc,
retain_acc, selectivity mean/min/max, gradient norm, gradient clip,
noise norm, momentum state/patience, bandit UCB values) so a specific
cycle's behavior change ("cycle 11: bandit picked decrease_grad_clip ->
momentum released -> ascent gradient norm jumped 2.8x -> retain_acc
0.96->0.91") is traceable after the fact rather than only visible in
aggregate; (2) save a config fingerprint (which mechanisms were on/off)
per experiment run, since the number of interacting toggles (bandit,
momentum, reflection, selective noise, selective ascent, Fisher,
per-layer normalization) is now large enough that "which configuration
produced this result?" is a real risk without one.

**Status:** Proposed. Engineering/tooling improvement, not a research
hypothesis — low risk, adoptable independently of Idea 3.

---

## Idea 6 — Reflection ON/OFF ablation 🔵

**Origin:** ChatGPT review, drawing an explicit parallel to Rule
Extraction's already-measured weak contribution (Kendall's W=0.044):
apply the same discipline to Reflection before investing in making it
"smarter" — compare Full system vs. Full-minus-Reflection first, rather
than assuming Reflection is pulling its weight.

**Status:** Proposed. Independent of Idea 3; cheaper to run (existing
mechanism, on/off toggle, no new implementation) if bandwidth allows it
alongside or before Idea 3.

---

## Idea 7 — `MemoryClearancePolicy` Strategy-pattern refactor (formalizing Idea 2) 🔵 — deferred

**Origin:** Gemini review, building directly on Idea 2's metaphor:
refactor `FisherForgettingBaseline` and `GradientAscentForgetter` into
a common `MemoryClearancePolicy` interface so multiple "clearance"
methods can be swapped and compared within one framework.

**Why this project is holding off on the timing, not the idea itself:**
every successful change documented in ARCHITECTURE.md so far (§14, §16,
§20, §22) has been small, motivated by a concrete, already-identified
need, and isolated to one toggle at a time — the opposite of a
speculative architecture-wide refactor done for elegance ahead of need.
Right now there is exactly one clearance mechanism in production
(`FisherForgettingBaseline`) plus one proposed-not-yet-built one (Idea
3's selective ascent) — not yet enough concrete, comparable policies to
make a shared interface pay for itself, and refactoring working, tested
code (34/34 passing) purely in anticipation of that need risks exactly
the kind of scope-creep this project has consistently avoided. Revisit
once Idea 3 exists as a real, working alternative mechanism worth
comparing programmatically against Fisher Forgetting — at that point
the abstraction is motivated by an actual need instead of anticipated
elegance.

**Status:** Proposed, explicitly deferred pending Idea 3.

---

## Idea 8 — Unlearning as a route to creative "lateral" recombination 🔵 — held, very low priority

**Origin:** ChatGPT review, explicitly distinct from Idea 2 (this is an
application hypothesis, not an architecture metaphor): does removing
fixed/entrenched associations (unlearning) enable novel recombination of
remaining knowledge (a "creativity via forgetting" hypothesis)? The
reviewer's own assessment, which this project agrees with: current
results give no basis for this claim, it does not belong in the
research core, and it is explicitly the kind of thing this file exists
to hold rather than either building it prematurely or losing the idea
entirely.

**Status:** Proposed, held. No pre-registration, no design — recorded
only so it isn't lost, per the reviewer's own framing.

---

## External Review Round 4 (2026-08-13) — ChatGPT and Gemini on the §24 null result

Both reviewers were given ARCHITECTURE.md through §24 (the Selective
Gradient Ascent null result). Full raw text archived at
`docs/external_reviews/round4_chatgpt.txt` and
`docs/external_reviews/round4_gemini.txt`. Both are strongly validating
of §24's process (the 2x2 design, the pre-registered stopping rule, and
specifically the decision to record the null honestly rather than treat
convergent prior predictions as license to keep tuning until something
significant turned up) — no new idea was opened for those points, since
they confirm decisions already made rather than propose new ones.

Both also independently reach the same next-step recommendation §24.4
already pointed at: class-level generalization (§19.4), not a further
noise/ascent variant. The ChatGPT review adds a genuinely useful
refinement over §24.4's own framing, worth adopting rather than just
noting: don't jump straight to "does selectivity improve performance on
class-level forgetting" (which repeats the same mistake this round's own
review criticized elsewhere — testing a mechanism's downstream effect
before checking whether its *input signal* is even present). Check the
input first. `MemoryTraceMapper`'s selectivity has now been tested at
two different downstream connections (noise, ascent) with no detected
effect from either — the reviewer's point is that this is starting to
look less like "wrong mechanism" and more like "the signal itself may be
too narrow for this benchmark," which is a claim about
`MemoryTraceMapper`'s *output*, not about anything downstream of it, and
is directly, cheaply checkable before building anything new. Logged as
**Idea 9** below, structured as the reviewer's own two-phase split.

Both reviewers also re-endorse Idea 5 (per-cycle logging + config
fingerprinting) independently of the ChatGPT review that first proposed
it in round 3 — now recommended by both AI reviewers across two
different rounds. No new idea needed, but this is a second, independent
vote for treating it as adoptable infrastructure work rather than
something to keep deferring indefinitely.

---

## Idea 9 — Selectivity Generalization Test: does the *signal itself* carry more information for class-level than instance-level forgetting? ❌/⚠️ resolved — see ARCHITECTURE.md §25 (Phase 1), §26 (Phase 2)

**Resolution (2026-08-13):** Phase 1 confirmed the signal itself
generalizes dramatically (class-level selectivity std 9.76x
instance-level's). Phase 2 then tested whether that richer signal
translates into better forgetting performance — pre-registered 2x2
factorial, both mechanisms treated as primary since neither had been
tested on class-level before.

**Selective ascent: still null.** Stage 1 (n=15): d=+0.22, implied
Stage 2 n=94,939 — closed, no Stage 2. Richer signal did not rescue this
mechanism; the more parsimonious read now is that scaling the ascent
gradient by selectivity specifically doesn't move this benchmark's
outcome, independent of signal quality.

**Selective noise: a confirmed, significant, HARMFUL effect** — the
notable finding of this idea, and the first properly-powered significant
result across every selective-mechanism comparison in this document.
Stage 1 (n=15): d=-0.83 → Stage 2. Stage 2 (n=30, confirmatory):
mean=-0.0351, t(29)=-4.13, p=0.00028, d=-0.754, 95% CI=[-0.053,-0.018].
Selective noise measurably *hurts* class-level forgetting performance
relative to uniform noise. §26.4 offers a specific, checkable candidate
explanation (raw, unnormalized selectivity has a lower mean on
class-level — 0.30 vs. instance-level's 0.50 — so under `noise_scale`
calibrated for roughly-uniform application, selective noise ends up
systematically under-strength, not a sign the underlying idea is
unsound) — not independently verified.

Full writeup, both pre-registrations, and both result sets:
ARCHITECTURE.md §25 and §26.

*(Detail trimmed here now that this has a result — see the philosophy
note at the top of this file.)*

---




## Idea 10 — Mean-preserving normalization for BOTH mechanisms ✅/❌ resolved — see ARCHITECTURE.md §28

**Resolution (2026-08-15):** Tested exactly as designed below — one
normalization scheme fixed in advance (mean-normalization), both
questions asked separately (N vs R, N vs U), n=45 reusing §26's
already-collected U/R data. **Noise:** confirmed — `N_noise`
significantly beat `R_noise` (p=0.0003, d=+0.591, 95%
CI=[+0.020,+0.062]), validating §26.4/§27.2's calibration-gap
hypothesis. But `N_noise` did not significantly beat `U` (p=0.088,
d=+0.260, CI=[-0.002,+0.029]) — the fix removed the harm without
producing a benefit; mean-normalized selective noise is statistically
neutral relative to uniform on this benchmark. **Ascent:** null on both
comparisons (vs. R_ascent: p=0.078, d=-0.269, CI touching zero; vs. U:
p=0.999, d=+0.000) — mean-normalization does not rescue selective
ascent, suggesting its null is a property of the mechanism rather than a
calibration artifact, unlike noise's.

Full writeup, pre-registration text, and all four results:
ARCHITECTURE.md §28.

*(Original design detail kept below rather than trimmed to a stub, since
it documents the two methodological fixes — one scheme, two questions —
that made this a clean test; see the philosophy note at the top of this
file for why completed ideas aren't deleted.)*

**Origin:** ARCHITECTURE.md §26.4's candidate explanation for why
selective noise confirmed harmful on class-level forgetting (§26,
d=-0.754), broadened after §27 found the same underlying gap in
selective ascent's existing normalization. `to_parameter_weights()`
(noise) passes raw, unnormalized selectivity directly into the noise
multiplier — mean 0.30 on class-level vs. 0.50 on instance-level (§25) —
so under a `noise_scale` calibrated assuming roughly-uniform
application, aggregate noise strength is diluted to ~0.30x on
class-level. `to_ascent_weights()` (ascent, §24.1) already normalizes,
but only fixes the *range* (min-max to [0,1]) — a linear rescaling
preserves the underlying distribution's *skew*, and class-level
selectivity is heavily right-skewed (§25.2: median well below mean), so
the aggregate ascent multiplier still lands around ~0.83x, not the
intended neutral 1.0 (§27.2, checked directly on 3 seeds). Both
mechanisms are diluted by the same underlying cause; ascent less
severely, because its `beta=0.5` floor bounds how low any single
parameter's multiplier can go, unlike noise's unfloored raw weight.

**Hypothesis:** a normalization that preserves the selectivity
distribution's *mean* (not just its range) — e.g. rescaling so the
distribution's own mean maps to the neutral point (1.0 for ascent's
`alpha*s+beta` form; a task-independent reference for noise's
multiplicative form) regardless of skew — would remove or substantially
shrink §26's harmful noise effect, AND for the first time give selective
ascent a test where its aggregate strength isn't quietly diluted
relative to uniform ascent, on a task where the underlying signal (§25)
is known to be rich. Both are the same fix now, not two.

**Why this is a real hypothesis and not just a patch to chase away an
inconvenient result:** §26.4 and §27.2's explanations were both written
down as accounts of results already fully accepted and documented (§26
and §24 both stand regardless of whether this idea is ever tested); this
idea proposes one specific, mechanistically-motivated fix applied
consistently to both mechanisms, with a falsifiable prediction (noise's
harmful effect should shrink; ascent's near-zero effect might finally
move, in either direction, once it isn't systematically diluted) — not a
search for whatever change flips either sign.

**Two refinements from external review round 5 (ChatGPT), adopted
before this idea is run, not after seeing a result:**

1. **Fix one normalization scheme in advance.** There is more than one
   way to make a distribution's mean land at a neutral point (mean
   normalization: `weight / mean(weight)`; min-max to a symmetric range
   like [0.5, 1.5] recentered on the *mean* rather than the *midpoint*;
   variance-preserving transforms). Trying several and reporting
   whichever one moves the result is exactly the kind of researcher
   degrees of freedom this document's pre-registration discipline exists
   to close off. Whichever pre-registration eventually covers this idea
   commits to exactly one scheme (mean normalization is the current
   default choice, as the simplest one that directly targets the
   diagnosed mechanism — the distribution's mean, not its shape) before
   any comparison data is collected, matching this document's standing
   practice for every prior precommit.

2. **Two different questions, not one.** "Does normalizing shrink or
   remove §26's harmful effect" (normalized vs. raw selective noise) is
   a narrower claim than "does selectivity-weighted noise, once
   correctly calibrated, actually beat uniform noise" (normalized vs.
   uniform). A result confirming only the first should not be reported
   as confirming the second. Any pre-registration for this idea commits
   to both comparisons (Uniform / Raw-selective / Mean-normalized-
   selective, three conditions, not two) rather than treating "the
   harmful effect went away" as equivalent to "selectivity weighting is
   beneficial."

A cheap diagnostic step this idea would otherwise open with — computing
each condition's actual average effective weight from already-collected
data, before running anything new — is already substantially answered:
§26.4 established raw selective noise's average multiplier at ~0.30 on
class-level (§25's measured mean, which is also the covered-parameter
average `to_parameter_weights()` produces, since that function performs
no transform beyond broadcasting); §27.2 established selective ascent's
average multiplier at ~0.83 under its *current* (range-only)
normalization. What is not yet computed is the analogous number under
the *proposed* mean-normalization scheme for either mechanism — that
would be this idea's actual first step, not a repeat of §26.4/§27.2's
diagnostics.

**Status:** Proposed, not started. Would need its own pre-registration
covering, per mechanism: three conditions (Uniform / Raw-selective /
Mean-normalized-selective), one fixed normalization scheme decided in
advance, and both comparisons (N vs. R, N vs. U) analyzed as distinct
claims — on class-level forgetting, paired against §26's own
already-collected UU/SU/US/SS data by seed where possible, mirroring how
§24 reused §21's data.

---

## External Review Round 5 (2026-08-15) — ChatGPT and Gemini on §24-§27

Three reviews this round, archived in `docs/external_reviews/`:
`round5_chatgpt.txt` (v3.0, before §27), `round5_gemini_partial.txt`
(also labeled v3.0 by the person relaying it, but its content stops
mid-§22 — it appears to reflect a truncated upload rather than the
actual v3.0 content, since v3.0 already included §23-26; treated as a
partial/stale view rather than a substantively different assessment),
and `round5_gemini_on_v31.txt` (v3.1, reviewing §27 specifically).

The ChatGPT review is the substantive one this round, and it caught
something this document hadn't addressed: Idea 10, as originally
written, didn't commit to *which* normalization scheme to use, and
didn't separate "does normalizing remove the harmful effect" from "does
correctly-calibrated selective noise actually beat uniform" — two
different claims that a single comparison can't distinguish. Idea 10 is
revised above to close both gaps before any of its data is collected,
rather than after.

The truncated Gemini review (`round5_gemini_partial.txt`) asked whether
the seed=1004 Fisher Forgetting fix held up — it does (§22: retain_acc
0.9961 vs. the original 0.8775-triggered failure; §23 separately found
no general average-performance improvement, which doesn't affect the
specific-seed fix). It also raised two points not tied to any specific
open thread: whether "Meta-Learning" is still the right framing given
the system functions more like an adaptive contextual-bandit controller
than gradient-based meta-learning (a documentation/naming question, not
an empirical one — noted here rather than opened as an Idea, since
there's no experiment to pre-register); and dataset/model-size
generalization, which §19.4 already flagged as untested and which had
never been promoted to a tracked Idea until now — see Idea 11.

The v3.1 Gemini review strongly validated §27's approach (new section,
§26 left untouched) and independently drafted its own version of similar
content — not adopted verbatim since §27 already existed and covers the
same ground, but a useful independent confirmation that the approach
(and the finding itself) reads as sound to a reviewer encountering it
fresh.

---

## Idea 11 — Generalization beyond one dataset and one model size 🔵

**Origin:** ARCHITECTURE.md §19.4, flagged as an untested gap
("Model-size and dataset generalization remain untested") but never
promoted to a tracked Idea; independently re-raised by external review
round 5 (Gemini, partial view). Distinct from §25/§26's instance-level
vs. class-level generalization, which varied the *forgetting task*
structure on the same dataset and model — this is about varying the
*dataset* and *model size* themselves, which nothing in this document
has tested. Every result recorded so far — §17's confirmed dual-engine
effect, §21/§24's noise/ascent nulls, §26's confirmed harmful noise
effect — comes from exactly one architecture (`MLP(64,[128,64],10)`) on
exactly one dataset (sklearn digits).

**Status:** Exploratory check and root-cause decomposition done, see
ARCHITECTURE.md §31 — not yet confirmatory. A wine-dataset loader
(`load_wine_instance_forgetting`, `data/dataset_utils.py`) was added:
sklearn's bundled wine dataset (13 tabular features, 3 classes, 178
samples — differs from digits on every axis this project hadn't
varied: tabular not image, 3 not 10 classes, ~10x fewer samples),
mirroring `load_digits_instance_forgetting`'s design (stratified
per-class forgetting) for a like-for-like comparison of the same
benchmark type on different data. 7 tests in `tests/test_dataset_utils.py`.

**Result (§31):** an n=5 exploratory check found B (full adaptive
system) underperforming A (fixed hyperparameters) in all 5 seeds —
opposite of §17.4's confirmed digits result. A follow-up per-cycle
root-cause decomposition ruled out cross-run experience transfer
(structurally impossible in this architecture — `StrategyMemory` has no
persistence) and found the effect concentrated in 3/5 seeds where a
specific hyperparameter action (`noise_scale` reaching ~50x its
default) triggered the `retain_floor` guardrail — supporting
"exploration step sizes calibrated for digits' scale are proportionally
too large for wine's much smaller retain set" over "adaptation itself
is harmful." Not yet a confirmatory claim; no new mechanism (e.g.
scale-aware step sizing) has been proposed or built, per explicit
instruction pending a properly-powered follow-up design.

**Not yet done:** a pre-registered confirmatory design (mirroring
§17.4's own n=55 structure) and/or a diagnostic check of whether
recalibrating exploration step sizes for wine's scale changes the
floor-violation rate, analogous to §24.1's and Idea 10's calibration
fixes for a different mechanism.

---

## External Review Round 6 (2026-08-16) — ChatGPT on v3.2

Full review archived at `docs/external_reviews/round6_chatgpt.txt`. The
substantive finding — Shadow MIA data leakage — was verified directly
and fixed; see ARCHITECTURE.md §29 for the full account (found, traced
to confirm it affected no reported result, fixed, tested).

Two smaller terminology points, not opened as Ideas since neither is an
empirical hypothesis, recorded so they aren't lost before any future
paper writeup:

- **Rule Extraction is correlational, not causal**, and should be
  described that way. The current success check ("did composite_score
  improve in the cycle after this action") doesn't isolate the action's
  effect from everything else changing between cycles (replay, noise,
  momentum, gradient clipping, stochastic batching, Fisher, model
  state). The mechanism itself is unchanged and already correctly
  documented (§17's off-by-one fix); this is about how to describe what
  it measures, not a bug — "empirical strategy rules" or similar is more
  accurate than any framing implying causal attribution.
- **`generalization_score`'s name overstates what it currently
  measures** — a heuristic success-tracking score updated within a
  single task/context, not cross-task transfer. Directly connects to
  Idea 11 above: a name change alone doesn't need a pre-registration,
  but actually measuring generalization does, and that's already
  tracked there.

The "Meta-Learning" naming question was raised independently by this
review too (see round 5's synthesis above for the first instance) —
now two independent reviews converging on the same framing point. Still
not opened as an Idea for the same reason as before: it's a
documentation/naming question, not an experiment.

Also independently re-confirmed: the codebase reproduces (52/52 tests
passing in the reviewer's own environment at the time), and every
priority judgment already reflected in this file — defer
`MemoryClearancePolicy` (Idea 7), don't further tune Selective Ascent,
Idea 5/6/11 as the next reasonable threads — was reached independently
by this review too.

---

## Idea 12 — Dedicated RNG generator for ShadowMIA's train/eval split 🔵

**Origin:** External review round 6/7 (both ChatGPT and Gemini,
independently). `ShadowMIA._split_test_outputs()` (§29) uses the global
`torch.randperm` for its train/eval split. Both reviews noted, and both
explicitly marked as optional/not required for v3.3: a dedicated
`torch.Generator`, seeded independently of whatever else consumes random
state elsewhere in a run, would make the split itself directly
reproducible in isolation.

**Status:** Proposed, low priority, not started. No result currently
depends on this — `ShadowMIA` is not wired into any scored comparison
(§29.2) — so this is an engineering-quality improvement, not something
blocking any research thread.

---

## Idea 13 — Conceptual Metaphor: The Puppet Master (Project 2501, *Ghost in the Shell*) 🔵

**Status:** Conceptual metaphor / exploratory design idea. Not
implemented. Not a pre-registered hypothesis. No code, evaluation
protocol, experiment result, or README changed by this entry — this is
a documentation-only addition, explicitly requested as such.

**Idea / Concept:** Shirow Masamune's *Ghost in the Shell* — specifically
the Puppet Master (Project 2501) — as a structural, not literal,
metaphor for the relationship already implemented between this
project's two engines: a higher layer that does not itself execute the
task but intervenes in a lower layer's strategy by drawing on an
accumulated pool of past information.

**Motivation:** Distinct from Idea 2 (the Glymphatic-inspired Clearance
Hypothesis), which is a biological metaphor for the *clearance/forgetting
mechanism itself* (`GradientAscentForgetter`, noise injection). This
idea is about a different part of the architecture — the *control
hierarchy* between `ExperienceEngine` and `UnlearningEngine` — and does
not overlap with Idea 2's scope.

**Architectural Mapping** (structural correspondence only, per the
caveats below):

| Metaphor | This system |
|---|---|
| Puppet Master | `ExperienceEngine` / meta-controller — does not execute unlearning directly; observes metrics and past `Experience`/`StrategyRecord`s, then adaptively directs the lower layer's strategy and hyperparameters |
| The Net / sea of information | Accumulated `Experience` / unlearning history across cycles and tasks — the pool `ExperienceEngine` draws on |
| The puppet | `UnlearningEngine` — the execution layer that actually applies the strategy and hyperparameters it's given |
| The Ghost | The learned representations formed in the model during training — the thing selective unlearning tries to partially, precisely rewrite (remove forget-set influence) without destroying the whole. Explicitly NOT a claim that "Ghost = consciousness" or "model = a person" — see Caveats. |

**Research Implication:** The mapping suggests a design question worth
keeping distinct from whether the metaphor is apt: *having* past
experience and *whether it should be used* for the current task are not
the same thing. This is directly motivated by an actual (exploratory,
not yet confirmed) result already in this project's history: digits
showed Condition B (full adaptive system, using accumulated
experience/rules) outperforming Condition A (fixed hyperparameters,
confirmed at n=55, §17.4); an early wine-dataset exploratory check (5
seeds) showed the opposite direction in every seed (ARCHITECTURE.md
§31, which also found this specific case traces to exploration step
sizes rather than to using accumulated experience per se — still worth
recording as the observation that motivated this idea). If that pattern
holds up under proper confirmation, it suggests `ExperienceEngine`
might eventually need something like a fourth option alongside however
it currently decides to use, modify, or create a rule: to **skip**
using accumulated experience for a given task altogether, rather than
applying it unconditionally.

**Future Hypothesis (not implemented, not designed in detail):** a
future `ExperienceEngine` variant might decide, per task, among
`USE` / `MODIFY` / `CREATE` / `SKIP` for whether and how to draw on
accumulated experience — rather than always attempting to apply it.
This is recorded as a hypothesis this metaphor helped surface, not a
committed design; no interface, gating mechanism, or criterion for the
decision is proposed here.

**Caveats / Non-equivalence (explicit, per the metaphor's own limits):**
this metaphor does NOT claim or imply that `ExperienceEngine` has
consciousness, autonomous will or intent, or anything resembling a
persona or "ghost" in the sense the source fiction uses the term; does
NOT claim this system is technically equivalent to Project 2501 or any
other fictional AI; and does NOT treat the fictional work's internal
logic as scientific or engineering justification for anything in this
project. The mapping is offered only as a structural analogy — a
meta-controller that intervenes in a lower execution layer using a pool
of accumulated information — nothing more.
