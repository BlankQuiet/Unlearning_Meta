# Unlearning Meta-Learning Research Prototype
## Technical Documentation

---

## 1. Class Diagram (Mermaid)

```mermaid
classDiagram
    %% ─── Layer 1: Unlearning Engine ──────────────────────────────
    class UnlearningEngine {
        +model: MLP
        +config: UnlearningConfig
        +fisher: FisherInformation
        +ewc: EWCConsolidation
        +trace: MemoryTraceMapper
        +evaluator: UnlearningEvaluator
        +run_cycle(loaders, cycle) UnlearningMetrics
        +apply_strategy(StrategyUpdate) bool
        +save_checkpoint(path)
        +config_snapshot() Dict
    }

    class MemoryTraceMapper {
        +forget_mask: Dict
        +retain_mask: Dict
        +selectivity: Dict
        +compute(model, f_loader, r_loader)
        +overlap_score() float
    }

    class FisherInformation {
        +fisher: Dict[str, Tensor]
        +compute(model, loader) FisherInformation
        +importance_mask(percentile) Dict
        +privacy_risk_score() float
    }

    class GradientAscentForgetter {
        +model: Module
        +strength: float
        +run(forget_loader, ewc_fisher) Dict
        -_ewc_penalty() Tensor
        -_inject_noise()
    }

    class DreamReplayer {
        +dream_count: int
        +run(retain_loader) Dict
        -_collect_dreams() Tuple
        -_replay(dream_x, dream_y) float
    }

    class CorrectionReplayer {
        +run(retain_loader, fisher) Dict
        -_ewc_penalty() Tensor
    }

    class EWCConsolidation {
        +reference: Dict
        +fisher: Dict
        +ewc_lambda: float
        +register(fisher)
        +penalty(model) Tensor
        +update_reference(model)
    }

    class UnlearningEvaluator {
        +evaluate(loaders, cycle) UnlearningMetrics
        -_accuracy(loader) float
        -_hallucination_rate(loader) float
        -_mia_privacy_score() float
        -_stability_score() float
    }

    %% ─── Layer 2: Experience Engine ──────────────────────────────
    class ExperienceEngine {
        +journal: MemoryJournal
        +reflector: SelfReflection
        +explainer: SelfExplainer
        +extractor: RuleExtractor
        +memory: StrategyMemory
        +evolver: StrategyEvolution
        +meta: MetaKnowledge
        +process(metrics) StrategyUpdate
        -_propose_strategy() StrategyUpdate
        +report() Dict
        +top_rules(n) List
    }

    class MemoryJournal {
        +entries: Deque[JournalEntry]
        +add(cycle, metrics, strategy) JournalEntry
        +last_n(n) List
        +strategy_outcomes() Dict
        +failure_frequency() Dict
    }

    class SelfReflection {
        +reflect(journal, cycle) ReflectionReport
        -_detect_failures(metrics) List
        -_classify_trend(scores) str
        -_suggested_focus() str
    }

    class SelfExplainer {
        +explain(metrics, reflection, proposal) str
    }

    class RuleExtractor {
        +extracted_rules: List[StrategyRecord]
        +extract(journal, cycle) List[StrategyRecord]
        -_cluster_by_threshold() List
        -_should_merge() bool
    }

    class StrategyMemory {
        +records: Dict[str, StrategyRecord]
        +add(record)
        +query(metrics, state) List[StrategyRecord]
        +record_outcome(id, success, cycle)
        +run_lifecycle(cycle) Dict
    }

    class StrategyEvolution {
        +evolve(memory, cycle) int
        -_run_one_round() int
        -_cluster_by_threshold() List
        -_merge(cluster) StrategyRecord
    }

    class MetaKnowledge {
        +action_stats: Dict[str, ActionStats]
        +best_score: float
        +update(action, metrics, delta, success)
        +ucb_score(action) float
        +best_action_for(failure) StrategyAction
        +recommended_delta(action) float
    }

    %% ─── Shared Types ─────────────────────────────────────────────
    class UnlearningMetrics {
        +forget_acc: float
        +retain_acc: float
        +accuracy: float
        +privacy: float
        +hallucination: float
        +stability: float
        +cycle: int
        +composite_score() float
    }

    class StrategyUpdate {
        +action: StrategyAction
        +delta: float
        +rationale: str
        +confidence: float
        +source_rule: str
        +is_noop() bool
    }

    class StrategyRecord {
        +id: str
        +rule: str
        +action: StrategyAction
        +success_rate: float
        +generalization_score: float
        +usage_frequency: int
        +last_used: int
        +state: StrategyState
        +importance() float
        +matches(metrics) bool
    }

    %% ─── Relationships ────────────────────────────────────────────
    UnlearningEngine --> MemoryTraceMapper
    UnlearningEngine --> FisherInformation
    UnlearningEngine --> GradientAscentForgetter
    UnlearningEngine --> DreamReplayer
    UnlearningEngine --> CorrectionReplayer
    UnlearningEngine --> EWCConsolidation
    UnlearningEngine --> UnlearningEvaluator
    UnlearningEngine ..> StrategyUpdate : receives proposal
    UnlearningEngine --> UnlearningMetrics : produces

    ExperienceEngine --> MemoryJournal
    ExperienceEngine --> SelfReflection
    ExperienceEngine --> SelfExplainer
    ExperienceEngine --> RuleExtractor
    ExperienceEngine --> StrategyMemory
    ExperienceEngine --> StrategyEvolution
    ExperienceEngine --> MetaKnowledge
    ExperienceEngine --> StrategyUpdate : produces
    ExperienceEngine ..> UnlearningMetrics : receives only

    StrategyMemory --> StrategyRecord
    RuleExtractor --> StrategyRecord
    StrategyEvolution --> StrategyMemory
    MetaKnowledge --> ActionStats
```

---

## 2. Module Dependency Diagram

```
unlearning_meta/
│
├── config.py               ← no internal deps
├── schemas.py               ← no internal deps
│
├── models/
│   └── base_model.py       ← no internal deps
│
├── data/
│   └── dataset_utils.py    ← no internal deps
│
├── modules/
│   ├── unlearning/
│   │   ├── memory_trace.py     ← types
│   │   ├── fisher_information.py ← (none)
│   │   ├── gradient_ascent.py  ← (none)
│   │   ├── dream_replay.py     ← (none)
│   │   ├── correction_replay.py← (none)
│   │   ├── ewc_consolidation.py← (none)
│   │   └── evaluator.py        ← types
│   │
│   └── experience/
│       ├── memory_journal.py   ← types
│       ├── self_reflection.py  ← types, memory_journal
│       ├── self_explanation.py ← types, self_reflection
│       ├── rule_extraction.py  ← types, memory_journal
│       ├── strategy_memory.py  ← types
│       ├── strategy_evolution.py ← types, strategy_memory
│       └── meta_knowledge.py   ← types
│
├── engines/
│   ├── unlearning_engine.py  ← config, types, modules/unlearning/*
│   └── experience_engine.py  ← config, types, modules/experience/*
│
├── evaluation/
│   ├── mia_evaluator.py      ← (none)
│   └── metrics.py            ← types
│
└── utils/
    ├── logger.py             ← types
    └── visualization.py      ← evaluation/metrics
```

**Dependency direction:** always downward. No circular imports.

---

## 3. Learning Loop (Pseudocode)

```
ALGORITHM: Dual-Engine Unlearning Meta-Learning

INPUT:
  M   ← pre-trained model
  D_f ← forget dataset
  D_r ← retain dataset
  D_t ← test dataset
  N   ← number of cycles

INITIALISE:
  θ_UE ← UnlearningConfig (hyperparameters)
  S    ← StrategyMemory (empty)
  J    ← MemoryJournal (empty)
  K    ← MetaKnowledge (empty)

FOR cycle = 1 to N:

  ── LAYER 1: Unlearning Engine ──────────────────────────────────
  1.  trace ← MemoryTraceMapper(M, D_f, D_r)
  2.  F     ← FisherInformation(M, D_r)         // diagonal Fisher
  3.  EWC   ← EWCConsolidation(M, F, λ=θ_UE.ewc_lambda)

  4.  FOR epoch = 1..θ_UE.forget_epochs:         // Gradient Ascent
        ℓ = -θ_UE.strength · CE(M(x_f), y_f)
            + λ · Σ F_i(θ_i - θ_i*)²            // EWC penalty
        θ ← θ - η∇ℓ

  5.  AddNoise(M, std=θ_UE.noise_scale)

  6.  FOR epoch = 1..θ_UE.dream_epochs:          // Dream Replay
        x̂, ŷ ← M.high_confidence_predictions(D_r)
        θ ← θ + η∇CE(M(x̂), ŷ)

  7.  FOR epoch = 1..θ_UE.correction_epochs:     // Correction Replay
        θ ← θ + η∇CE(M(x_r), y_r)

  8.  metrics ← Evaluate(M, D_f, D_r, D_t)
      // {forget_acc, retain_acc, accuracy, privacy, hallucination, stability}

  ── LAYER 2: Experience Engine ──────────────────────────────────
  9.  J.add(cycle, metrics, last_proposal)
  10. reflection ← SelfReflection(J)
  11. new_rules  ← RuleExtractor(J)
  12. S.add(new_rules)
  13. StrategyEvolution(S)   // merge similar rules
  14. S.run_lifecycle(cycle) // Active→Dormant→Archive→Delete

  15. proposal ← SELECT_STRATEGY(metrics, reflection, S, K):
        // Tier 1: best matching rule from S
        // Tier 2: UCB recommendation from K
        // Tier 3: ε-random exploration
  
  16. explanation ← SelfExplainer(metrics, reflection, proposal)
  17. K.update(proposal.action, metrics, Δscore, success)

  ── Apply proposal ──────────────────────────────────────────────
  18. θ_UE ← θ_UE + APPLY(proposal)
      // ONLY adjusts hyperparameters, NOT model weights

RETURN M, J, S, K
```

---

## 4. Strategy Memory Design

### State Transitions

```
            usage resumes
  ┌─────────────────────────────────────────────┐
  ▼                                             │
ACTIVE ──(unused ≥ dormant_after cycles)──► DORMANT
  ▲                                             │
  │                                             │ (unused ≥ archive_after)
  │ importance                                  ▼
  │ rises             ┌───────────────────► ARCHIVE
  └───────────────────┘                         │
                                                │ importance < threshold
                                                ▼
                                            DELETED
```

### Importance Formula

```
importance(r, t) =
    0.35 × success_rate(r)
  + 0.25 × generalization_score(r)
  + 0.20 × recency(r, t)          // 1 - (t - last_used) / t
  + 0.20 × usage_freq(r)          // min(1, freq / 100)
```

Deletion trigger: `importance < importance_threshold (default 0.25)`

---

## 5. Rule Extraction Algorithm

```
FUNCTION extract_rules(Journal J, window W, min_obs K, conf_thresh τ):

  recent ← J.last_n(W)
  pairs  ← [(J[i], J[i+1]) for i in 0..len(recent)-2]
  candidates ← {}

  FOR (before, after) IN pairs:
    IF before.strategy IS NULL: continue
    action ← before.strategy.action

    FOR metric IN [forget_acc, retain_acc, accuracy, privacy, ...]:
      FOR (op, thresh) IN THRESHOLDS[metric]:
        IF condition_satisfied(before.metrics, metric, op, thresh):
          key ← f"{metric}{op}{thresh}:{action}"
          IF score_improved(before, after):
            candidates[key].successes += 1
          ELSE:
            candidates[key].failures  += 1

  new_rules ← []
  FOR (key, cand) IN candidates:
    IF cand.total >= K AND cand.confidence >= τ:
      new_rules.append(StrategyRecord(cand))

  RETURN new_rules
```

---

## 6. Meta-Learning Extension Proposals

### 6a. MAML Integration (Model-Agnostic Meta-Learning)

Apply MAML to the Experience Engine's strategy selector:

```python
# Inner loop: adapt strategy to current task
fast_weights = strategy_selector.parameters()
for step in range(inner_steps):
    proposal = strategy_selector(metrics, fast_weights)
    loss = -composite_score(apply_and_eval(proposal))
    fast_weights = fast_weights - α * grad(loss)

# Outer loop: update meta-parameters across tasks
meta_loss = sum(eval_on_new_task(fast_weights) for task in task_set)
meta_optimizer.step(meta_loss)
```

### 6b. Bayesian Strategy Prior

Replace ε-greedy with a Thompson Sampling approach:

```python
# Model each action's success rate as Beta(α, β)
alpha[action] += success
beta[action]  += (1 - success)
# Sample from posterior for exploration
sampled_rate = Beta(alpha[action], beta[action]).sample()
```

### 6c. Continual Unlearning Curriculum

Gradually increase forgetting difficulty:
- Cycle 1–5:   forget 10% of forget set
- Cycle 6–15:  forget 50% of forget set
- Cycle 16+:   forget 100% of forget set

This mirrors curriculum learning and lets the Experience Engine
build rules incrementally before facing the full problem.

### 6d. Cross-Task Rule Transfer

When starting a new forgetting task (new forget class):
- Initialise StrategyMemory from a pre-trained rule base
- Trust rules with `generalization_score > 0.7` immediately
- Validate task-specific rules with reduced `min_observations`

---

## 7. MIA Evaluation Protocol

### Experimental Setup

```
Pre-unlearning baseline:
  Train shadow classifier on (M_pretrained outputs, member/non-member labels)
  Record AUC_pre  ≈ 0.8–0.9  (model strongly memorises training data)

Post-unlearning target:
  Run MIAEvaluator on M_unlearned
  Record AUC_post ≈ 0.5      (model can no longer distinguish forget samples)

Privacy gain = AUC_pre - AUC_post
  > 0.2  → effective forgetting
  < 0.05 → forgetting failed
```

### Metrics

| Metric | Definition | Target |
|--------|------------|--------|
| Confidence AUC | ROC-AUC of confidence-based MIA | ≤ 0.55 |
| Shadow AUC | ROC-AUC of trained meta-classifier | ≤ 0.55 |
| Privacy Score | 1 − 2·\|AUC − 0.5\| | ≥ 0.85 |
| Entropy Gap | H(M(D_f)) − H(M(D_t)) | ≤ 0.1 nats |

*(Note added 2026-08-16, external review round 6/7 — Gemini specifically
requested this cross-reference for paper-level rigor: Shadow AUC above
is computed by training the meta-classifier on retain-vs-one-half-of-test
and evaluating it on forget-vs-the-other-half-of-test, so the classifier
is never evaluated against non-member samples it saw during its own
training. See §29 for the bug this fixes, the impact assessment showing
it never affected any reported result, and the regression tests.)*

---

## 8. Experiment Protocol

### Baseline Comparisons

| Method | Description |
|--------|-------------|
| Random Noise | Add Gaussian noise to all weights |
| Gradient Ascent | Plain GA, no retention mechanism |
| GA + EWC | GA with EWC consolidation (SISA-inspired) |
| **UML (ours)** | Full dual-engine system |

### Ablation Studies

1. **Without Experience Engine** — fixed hyperparameters throughout
2. **Without Rule Extraction** — random strategy selection only
3. **Without Strategy Evolution** — no rule merging
4. **Without Dream Replay** — only correction replay for retention
5. **Without EWC** — no Fisher-based importance weighting

### Evaluation Metrics

```
Primary composite score:
  Ω = F + P + A + R - H
  where:
    F = 1 - forget_acc   (forgetting quality)
    P = privacy_score    (MIA resistance)
    A = test_accuracy    (overall accuracy)
    R = retain_accuracy  (retention quality)
    H = hallucination    (penalty)

Secondary:
  • Convergence speed  (cycles to reach Ω > 4.0)
  • Strategy efficiency (number of proposals until convergence)
  • Rule generalisation (evolved rules / total rules)
```

### Reproducibility

- Seed: 42 (all random operations)
- Dataset: MNIST, forget_class=0
- Hardware: single GPU (NVIDIA V100) or CPU
- Pre-training: 5 epochs, lr=0.001, Adam
- Cycles: 25
- All results averaged over 3 seeds: {42, 123, 456}

---

## 9. Novelty Analysis (for Paper)

### Core Contributions

**C1: Dual-Engine Cognitive Architecture**

The strict Layer 1 / Layer 2 separation is novel in machine unlearning.
Prior work (SISA, Amnesiac, Bad Teacher) treats forgetting as a single-pass
procedure. Our architecture enables continuous, adaptive unlearning guided
by an experience-accumulating meta-learner.

**C2: Meta-Learning of Forgetting Strategies**

The Experience Engine does not learn *what* to forget; it learns *how to
forget optimally*. This is the first application of meta-learning principles
to the unlearning hyperparameter adaptation problem.

**C3: Long-Term Strategy Memory with Lifecycle Management**

The 4-state (Active/Dormant/Archive/Deleted) lifecycle with importance-weighted
pruning ensures the strategy base does not grow unboundedly while preserving
high-generalisation rules. This borrows from cognitive science models of
long-term potentiation and synaptic pruning.

**C4: Rule Extraction from Unlearning Experience**

Automatic extraction of if-then rules from observed (condition, action, outcome)
triples enables interpretable, auditable reasoning about *why* a strategy was
applied — a key requirement for regulated machine unlearning (e.g., GDPR Art. 17).

**C5: Rule Evolution via Structural Merging**

Hierarchical merging of similar rules into generalised abstractions
(analogous to concept formation in cognitive systems) reduces rule base
complexity and improves generalisation to unseen forgetting scenarios.

### Related Work Differentiation

| Paper | Method | vs. Our Work |
|-------|--------|--------------|
| Cao & Yang 2015 | Summation-form transformation (statistical query learning) | Requires reformulating the learning algorithm itself; no post-hoc adaptation loop |
| Golatkar et al. 2020 | Fisher Forgetting — noisy Newton update from the FIM | One-shot; no meta-learning |
| Chundawat et al. 2023 | Bad Teacher distillation (incompetent-teacher framework) | Single strategy; no evolution |
| Bourtoule et al. 2021 | SISA Training | Pre-training only; no post-hoc loop |
| Ours | Dual-engine with meta-learning | Adaptive, interpretable, continual |

### Evaluation Claims

Hypothesis H1: The dual-engine system achieves higher Ω than fixed-hyperparameter
baselines within the same number of unlearning cycles.

Hypothesis H2: Rule extraction enables faster convergence in repeated forgetting
tasks (transfer learning for forgetting).

Hypothesis H3: Strategy evolution (rule merging) improves generalisation score
compared to an ablation without merging.

---

## 10. Empirical Validation (Real Run, Not Synthetic)

The implementation was validated end-to-end on **real structured data** —
scikit-learn's bundled `digits` dataset (1,797 genuine 8×8 handwritten
digit images, 10 classes) — rather than only on random tensors. This
dataset was chosen as a network-free MNIST substitute because the sandboxed
execution environment's egress allowlist does not include MNIST's mirror
hosts (`yann.lecun.com`, `ossci-datasets.s3.amazonaws.com`); a user running
this code in an environment with normal internet access can swap back to
`load_unlearning_datasets()` (real MNIST) with no code changes elsewhere,
since both loaders share an identical `(forget, retain, test, full)`
`DataLoader` interface.

Task: pre-train on all 10 digits → forget digit "7" (143 samples) while
retaining digits 0–6, 8, 9 (1,294 samples), evaluated against a 360-sample
held-out test set. 25 cycles, MLP(64→128→64→10), CPU-only.

### 10.1 Bugs Found and Fixed by Real-Data Validation

Running on genuinely learnable (non-random) data surfaced two defects that
the random-tensor smoke tests could not have caught, since random labels
never produce the activation/threshold patterns that trigger them:

**Bug 1 — Rule Extraction off-by-one.** `RuleExtractor.extract()` paired
each journal entry's *condition* with the *action already baked into that
same entry* (`before.strategy_applied`) instead of the action *decided in
response to* that entry (`after.strategy_applied`). Journal semantics are
`journal[i].strategy_applied = `the proposal computed from `journal[i-1].metrics`,
so the correct attribution for "condition observed at `i` → action chosen →
outcome at `i+1`" requires reading the action off the *following* entry.
Fixed in `modules/experience/rule_extraction.py`.

**Bug 2 — BatchNorm1d crash on size-1 trailing batches.** `DreamReplayer`
builds its replay `DataLoader` from a *confidence-threshold-filtered*
subset of retain data, so the resulting sample count is run-dependent and
not guaranteed divisible by the batch size; a trailing batch of exactly 1
sample makes `BatchNorm1d.forward()` raise (`Expected more than 1 value per
channel when training`). The same latent risk existed in
`GradientAscentForgetter`, `CorrectionReplayer`, and the pre-training loop
in `main.py` for any forget/retain split whose size happens to land on a
remainder of 1. Fixed with an explicit `if x.size(0) < 2: continue` guard
in all four training loops (chosen over `drop_last=True` alone, since
`drop_last` can silently discard an entire small forget set if its size is
smaller than the batch size).

Both fixes are in the delivered code; the smoke tests in this document's
examples were re-run after the fixes to confirm no regression.

### 10.2 Observed Dynamics

| Metric | Cycle 0 | Final (cycle 24) | Δ |
|---|---|---|---|
| forget_acc | 0.993 | 0.000 | −0.993 |
| retain_acc | 1.000 | 1.000 | 0.000 |
| accuracy | 0.983 | 0.881 | −0.102 |
| privacy | 0.302 | 0.185 | −0.117 |
| hallucination | 0.333 | 0.442 | +0.109 |
| stability | 0.923 | 0.958 | +0.035 |

Forgetting itself converged almost immediately (forget_acc crossed 0.40,
0.25, and 0.15 by cycle 2, reaching 0.000 from cycle 3 onward) while
retain_acc never dropped below 0.992 — the GA + EWC + dream/correction
replay combination is highly effective at the core forget/retain trade-off
on this task. The harder, longer-horizon problem is the **side effects**:
hallucination rose steadily (0.33 → 0.44, peaking at 0.68 mid-run) and
privacy *fell* rather than improved (0.30 → 0.19).

The privacy result has a specific, citable explanation rather than being a
simple failure: `Confidence-MIA AUC = 0.078` — far below 0.5 in the
*opposite* direction from ordinary membership leakage. Because the task
forgets an entire semantic class rather than scattered instances, the model
learns to be *systematically under-confident specifically on digit-7
inputs*, which is itself a distinguishing signature an attacker can exploit
just as effectively as ordinary overconfidence. This matches a known
distinction in the unlearning literature between class-removal and
instance-level unlearning regimes (Golatkar et al., 2020): class-level
forgetting trades one detectable signal (high confidence on members) for
another (anomalously low confidence on the forgotten class), and a
symmetric privacy score (`1 − 2|AUC − 0.5|`) correctly penalises both
directions rather than only the conventional one.

### 10.3 Rule Extraction and Evolution — Confirmed Working on Real Data

After the off-by-one fix, the 25-cycle run produced **12 extracted rules**,
**3 merge events**, and a final memory state of `{active: 5, dormant: 3,
deleted: 7}` — the lifecycle state machine visibly pruning lower-importance
rules as evolution superseded them. The dominant surviving rule was:

```
[EVOLVED] if hallucination high (thresh ∈ [0.05, 0.20]): increase_forgetting_strength
  success_rate=0.56  confidence=0.70  usage=5
```

formed by merging three near-identical threshold variants
(`hallucination > 0.05/0.10/0.20 → increase_forgetting_strength`) — exactly
the abstraction pattern described in the design spec (§ Rule Evolution),
except the *specific* condition→action pairing was discovered empirically
rather than hand-specified.

### 10.4 An Emergent Limitation, Found Empirically

Cross-referencing the per-strategy effectiveness table against *when* each
rule fired reveals a genuine weakness worth stating plainly rather than
hiding: `increase_forgetting_strength` was applied 8 times across cycles
2–24, but its **overall mean score delta was slightly negative (−0.0078,
50% improve-rate)** — it only helped early (cycles 2–5, while forget_acc
was still non-zero) and was actively unhelpful later, since by cycle 15 the
forget set was already at 0% accuracy and *additional* forgetting pressure
could no longer improve forgetting quality, yet kept perturbing weights in
ways that plausibly compounded the hallucination problem it was nominally
called in to fix. The rule's condition (`hallucination high`) remained
true throughout this period, so it kept re-firing without any awareness
that the *premise behind its original success* (residual forgetting still
in progress) no longer held.

This is precisely the kind of context-drift failure mode that motivates
§ 6's meta-learning extensions — in particular, **stage-aware rule
preconditions** (§ 6d) that would gate `increase_forgetting_strength` on
`forget_acc` still being above some floor, not only on `hallucination`
being high. We present this as an identified limitation and concrete
future-work direction rather than retro-fitting the rule logic to hide it,
since an honest account of where the current strategy-selection heuristic
breaks down is more useful to a research audience than a result that only
shows successes.

### 10.5 Reproducing This Validation

```bash
python -m unlearning_meta.run_real_experiment
```

Outputs land in `./outputs_real/` (metrics CSV/JSONL, 4 dashboard plots,
final checkpoint) and `./logs_real/` (timestamped + JSONL logs), using the
exact configuration in `run_real_experiment.py::build_config()`.

---

## 11. External Review, Round 2 — ChatGPT and Gemini on Design/Theory Questions

A structured review request (5 questions on RL formalization, score design,
strategy-selection coherence, terminology, and experimental rigor — see
`unlearning_meta_external_review_request.md`) was independently sent to
ChatGPT and Gemini. ChatGPT answered all 5 questions directly with
verdict/reasoning/fix. Gemini instead reacted to the request document
itself, endorsed the same 5 questions, proposed 3 additional review items,
and gave an overall project scorecard. Both are summarized and critically
assessed below, with a clear record of what was actually implemented as a
result versus documented as future work.

### 11.1 ChatGPT's verdicts (Q1–Q5) — assessment

| Q | Verdict | My assessment |
|---|---|---|
| 1 (Markov property) | Doesn't hold; needs POMDP framing, frame-stacking or momentum features | **Agree.** Well-grounded — frame-stacking for partial observability is standard RL practice (e.g. Atari DQN stacks 4 frames because single-frame state is non-Markovian for velocity). Concrete and implementable. |
| 2 (linear scalarization) | Not defensible for headline results; use Pareto frontier or constrained optimization | **Agree.** The constrained-optimization reframing (maximize F+P subject to A≥threshold, H≤threshold, else penalize) maps cleanly onto the original spec's own "responsibilities" split (Forgetting/Privacy as objectives to push; Retention/Accuracy as guardrails that must not collapse). |
| 3 (Tier 1/2/3 coherence) | Not coherent; Tier 1's static 0.55 threshold can preempt Tier 2's UCB score even with overwhelming contrary evidence | **Agree — this is also what I identified independently in the review request.** Note: the response's proposed unified-score formula was garbled in transmission (the `Rule_Prior(a)` equation didn't render) — see §11.3 for a reconstruction attempt. |
| 4 (hallucination terminology) | Not defensible; will draw reviewer pushback; rename to "Overconfident Misclassification Rate (OMR)" | **Agree on the verdict. Partially implemented — see §11.4** for why this couldn't be a blanket rename. |
| 5 (task difficulty) | Not difficult enough; whole-class removal on distinct-featured digits is "too clean a surgical extraction"; use instance-level or feature-correlated forgetting instead | **Agree.** The "10% of every class" instance-level suggestion is concrete and directly implementable against the existing `load_digits_unlearning_datasets` interface — not yet done, tracked as future work (§11.5). |

### 11.2 Gemini's additions (Q6–Q8) and scorecard — assessment

**Q6 (Is this really Meta-Learning?)** Fair and arguably the most
fundamental of all eight questions raised across both reviews. As
implemented, the Experience Engine does **not** perform gradient-based
meta-learning in the MAML/Reptile sense (no inner/outer loop optimizing
over a distribution of unlearning tasks). It is closer to a rule-based
adaptive controller blended with a simplified multi-armed-bandit
mechanism. "Meta-Learning" was the term specified in the original project
brief (alongside "hallucination" — see §11.4), not an independent
terminology choice made during implementation, but that provenance doesn't
resolve the substantive question Gemini raises: a paper claiming this
architecture *is* meta-learning should either (a) rename the contribution
to "adaptive strategy control" / "learned unlearning heuristics" and drop
the meta-learning framing, or (b) actually close the gap by implementing
one of §7's proposed extensions (MAML-style inner/outer loop, or at
minimum a proper contextual bandit per Q3's fix) so the term is earned
rather than aspirational. Recommend option (b) before submission.

**Q7 (Rule Extraction's theoretical grounding)** Fair. The current
`RuleExtractor` is, in effect, a simplified rediscovery of Association
Rule Mining's support/confidence framework (§6 of `rule_extraction.py`
counts occurrences and gates on `min_observations` + `confidence_thresh`,
which is structurally support + confidence by another name) without
citing that literature or using its more principled statistical tooling
(lift, conviction, chi-square significance testing, Apriori's
downward-closure property for efficient search over condition
combinations). Positioning this explicitly against Association Rule
Mining in the paper would both strengthen the related-work section and
likely surface concrete improvements (e.g., a statistical significance
gate instead of the current fixed `min_observations` count).

**Q8 (Episodic/Semantic/Procedural memory framing)** Reasonable but lower
priority — this is a narrative/positioning suggestion for the discussion
section rather than a design flaw. Worth one paragraph relating
`StrategyRecord`'s fields to procedural memory (it stores *how* to act,
not declarative facts) if leaning into the "cognitive architecture" framing
already present in the original brief, but doesn't require code changes.

**Scorecard (9.5/10 implementation, 8.5–9/10 novelty, 8/10
paper-readiness).** I think this is too generous and internally
inconsistent with Gemini's own preceding paragraph, which just endorsed
three separate "not coherent" / "not defensible" verdicts on core design
elements (Q2, Q3, Q4). A 9.5/10 implementation-completeness score sits
oddly next to that. For calibration: across this conversation, direct
execution and code reading (not review commentary) surfaced at least 7
concrete, independently-fixed defects — a rule-extraction off-by-one, a
BatchNorm1d crash on size-1 batches (4 call sites), a stdlib module-name
collision, an unverified "measured" memory claim, a mischaracterized
citation, and — found while preparing the review request document itself
— an exploration-rate bug where the actual probability of random strategy
exploration was ~4x lower than the configured value (0.039 vs. a
configured 0.15) due to independent re-sampling at each decision tier.
That track record argues for treating this as a working, well-tested
engineering scaffold with several genuine open *design* problems (now
partially addressed below), rather than a near-finished 9.5/10 system.
The suggested baselines/ablations (fixed-hyperparameter, no-Rule-Memory,
no-Reflection, no-Strategy-Evolution) are good and not yet implemented —
tracked as future work (§11.5).

### 11.3 What was implemented as a direct result of this review round

**Cumulative drift from θ₀ (Q1's "momentum feature" fix, partial).**
`UnlearningEngine` now snapshots model weights once at the start of the
run (`_theta_zero`, fixed thereafter) and computes a normalized L2
distance from that fixed point every cycle, stored in
`UnlearningMetrics.extra["cumulative_drift"]` (kept out of the six core
spec'd fields deliberately — see below). Unlike the existing per-cycle
`stability` metric (which resets its reference every cycle and can
therefore look identical for a lightly-perturbed model and one that has
taken a long, circuitous path to the same point), `cumulative_drift`
accumulates monotonically:

```
cycle 0: stability=0.839  cumulative_drift=0.161
cycle 4: stability=0.919  cumulative_drift=0.502
cycle 7: stability=0.934  cumulative_drift=0.672   ← stability ~flat, drift keeps climbing
```

This is infrastructure for Q1's fuller fix (a frame-stacked or
momentum-augmented state representation for a future RL policy), not the
complete fix — actual frame-stacking (a rolling window of the last N
metric tuples) is not yet implemented.

**OMR terminology (Q4, display layer only).** Chart titles and the
natural-language Self Explanation sentences now read "Overconfident
Misclassification Rate (OMR)" instead of "hallucination." The underlying
Python field name (`UnlearningMetrics.hallucination`) and the
`hallucination_risk` failure-category tag are **unchanged** — both were
literally specified by name in the original project brief (`"hallucination":
float` in the required metrics dict; `hallucination_risk` in the required
Self Reflection failure list), not an independent naming choice made
during implementation, so a full rename would silently override an
explicit instruction rather than address a design gap. The rename that
*is* implementer-discretion — how the metric is described to a human
reader in logs, charts, and this document — has been updated. A 12-file
full-schema rename remains possible if the person running this project
decides the original terminology should be superseded rather than kept
alongside a publication-facing label; see `config.py`/`schemas.py` if so.

**Reconstruction attempt for Q3's garbled formula.** The transmitted
response's unified-score equation didn't render. Based on the surrounding
text ("additive boost applied only if a rule explicitly recommends action
a"), the intended formula is most likely:

```
Score(a) = UCB(a) + β · Rule_Prior(a)
Rule_Prior(a) = best_rec.confidence  if a matching StrategyRecord recommends a, else 0
action = argmax_a Score(a)
```

with β as a new tunable weight. This has **not** been implemented — Tier
1/2/3 remains a fixed-priority hierarchy in the current code — but is
recorded here precisely enough to implement directly if this becomes the
next priority.

### 11.4 On the two terms specified in the original brief ("hallucination", "meta-learning")

Both external reviews converged on renaming "hallucination"; Gemini
separately questioned whether "meta-learning" is earned. Both terms trace
back to the same source: the original project brief specified them by
name, not as accidents of implementation. This document now distinguishes
between the parts of the design that are *implementer choices* (fair game
for these reviews to override — e.g. the composite score weights, the
Tier 1/2/3 hierarchy, the exploration-rate mechanics) and the parts that
were *explicit user specification* (the six-metric dict contract including
the `hallucination` key, the five-item failure taxonomy including
`hallucination_risk`, and the "meta-learning" framing itself). Recommending
a change to the latter category is still useful — hence recording both
recommendations here in full — but implementing it unilaterally inside the
prototype would overstep what was actually asked for. The person running
this project should make that call explicitly rather than have it made
silently by an automated rename.

### 11.5 Consolidated future-work backlog from this review round

Not implemented yet; recorded here with enough specificity to act on directly:

1. **Constrained-optimization reward** (Q2): `Score = F + P` subject to
   hard guardrails on `A` and `H`; replaces the fixed linear scalarization
   for any future RL-policy training, while the current `Ω` composite
   score can remain as a reporting/logging convenience.
2. **Unified contextual bandit** (Q3): replace the Tier 1/2/3
   fixed-priority hierarchy with the single-score formula in §11.3.
3. **Frame-stacked state representation** (Q1): extend
   `cumulative_drift` (§11.3, now available) into a rolling window of the
   last N metric tuples and last N actions as the actual RL state, once
   an RL policy is implemented against Q2/Q3's fixes.
4. **Instance-level and feature-correlated forgetting datasets** (Q5): add
   a `forget_fraction`-style instance-level mode to
   `load_digits_unlearning_datasets` (forgetting a random subset of every
   class rather than whole classes) as a harder benchmark.
5. **Baselines and ablations** (Gemini's scorecard commentary):
   fixed-hyperparameter baseline, Experience-Engine-disabled ablation,
   no-Rule-Extraction ablation, no-Strategy-Evolution ablation — all
   directly runnable against the existing `Config` system by toggling
   `experience.exploration_rate=0` / bypassing `experience_engine.process()`
   / disabling `RuleExtractor`/`StrategyEvolution` calls respectively.
6. **Association Rule Mining framing** (Gemini Q7): reposition
   `RuleExtractor` explicitly against support/confidence/lift, and
   consider a statistical-significance gate in place of the current fixed
   `min_observations` threshold.

---

## 12. Instance-Level Forgetting Benchmark (Q5, implemented and validated)

Following the round-2 review's Q5 critique (whole-class digit removal is
"too clean a surgical extraction" — ChatGPT; "3サイクルで終了...十分に示せない" —
Gemini's document-35 review) and the decision to prioritize benchmark
rigor before further algorithm work (§11.5 reasoning: algorithm
improvements can't be evaluated on a task everything already solves in 2-3
cycles), a harder benchmark was implemented and run:
`load_digits_instance_forgetting()` forgets a stratified random 10% of
*every* class (139 samples spread across all 10 digits) instead of one
whole class, so the forget set is drawn from the same distributions as
retain rather than being trivially separable by class identity.

### 12.1 forget_acc=0 is not even the right target here

A retrain-from-scratch gold-standard baseline was computed (a fresh model
trained on retain-only data, evaluated on the forget set it never saw):

```
Gold-standard baseline forget_acc = 0.9856
```

A model that never saw these 139 instances still classifies **98.6% of
them correctly**, purely from general class-boundary knowledge — nine
retained "3"s are enough to teach the model what a "3" looks like, whether
or not this particular fourteenth "3" was included. Driving forget_acc to
0 here would mean actively suppressing correct predictions the model has
every right to make; that is over-forgetting, not success. This is a
structural difference from whole-class forgetting, where forget_acc=0 is
the unambiguous correct target, and is worth stating plainly: **the
composite score's `F = 1 - forget_acc` term, and by extension the whole Ω
formula, is only valid for whole-class-style benchmarks.** Using it
unmodified on instance-level tasks would reward over-forgetting. This
benchmark was run with the existing Ω formula unchanged specifically to
observe what the current system does *without* correcting for this yet —
seeing the failure mode was the point.

### 12.2 Result: persistent under-forgetting, not over-forgetting

```
Pre-unlearning forget_acc : 1.0000
Final forget_acc (25 cyc) : 0.9856   (coincidentally ~= the baseline)
Min forget_acc across run : 0.9784
Max forget_acc across run : 1.0000
Retain_acc across run     : 1.000 at every single cycle, no exceptions
```

The final value landing near the gold-standard baseline is coincidental,
not earned: forget_acc barely moved from its pre-unlearning value of
1.0000 for the *entire* 25-cycle run (max drop: 2.2 percentage points).
Compare directly to the whole-class benchmark (§10), where forget_acc fell
from ~0.99 to 0.000 within 3 cycles. This is a completely different, and
more informative, failure mode: **under-forgetting**, not over-forgetting,
and not the fast clean success seen on the easy benchmark either.

This did not happen for lack of trying: `increase_forgetting_strength` was
the action proposed and applied in **18 of 25 cycles (72%)** —
the Experience Engine correctly and repeatedly diagnosed `forget_failure`
and pushed the obvious lever — yet forget_acc stayed essentially flat
regardless. This is a genuine limitation the whole-class benchmark could
never have revealed, since gradient ascent alone was already sufficient
there.

### 12.3 Root cause, precisely isolated (updated — the original hypothesis was wrong)

The original hypothesis above (Correction Replay / EWC neutralising
forgetting progress) was tested directly with a 2×2 factorial ablation
(`run_ablation_study.py`: Correction Replay × EWC, both on/off, from an
identical pretrained starting point, 25 fixed-hyperparameter cycles each,
no Experience Engine involved to isolate the mechanism cleanly) and was
**falsified**:

```
Condition                Correction   EWC    ΔF (forget_acc drop from pre-unlearning)
A) Full system                ON      ON      0.0288
B) No correction replay       OFF     ON      0.0216   (LESS forgetting, not more)
C) No EWC                     ON      OFF     0.0288   (identical to A — no effect)
D) Neither                    OFF     OFF     0.0144   (LESS forgetting still)
```

Removing either mechanism did not increase forgetting progress — if
anything, removing Correction Replay made it slightly *worse*. Whatever
was suppressing forgetting, it wasn't retain-protection fighting back.

Two follow-up targeted tests isolated the actual cause:

**Test 1** — hold `gradient_ascent_strength` fixed at 2.5 (a value the
real run passed through around cycle 14) for the full 25 cycles, instead
of letting it ramp: forget_acc *still* stayed flat (0.99→0.97). Magnitude
reached wasn't the issue either.

**Test 2** — same fixed `gradient_ascent_strength=2.5`, same untouched
`forget_lr=0.006`, but with `max_grad_norm` raised from its default of
**1.0** to 1000 (i.e., gradient clipping effectively disabled):
forget_acc declined steadily and cleanly from 1.00 to **0.93** over 25
cycles — **with retain_acc holding at a perfect 1.000 throughout, no
damage at all.**

**Root cause**: `GradientAscentForgetter` scales the *loss* by
`gradient_ascent_strength` before `.backward()`, but then applies
`torch.nn.utils.clip_grad_norm_(params, max_grad_norm=1.0)` before the
optimizer step — unconditionally, regardless of how large `strength` made
the pre-clip gradient. Past a fairly low threshold, increasing `strength`
further does nothing: the clip caps the effective step at the same norm
either way. Across the real 25-cycle run, `gradient_ascent_strength`
climbed from 0.5 to 3.88 (§12.2's log) while `increase_forgetting_strength`
fired in 18/25 cycles — all of that adaptation was fighting a ceiling it
had no way to detect or adjust, because **`max_grad_norm` is not one of
the seven strategy actions' `config_attr` targets** (`schemas.py`'s
`StrategyAction.config_attr` mapping has no entry that touches it) and
`forget_lr` — the parameter that a much larger, blunter test (§12.2's
follow-up: `strength=5.0` *and* `forget_lr` raised 8× together) showed
*does* move forget_acc, at the cost of catastrophic retain damage
(retain_acc collapsed to 0.64) — is equally unreachable by any strategy
action.

**This reframes the finding entirely.** It is not that instance-level
forgetting is intrinsically unsolvable with this architecture, or that
retain-protection is "too strong" in some fundamental sense. It's that
**the Experience Engine's action space is missing a lever for the specific
hyperparameter that turned out to matter**, and the one blunt instrument
available (`forget_lr`, reachable only by directly editing `UnlearningConfig`,
not through any `StrategyAction`) overshoots badly when pushed hard enough
to matter. Test 2 above shows a *clean, undamaging path exists*
(disable/relax the clip, leave `forget_lr` small) — the current strategy
vocabulary simply can't find it.

### 12.4 What this changes about the round-2 assessment

This is direct empirical support for treating Gemini's 9.5/10
implementation-completeness score (§11.2) as too generous: the same
hyperparameters and dual-engine architecture that looked effective on the
original benchmark essentially fail to make progress at all on a
harder-but-still-small, still-CPU-cheap variant of the same task — and the
root cause, once found, was a genuinely simple implementation gap (a
hardcoded, non-adjustable gradient clip silently capping the one action
the Experience Engine kept correctly reaching for), not a deep theoretical
limitation of the architecture. That combination — correct diagnosis
(`forget_failure` flagged every relevant cycle), correct lever pulled
(`increase_forgetting_strength`, 18/25 cycles), and complete lack of
effect because of an unrelated hardcoded ceiling nothing in the system
could see — is exactly the kind of failure mode a 9.5/10 score should have
had a mechanism to catch, and didn't.

**Concrete fix, precisely scoped** (supersedes the vaguer §11.5 item 5
ablation-only framing for this specific issue): add `max_grad_norm` as an
eighth adjustable target in `StrategyAction.config_attr`
(`schemas.py`) — e.g. a `relax_grad_clip` action mapped to
`"max_grad_norm"` with a positive sign — and give `SelfReflection` /
`RuleExtractor` visibility into cases where `gradient_ascent_strength` has
been increased repeatedly (say, 3+ consecutive cycles) with no
corresponding forget_acc improvement, as a trigger condition distinct from
the current flat `forget_acc > threshold` check. That second part matters:
Test 1 and Test 2 above show the *symptom* (repeated
`increase_forgetting_strength`, no effect) is detectable from metrics
already being logged — the system has the information needed to notice
its own lever isn't working, it just has no rule watching for that
specific pattern yet.

The remaining §11.5 backlog items (constrained optimization, unified
bandit, embedding-based rule evolution) should still be evaluated against
this benchmark once implemented, and the ablation-study infrastructure
built for this investigation (`run_ablation_study.py`) is reusable for
that — but the *specific* under-forgetting failure mode found here has a
known, precise, narrow fix now, rather than requiring those larger
architectural changes first.

Reproduce with: `python -m unlearning_meta.run_instance_level_experiment`
(main finding) and `python -m unlearning_meta.run_ablation_study` (the
2×2 ablation that falsified the original hypothesis) — outputs land in
`./outputs_instance/` / `./logs_instance/` and stdout respectively.

---

## 13. The Fix, Implemented — And Caught in the Act of Being Undermined by Q3

§12.4's proposed fix was implemented: `INCREASE_GRAD_CLIP` /
`DECREASE_GRAD_CLIP` were added as an 8th `StrategyAction` pair (mapped to
`max_grad_norm`, multiplicatively scaled rather than additively — see
`schemas.py` / `unlearning_engine.py`, since this parameter's useful range
spans orders of magnitude unlike the original seven), and
`SelfReflection` gained a new, journal-history-aware
`forget_progress_stalled` detector: `increase_forgetting_strength`
applied ≥3 times with <0.03 total forget_acc improvement while still
above the forget-failure threshold, mapped to `INCREASE_GRAD_CLIP` as the
recommended next action.

Both additions go beyond the original project brief's 7 actions / 5
failure categories — flagged explicitly (as with §11.4's terminology
decisions) since it wasn't asked for, only found necessary.

### 13.1 It works — once

Re-running the instance-level benchmark through the *actual*
`ExperienceEngine` (not a manual hyperparameter override, as in §12.3's
diagnostic tests) confirms the new detector fires correctly:

```
cycle  7: increase_forgetting_strength   forget_acc=0.9928 (flat for 3 cycles)
cycle  8: increase_forgetting_strength   forget_acc=0.9928
cycle  9: increase_forgetting_strength   forget_acc=0.9928   <- 3rd repeat, stall confirmed
cycle 10: increase_grad_clip             max_grad_norm: 1.0 -> 1.2   <- fix engaged
```

This is the system correctly diagnosing that its own usual lever isn't
working and reaching for the one specific fix that Test 2 in §12.3 showed
actually unlocks clean progress — autonomously, with no manual
intervention. That part of the loop closes exactly as designed.

### 13.2 ...then gets preempted by exactly the problem Q3 already named

`increase_grad_clip` fires exactly once in the 25-cycle run, then never
again — despite forget_acc remaining essentially flat (0.99→0.978) for
the rest of it, which should keep re-triggering the same stall condition.
Direct inspection of `StrategyMemory` explains why:

```
cycle 13: chosen=increase_forgetting_strength
  Tier-1 memory match: [EVOLVED] if forget_acc high (∈[0.15,0.25]):
    increase_forgetting_strength   confidence=0.725
cycle 14: ... confidence=0.772
cycle 15: ... confidence=0.644
```

An **evolved rule** — itself a Strategy Evolution merge product, exactly
the mechanism described in §5/§6 of this document — sits in Tier 1 with
confidence comfortably above the 0.55 gate, every single cycle from
roughly cycle 12 onward. Since Tier 1 is checked (and returns
immediately, per the code in Q3's original review excerpt) before Tier 2
— where `forget_progress_stalled` → `increase_grad_clip` lives — the new,
more-specific, journal-aware fix never gets a chance to re-fire once this
Tier-1 rule solidifies, regardless of how obviously stalled forget_acc
actually is.

This is not a new problem. It is **the exact Tier 1/Tier 2 coherence
issue ChatGPT identified in Q3 of external review round 2**
(§11.1: "Tier 1's static 0.55 threshold can preempt Tier 2's UCB score
even with overwhelming contrary evidence") — caught here concretely
undermining a specific, otherwise-working fix, rather than as an abstract
theoretical concern. The evolved rule's confidence (0.64–0.77) isn't even
that extreme; it simply never has to compete on the same footing as
`forget_progress_stalled`'s much more specific, directly-relevant signal,
because the fixed priority hierarchy never lets them compete at all.

### 13.3 Why this matters for prioritizing §11.5's backlog

Q3's unified contextual-bandit fix (§11.3's reconstructed formula,
`Score(a) = UCB(a) + β·Rule_Prior(a)`, `argmax` over all actions) is no
longer only theoretically motivated — it has a concrete, reproducible
failure case attached to it now: the newest, most targeted fix in this
codebase is real but structurally unreliable *because* Tier 1/2/3 remains
a fixed-priority hierarchy rather than a single scored comparison. Implementing
Q3 is now the natural next step, and this specific scenario (evolved
`forget_acc`-rule vs. `forget_progress_stalled`) is a ready-made test case
for confirming the fix once built: after Q3's change, `increase_grad_clip`
should be able to win against the evolved rule on cycles where
forget_progress_stalled is active, rather than being permanently locked
out once the evolved rule's confidence clears 0.55.

Reproduce with: `python -m unlearning_meta.run_instance_level_experiment`
(the fix is wired into the real pipeline; §13.1/13.2's traces came from
direct engine inspection, included here for precision — a future revision
of the experiment script could surface Tier-1-preemption events in its
own log output directly).

---

## 14. Unified Contextual Bandit — Implemented, Partially Validated, One New Problem Found

Following external review round 3 (Gemini's `ContextualBanditSelector`
proposal, directly motivated by §13's empirical confirmation of the Q3
Tier-1-entrenchment problem), the design was implemented in
`modules/experience/contextual_bandit.py` and wired into
`ExperienceEngine` behind a new opt-in config flag
(`ExperienceConfig.use_contextual_bandit`, default `False` — the original
Tier 1/2/3 hierarchy remains the default and a documented rollback path).

### 14.1 Two integration bugs fixed against the actual codebase

The contributed proposal's `memory.query(metrics, state="Active")` does
not match the actual `StrategyMemory.query()` signature
(`state_filter: Optional[StrategyState]`, not `state: str` — this would
raise `TypeError` if run as-is). It also did not thread `source_rule`
through to the returned proposal, which would have silently broken the
existing rule-outcome-tracking step in `ExperienceEngine.process()` (any
rule that won a selection would stop accumulating success-rate evidence,
since that update keys off `StrategyUpdate.source_rule`). Both fixed in
the implementation; see the module's docstring for the full list.

### 14.2 A cooldown mechanism was added, beyond the original proposal

A pure `argmax` over `Score(a) = UCB(a) + beta * Rule_Prior(a)`, run
independently each cycle, does not by itself guarantee an entrenched
leader gets re-challenged — its own inputs only change if it stops being
selected, which nothing in a pure-scoring approach forces. A cooldown was
added: after `bandit_cooldown_after` (default 4) consecutive cycles
selecting the same action, the highest-scoring *different* action is
forced for one cycle.

### 14.3 Result: the specific §13 failure is fixed — confirmed by direct re-run

The exact §13 scenario (same seed, same instance-level benchmark, same
unlearning hyperparameters) was re-run with only
`use_contextual_bandit=True` changed:

```
Old hierarchy (§13):  increase_grad_clip fires 1/25 cycles, then permanently
                       blocked by an evolved Tier-1 rule (confidence 0.64-0.77)
New bandit (§14):     increase_grad_clip fires 2/25 cycles; no action wins
                       more than 2 consecutive cycles anywhere in the run
```

The specific, reproduced entrenchment pattern from §13.2 does not recur.
More notably, the new selector reached a **deeper minimum forget_acc**
than the old hierarchy ever achieved in the same scenario (0.9353 at
cycle 8, vs. 0.9784 as the old hierarchy's best point across its full
25-cycle run) — genuine evidence of more forgetting progress being made
at its best point, not just more varied action selection.

### 14.4 But it doesn't sustain that progress — a new oscillation problem

forget_acc in the new run is **not monotonically improving**: after
reaching 0.9353 at cycle 8, it drifts back up to 0.9856 by cycle 24 —
nearly back to its starting value. The action trace shows why:
`increase_grad_clip` (cycle 14) is immediately followed by
`decrease_grad_clip` twice (cycles 15-16), undoing it; similar
increase/decrease alternation appears for `forgetting_strength`, `noise`,
and `ewc` throughout the run. No single action gets to dominate
unfairly anymore (§13's problem, fixed) — but nothing sustains a
directional push long enough to consolidate gains either. This is a
distinct, new problem, not a residual form of the old one.

**Diagnosis**: this is a UCB-vs-UCB dynamic, not a rule-prior or beta
issue. `increase_grad_clip` and `decrease_grad_clip` are both
under-explored early on, so both get a large, similar UCB exploration
bonus (`c·√(ln N / n)`, n≈1 for both) — whichever fires first gets
slightly more `n`, temporarily lowering its own bonus, which briefly lets
its opposite-direction sibling win instead. Nothing in the current score
formula distinguishes "this parameter was just deliberately pushed one
way for a reason" from "this direction happens to be under-explored right
now" — the two opposite-direction actions on the same parameter compete
as if unrelated to each other.

### 14.5 Direct answer to Gemini's question (cycle-based beta scheduling)

Gemini asked whether `beta` should be dynamically decayed/amplified over
the course of a run. Based on the result above: **likely not the right
lever for the problem actually observed.** Two reasons: (1) `rule_priors`
are empirically sparse for the first several cycles regardless of `beta`
— rules only exist once extraction (every 5 cycles) and evolution (every
10) have had time to accumulate evidence, so early-run `beta` is largely
inert no matter its value; (2) the oscillation problem diagnosed in §14.4
is a pure UCB dynamic between opposite-direction action pairs and has
nothing to do with how rule-priors get blended in — scheduling `beta`
would not touch it. A more targeted fix: either (a) directional
hysteresis — suppress the opposite-direction sibling's UCB exploration
bonus for a few cycles after either direction is chosen, so a deliberate
push isn't immediately eligible for reversal purely on under-exploration
grounds, or (b) a "ratchet" — require stronger evidence to justify
`decrease_X` than `increase_X` while forget_acc is actively improving.
Neither is implemented yet; both are precise enough to build directly.
This is recorded as the immediate next item, ahead of anything else in
§11.5's backlog, since it's a direct, reproduced consequence of the fix
just shipped in this section.

### 14.6 On document 6's maturity scorecard (external review round 3)

A companion review (document 6, external review round 3) scored 設計
(design) at 9.6/10 and 論文化 (paper-readiness) at 9.1/10 for v1.5. Both
feel inflated relative to what was true at the time of scoring: §13 had
just documented a *known, unfixed, actively-manifesting* architectural
flaw (the Tier-1 entrenchment problem) in the *current shipped design* —
scoring the design 9.6/10 while that was true undersells how unresolved
it still was. Similarly, 論文化 at 9.1/10 sits oddly next to the same
review's own item 4 ("ベースラインを増やす" — baselines are still
completely absent) and item 1 ("Tier1/2/3を廃止...最優先の改善点" —
acknowledging the highest-priority fix was not yet done). Praising the
falsification-and-diagnosis *process* highly is well-earned (§10-§13 are
genuinely strong scientific work); scoring the *current artifact* as
though the diagnosed flaw were already resolved is a different claim, and
the same distinction was already made once before about Gemini's earlier
9.5/10 (§11.2) — worth holding to consistently rather than only when the
first instance happened to have an internal contradiction to point to.

Reproduce §14.3's comparison with:
`cfg.experience.use_contextual_bandit = True` before constructing
`ExperienceEngine` in either `run_instance_level_experiment.py` or
`run_real_experiment.py` — both regression-tested with the flag left at
its `False` default to confirm zero behavioural change to existing
results (§14 is purely additive).

---

## 15. Directional Momentum — Synthesizing Two Independent Proposals

External review round 4 produced two different diagnoses of §14's
oscillation problem and two different proposed fixes, arriving from
different formal starting points:

- **ChatGPT**: framed it as a **non-stationary bandit** problem —
  choosing `increase_grad_clip` changes the environment
  `decrease_grad_clip` is evaluated against, breaking the independent-arms
  assumption standard UCB relies on. Proposed treating each opposing pair
  as **one controlled parameter with a finite-state machine** (increasing
  → still improving? → keep : stop → decrease) rather than two competing
  bandit arms — a structural reframing, closer to classical control theory
  than bandit theory.
- **Gemini**: framed it as **arm interdependence** within the MAB model —
  the two directions have "完全に相反するベクトル" (completely opposing
  vectors). Proposed **asymmetric damping**: temporarily suppress the
  exploration bonus of the opposite direction for some window after a move,
  formalized as a decay term `D(a,t)` added to the score. Also asked a
  direct implementation question: should opposing pairs be a static
  hardcoded mapping, or inferred dynamically from the `increase_`/`decrease_`
  string prefix?

Both diagnoses point at the same underlying issue through different
vocabulary and are not actually in tension — the implementation below
synthesizes both: ChatGPT's **grouping** (pairs compete as one unit
against the rest of the action space) provides the structural fix;
Gemini's **damping intuition**, implemented as explicit momentum state
with a patience threshold rather than a continuous decay function,
resolves within-group direction choice.

### 15.1 Gemini's question, answered

**Static hardcoded mapping** (`StrategyAction.opposite`, in `schemas.py`),
not dynamic prefix inference. Reasoning: prefix-parsing is implicit and
silently wrong for two actions already in the current action space —
`NOOP` has no prefix at all, and `increase_replay` /
`increase_correction_replay` have **no decrease_ counterpart at all** (see
§11 — these were never paired actions even in the original 7-action
spec). A string-prefix rule would need special-casing for both anyway;
an explicit `Dict[str, StrategyAction]` mapping documents the true
structure directly and returns `None` (not a wrong guess) for anything
outside it.

### 15.2 Implementation

`StrategyAction.opposite` provides the pairing. `ContextualBanditSelector`
now: (1) collapses each opposing pair into one group scored by
`max(score(increase_X), score(decrease_X))`, competing against singleton
groups (`increase_replay`, `increase_correction_replay`, unpaired) and
against each other via the same top-level argmax and cooldown as before;
(2) within a winning paired group, `_resolve_paired_group` uses momentum:
if the parameter was already moving in some direction and the composite
score hasn't gotten worse (within `momentum_patience` non-improving moves
of tolerance), keep going — don't re-derive from raw UCB. Only once
patience is exhausted does it fall back to a fresh increase-vs-decrease
comparison, which may reverse.

### 15.3 Result: the diagnosed pair is fixed; a patience sweep quantifies the tradeoff precisely

Re-running the exact §13/§14 scenario with the fix enabled:

```
grad_clip pair:  increase_grad_clip fires cycles 20,21 CONSECUTIVELY
                 (max_grad_norm: 1.0 -> 1.2 -> 1.44), zero decrease_grad_clip
                 firings anywhere in the run. The specific oscillation
                 diagnosed in §14.4 is gone for this pair.
```

A residual, milder oscillation remained on the `noise` pair at the
default patience setting, so `momentum_patience` was swept systematically
(same seed, all else fixed):

```
patience=0: min_forget_acc=0.9496  final=0.9928  reversals=6
patience=1: min_forget_acc=0.9496  final=0.9784  reversals=5
patience=2: min_forget_acc=0.9496  final=0.9712  reversals=3   <- adopted as default
patience=3: min_forget_acc=0.9496  final=0.9784  reversals=4
```

Two clean findings from this sweep: reversal count drops monotonically-ish
as patience increases (6→3, roughly halved at patience=2), confirming the
mechanism works as intended; and — more importantly — **min_forget_acc is
identical (0.9496) at every patience setting tested**, i.e. the momentum
mechanism reduces thrashing at *zero measured cost* to how deep the system
can still explore. `momentum_patience=2` was adopted as the new default on
this evidence (best reversal reduction with no downside observed).

### 15.4 Honest limitation: some of §14's exploration depth doesn't survive

§14's *unfixed*, freely-oscillating bandit reached a deeper minimum
(0.9353) than the momentum-corrected version does at any tested patience
(0.9496). The oscillation was not purely wasteful, then — some fraction of
how deep the unfixed system reached was serendipitous, an accidental
byproduct of thrashing landing on a good point rather than a controlled
achievement. A disciplined controller that commits to sustained,
coherent directional pushes (this section) trades away some of that
accidental depth in exchange for actually-reproducible, non-chaotic
progress. Both §14's raw exploration number and this section's more
stable number are real findings, not a case of the later one simply
superseding the earlier one — they characterize different points on an
explore/exploit-discipline tradeoff, worth reporting as such rather than
picking whichever sounds better.

Config: `ExperienceConfig.use_contextual_bandit=True` plus the existing
`bandit_beta` / `bandit_cooldown_after` / new `bandit_momentum_patience`
(default 2) fields. Default behavior (flag off) is unchanged — both
whole-class and instance-level regression scripts re-verified passing
with defaults.

---

## 16. The Objective Function Itself Was Miscalibrated — Found and Fixed

External review round 4 (Gemini) raised the sharpest critique of this
whole investigation: every strategy-selection mechanism built and refined
across §13-§15 — the grad-clip fix, the unified bandit, momentum,
patience tuning — has been judging "improvement" via
`UnlearningMetrics.composite_score()`, whose forget-quality term is
`1 - forget_acc`. This targets **0** unconditionally. §12.1 established
months earlier (in this document's own timeline) that 0 is the *wrong*
target for instance-level forgetting — the retrain-from-scratch gold
standard sits at 0.9856, and driving forget_acc below that is
over-forgetting. Gemini's point: no amount of actuator refinement
(§13-§15) fixes anything if the signal driving it is judging progress
against the wrong number.

### 16.1 Audit: how many places were actually affected

`grep`-ing every call site of `composite_score()` found **8 locations**
across 6 files, of which **3 called it with zero arguments at all** —
not even the existing `score_weights` parameter, let alone anything
target-aware: `contextual_bandit.py`'s momentum "did the score improve"
check, `meta_knowledge.py`'s best-score/best-cycle tracking, and
`self_explanation.py`'s natural-language trend description. All three
were silently judging progress against forget_acc=0 on every run,
including every instance-level run in §12-§15, regardless of what those
sections' prose said the correct target was.

### 16.2 Fix

`UnlearningMetrics.composite_score()` gained two new optional parameters,
both defaulting to `None` (whole-class behavior completely unchanged
unless explicitly overridden — verified below):

```python
composite_score(weights=None, target_forget_acc=None, retain_floor=None)
```

- `target_forget_acc=None` (default): `forget_quality = 1 - forget_acc`,
  exactly as before.
- `target_forget_acc=X`: `forget_quality = 1 - |forget_acc - X|` — rewards
  closeness to X, penalising deviation in *either* direction.
- `retain_floor=Y`: if `retain_acc < Y`, return a heavily penalised score
  (-10.0) regardless of every other term — the hard guardrail from
  external review round 2's Q2 and round 4's connection of Q2 back to
  §12.1, rather than the soft linear trade-off the unguarded formula
  otherwise gives retain_acc.

Rather than patch each of the 3 blind call sites to independently
recompute with the right arguments (which would just create 3 more
places that could drift out of sync with each other), `ExperienceEngine.
process()` now computes ONE canonical `current_score` per cycle — with
`self.target_forget_acc` / `self.retain_floor` applied — and threads that
single value down to `MetaKnowledge.update()`, `ContextualBanditSelector.
select()` → `_resolve_paired_group()`, `SelfExplainer.explain()`, and
`MemoryJournal.add()`, all of which now accept the pre-computed score as
a parameter instead of recomputing independently. This closes a second,
related latent issue the audit surfaced: even before target-awareness,
having 4 different call sites each independently call
`metrics.composite_score()` (some with `score_weights`, 3 without any
arguments) meant these were not even guaranteed to agree with each other
in the *original*, target=0 formula either — compute-once-thread-everywhere
is a strictly more consistent design regardless of the target-awareness
question that motivated finding it.

`run_instance_level_experiment.py` now sets
`cfg.experience.target_forget_acc = baseline_forget_acc` (the
already-computed retrain-from-scratch baseline — it was being displayed
in this script's own printed output all along, just never fed back into
the decision-making machinery) and `retain_floor = 0.90` before
constructing `ExperienceEngine`, and passes the same values into
`MetricsTracker` so logged/reported scores match what actually drove
decisions during the run.

### 16.3 Quantitative confirmation

Direct before/after comparison, same seed, same §14/15 bandit+momentum
configuration (chosen because forget_acc has room to move meaningfully
there, unlike the default Tier 1/2/3 hierarchy which is still bottlenecked
by the unrelated §12/13 gradient-clip issue on this benchmark):

```
                        min forget_acc   deviation from    min retain_acc
                        reached          baseline (0.9856)
Old (target=0)          0.9353           0.0504             0.9730
Fixed (target=baseline) 0.9568           0.0288             0.9831
```

The fix roughly **halves** the deepest deviation from the correct target
(0.0504 → 0.0288) — direct, quantitative confirmation that the old
scoring was pulling the system further past the correct stopping point
than the corrected version does. Retain damage improved too (min 0.9730 →
0.9831): chasing an unnecessarily aggressive forget_acc=0 target was
apparently also costing more collateral retain damage along the way, not
just missing the right forget_acc value.

### 16.4 What this means for §14/§15's numbers

§14 and §15's headline "min forget_acc" comparisons (0.9784 old hierarchy
→ 0.9353 unfixed bandit → 0.9496-0.9568 momentum-corrected bandit) were
all computed under the *pre-§16* scoring, i.e. all of that exploration was
being judged as "deeper is better" when the actually-correct read is
"closer to 0.9856 is better." None of those sections' conclusions about
*mechanism* (Tier-1 entrenchment fixed, oscillation fixed) are
invalidated — the mechanisms genuinely behave as described — but their
specific numbers should be read as "how far the wrong objective pulled
the system," not as a ranking of how good each version's outcome actually
was. §16.3's numbers are the first ones in this document computed against
a target this benchmark was actually verified (§12.1) to need.

Default behavior (`target_forget_acc=None`) verified numerically identical
to the pre-§16 formula (manual calculation vs. `composite_score()` output,
exact match to floating-point precision); both whole-class and
instance-level regression scripts re-verified passing with defaults.

---

## 17. Baselines, Ablations, and a Statistically Honest Answer

External review round 5 converged on the same next step from two
directions: ChatGPT proposed a `ScoreContext` refactor for future
extensibility (deferred — see §17.4); Gemini proposed finally executing
§11.5's longest-standing backlog item, baselines and ablations, now that
both the evaluation function (§16) and strategy-selection mechanism
(§13-15) are on verified footing. This section executes that.

### 17.1 First run (seed=42): the baseline won

`run_baseline_comparison.py` compares four conditions from an identical
pretrained starting point: (A) fixed hyperparameters, no Experience
Engine at all; (B) the full system (bandit + momentum + target-aware
scoring); (C) no Rule Extraction; (D) no Strategy Evolution. First run,
seed=42:

```
A (fixed hyperparameters):    mean_score=4.0917  min_retain=1.0000
B (full Experience Engine):   mean_score=4.0492  min_retain=0.9684
```

**The simplest possible baseline outscored the proposed method.** Within
the Experience-Engine family, B > D (no evolution) > C (no extraction),
consistent with evolution contributing real marginal value — but that
internal ordering doesn't matter if the whole family loses to doing
nothing adaptive at all.

### 17.2 Before writing that up: two more seeds flipped it

Two additional seeds (123, 777), run specifically to sanity-check before
treating §17.1 as a finding, produced the **opposite** result — B beating
A by a wide margin in both. A single-seed comparison here would have
supported whichever conclusion happened to get written up first,
depending only on which seed was run. This is precisely the failure mode
"multi-seed statistical evaluation" has been flagged to prevent across
every external review round since round 3 — demonstrated directly rather
than taken on faith.

### 17.3 Twenty-seven seeds — the properly-powered answer, and a methodological caution about how it was collected

§17.3's original n=7 estimate flagged "~25-30 seeds" as roughly the
sample size needed for adequate statistical power, computed from that
n=7 sample's own effect size (Cohen's d=0.605). Seeds were added in
batches (`run_seed_batch.py`, which appends to `seed_results/results.jsonl`
rather than overwriting it) toward that target, with the running total
checked after each batch: n=16 (p=0.095), n=26 (p=0.090), n=27 (p=0.061).
Final count, 27 seeds:

```
                   mean_score
A (fixed):         3.9885 ± 0.1563
B (full system):   4.0432 ± 0.1110
Delta (B - A):     +0.0547 ± 0.1453

B wins on 17/27 seeds (63%)
Paired t-test:     t=1.956, p=0.0613  →  still NOT significant at p<0.05
Effect size:       Cohen's d = 0.376 (paired) — down from 0.605 at n=7
95% CI on delta:   [-0.0001, +0.1095]  — still includes zero (barely)
```

**Methodological caution, stated explicitly rather than glossed over**:
checking the p-value after every batch (n=7 → 16 → 26 → 27) and deciding
whether to run another batch based on how close it looked to 0.05 is a
form of *optional stopping* — a well-known way to inflate false-positive
rates if the stopping rule is "add more until significant." That risk
didn't produce a false positive here (every checkpoint reported, still
none crossed p<0.05), but the *process* used to get to n=27 was not
itself rigorous, and this document says so rather than presenting n=27 as
though it were a single pre-committed, cleanly-executed test. The
statistically correct way to extend this further is to commit to a target
n in advance (the effect size at n=27 suggests ~55; see below) and run
that full batch once, reporting whatever single p-value results —
not checking after every batch as this section did.

Recomputing the required sample size at the more reliable n=27 effect
size (d=0.376) for 80% power gives **approximately 55 seeds** — smaller
than the n=26 checkpoint's estimate of ~65 (itself smaller than n=7's
original ~25-30), continuing the same pattern of the estimate shrinking
as more data arrives. `analyze_seed_results.py` computes this
automatically from whatever is in `results.jsonl` at the time, specifically
so a future continuation can commit to running the full remaining batch
(≈28 more seeds to reach 55) in one pass and report that result cleanly,
rather than repeating this section's own incremental-checking pattern.

**Final honest statement**: 27 seeds show a positive trend that has moved
closer to conventional significance as more data arrived (p: 0.16 → 0.09
→ 0.06) without crossing it, collected via a process this section
explicitly flags as methodologically imperfect (optional stopping) even
though it didn't produce a false positive in this instance. The data are
consistent with a small-to-modest real effect and also consistent with no
true effect; 27 seeds, collected this way, cannot responsibly be reported
as either "confirmed" or "ruled out." Data for all 27 seeds are in
`seed_results/results.jsonl`.

### 17.4 Fifty-five seeds, collected properly this time — a confirmed, modest result

Following §17.3's own methodological critique and Gemini's direct
prompt, the remaining 28 seeds (5000-5027) needed to reach the
n=55 target were pre-registered before collection
(`precommit/commitment.txt`: target n, exact seed range, and "analysis
runs exactly once, after all seeds complete" — written before any of
those 28 seeds ran) and then collected across several batched tool calls
**without computing or reporting any running p-value, effect size, or
confidence interval** during collection — only individual per-seed
win/loss, which is inherent to `run_seed_batch.py`'s existing per-seed
print statement and not a cumulative statistic. The single analysis was
run exactly once, after seed 5027 (the 28th and last) completed:

```
n = 55 seeds (pre-registered target, reached exactly)

A (fixed hyperparameters):  3.9989 ± 0.1517
B (full Experience Engine): 4.0517 ± 0.1078
Delta (B - A):              +0.0528 ± 0.1219

B wins on 37/55 seeds (67%)
Paired t-test:      t=3.213, p=0.0022  →  SIGNIFICANT at p<0.05
Effect size:        Cohen's d = 0.433 (paired)
95% CI on delta:    [+0.0206, +0.0850]  — entirely positive, no longer includes zero
```

**This is the first result in this document collected via a fully
pre-registered, non-peeked procedure, and it is statistically
significant.** The confidence interval no longer straddles zero. Across
the whole trajectory of estimates gathered along the way —
d=0.605 (n=7) → 0.346 (n=26) → 0.376 (n=27) → **0.433 (n=55, final)** —
the effect size did not shrink toward zero as more data arrived; it
stabilised in the 0.35-0.45 range, and the clean, properly-powered
endpoint confirms a real effect in that range rather than the noise the
early n=7 estimate could have been mistaken for.

**Honest characterisation of what this does and doesn't establish**: the
full Experience Engine (unified bandit, momentum, target-aware scoring)
provides a real, statistically confirmed advantage over doing nothing
adaptive at all, on the instance-level forgetting benchmark, at this model
size and cycle count. The effect is modest (d=0.433 is "small-to-medium"
by conventional Cohen's-d thresholds, not large) — this is evidence the
mechanism works, not evidence it works dramatically. The C/D ablation
ordering from §17.1 (evolution contributing more than raw rule extraction)
remains unconfirmed at multiple seeds and is the natural next thing to
check with the same pre-registration discipline used here, now that the
headline A-vs-B comparison has a clean answer.

### 17.5 On ChatGPT's ScoreContext proposal

Real merit — bundling `{composite_score, forget_acc, retain_acc, target,
penalty, weights, cycle}` into one object passed everywhere would mean
future evaluation axes (the proposal's examples: Novelty, Energy, Safety,
Stability) wouldn't require touching every function signature the way
§16's target_forget_acc addition just did (7+ signatures). Deferred
rather than implemented now: nothing is currently broken by its absence
(unlike §16, which fixed an active silent miscalibration), and building
it speculatively for hypothetical future axes that don't exist yet is a
cost paid now for a benefit not yet needed. The natural trigger point is
whichever future change first needs to add a second new axis alongside
target_forget_acc — building the generalised container in response to two
concrete cases is better-grounded than guessing its shape from one.

### 17.6 What this meant for the accumulated review scores, as of n=27

*(Written before §17.4's clean n=55 run existed — see §17.7 for the
updated view. Kept here rather than deleted, since revising a stated
position in place, without a visible trace of what was believed before
new evidence arrived, would understate exactly the kind of honesty this
document has tried to model throughout §10-17.)*

Recent external reviews scored this system very highly — 9.6-9.9/10
across several dimensions in round 4 (§14-15's discussion), including
"自己批判の質" (quality of self-criticism) at 9.9/10. §17.3's result was
hard to reconcile with those numbers taken as claims about the *system's
demonstrated effectiveness*: across 27 seeds, the 95% confidence interval
on whether the proposed method beats doing nothing adaptive at all still
included zero (barely — [-0.0001, +0.1095]). This wasn't a contradiction
of this document's own repeated point (§11.2, §14.6) that inflated scores
shouldn't be taken as consensus-seeking flattery rather than calibrated
assessment — it was the same point again, with the most concrete evidence
yet at the time: a real, honestly-run head-to-head against the simplest
possible baseline that the system had not yet clearly won, plus §17.3's
own explicit admission that even the process of gathering that evidence
had a real methodological flaw (optional stopping) worth naming rather
than glossing over.
None of the engineering and diagnostic work in §10-16 was worth less for
this — the failure-mode diagnosis, the falsified-then-confirmed
hypotheses, the interpretable rule-based reasoning are real contributions
independent of whether the headline score beats a static baseline — but
"beats a simple baseline" is a specific, checkable claim, distinct from
"the engineering is sound," and round 5 was the first point in this
document where that specific claim was actually checked rather than
assumed.

### 17.7 Updating §17.6 now that a significant result exists

§17.6 was accurate given what was known at n=27. §17.4's pre-registered
n=55 run changes the factual premise — the advantage is now confirmed,
p=0.0022 — without retroactively validating the 9.6-9.9 scores it was
pushing back on. A modest, real, properly-measured effect (d=0.433, a
mean score improvement of about 1.3% in this metric's units) is a
genuinely different, and much more specific, claim than "self-criticism
quality: 9.9/10" or architecture/design scores in the high 9s. The scores
weren't wrong to anticipate that the underlying mechanism might work —
§17.4 shows it does — but they were premature: given at a point when the
claim had not been checked, and (per §17.3/§14.6) following a pattern of
crediting the falsification-and-repair *process* as though it already
implied the outcome. The right lesson from finally reaching a genuinely
positive, confirmed result is not "the earlier high scores are now
vindicated," but "this is what a properly earned positive claim looks
like, and it took seven sections (§10-17) of falsified hypotheses, a
miscalibrated objective function, a reversed single-seed result, and a
self-caught optional-stopping violation to get here honestly."

Reproduce with: `python -m unlearning_meta.run_baseline_comparison`
(single-seed, 4-condition ablation), `python -m
unlearning_meta.run_seed_batch --start 5000 --count 28` (regenerates the
28 pre-registered seeds behind §17.4's result — already present in the
shipped `seed_results/results.jsonl`, so this is a no-op unless that file
is deleted first), and `python -m unlearning_meta.analyze_seed_results`
(recompute the full n=55 statistical report — mean/std, win rate, paired
t-test, Cohen's d, 95% CI — directly from the shipped data).

### 17.8 The C/D ablation, pre-registered — a null result, and the protocol working as designed

Following external review round 6 (Gemini's direct question: run C/D now
with the same rigor, or do literature review first), the empirical
question was resolved first — `precommit/commitment_cd.txt`, written
before any C/D data collection, fixed the design: reuse the exact same 55
seeds already collected for A/B (so B's scores need no re-collection), add
C (no rule extraction) and D (no strategy evolution) at each, and run a
Friedman omnibus test across all three FIRST — proceeding to
Bonferroni-corrected pairwise Wilcoxon tests only if that omnibus test is
significant. This avoids running three independent pairwise tests
uncorrected, which would itself be a multiple-comparisons problem exactly
analogous to §17.3's optional-stopping issue.

All 55 seeds' C and D scores were collected without checking any
intermediate statistic (`run_cd_ablation.py`, same append-and-skip design
as `run_seed_batch.py`), then the pre-registered analysis was run exactly
once:

```
n = 55 matched seeds

B (full system):        4.0517 ± 0.1078   95% CI [4.0232, 4.0802]
C (no rule extraction):  4.0396 ± 0.1102   95% CI [4.0105, 4.0688]
D (no strategy evol.):  4.0197 ± 0.1025   95% CI [3.9926, 4.0468]

Friedman omnibus test: chi2=4.836  p=0.0891  →  NOT significant
Kendall's W (effect size): 0.044  →  negligible
```

The three 95% CIs overlap substantially — visualised in
`seed_results/bcd_boxplot.png` (external review round 6's suggestion),
which shows the three distributions sitting on top of each other far more
than the mean ordering alone would suggest. Kendall's W of 0.044 is
"negligible" by conventional thresholds (W<0.1), quantifying just how
weak the 3-way concordance is — the omnibus non-significance isn't a
borderline call obscuring a real small effect; the effect size estimate
itself says there's barely anything there to detect.

**Per the pre-registered rule, pairwise tests were not run.** The means
are in the same order §17.1's single seed suggested (B > C > D — evolution
contributing more than raw extraction, both contributing something over
neither) but the omnibus test says this ordering is not statistically
distinguishable from chance at n=55. External review round 6 (Gemini)
correctly cautions that non-significance here doesn't prove no effect —
a 3-way repeated-measures comparison needs more power than the pairwise
A-vs-B test for a given effect size. Kendall's W adds a sharper point on
top of that caution rather than replacing it: W=0.044 is not just "we
couldn't detect it," it's a direct estimate that whatever concordance
exists among the three conditions is itself small. Both things can be
true together — the study may be underpowered, *and* the best current
estimate of the true effect is that it's small enough that resolving it
definitively would take substantially more than 55 seeds for a modest
payoff (recall §17.4's own experience: the effect-size estimate for the
A-vs-B question shrank as more data arrived too, from d=0.605 at n=7 down
to d=0.433 at the properly-powered n=55 — the analogous C/D question,
starting from a much smaller estimate already, is unlikely to resolve
into anything large).

**Strategic call, responding directly to round 6's question** (scale C/D
to n≈150, or pivot to generalization testing across tasks/forget-rates/
model-sizes): pivoting to generalization. Reasoning: the paper's central
claim (§17.4, does the Experience Engine help at all) is now confirmed
with adequate power; the C/D breakdown is a secondary, mechanistic
question, and a negligible effect-size estimate makes a large additional
investment to chase it a worse use of the same compute than testing
whether §17.4's confirmed result holds up anywhere else. Right now every
seed run in §10-17 — more than 140 model-training runs across the whole
investigation — has used exactly one dataset (digits), one model size
(64→128→64→10), and one forget fraction (10%). A reviewer questioning
whether the confirmed A-vs-B effect is an artifact of that one specific
setup is a materially larger threat to this document's central claim than
"we don't know whether rule extraction or strategy evolution individually
contributes more" — and no amount of further C/D precision would address
that larger, currently completely untested gap. §18 below begins that
work.

**Why this result matters beyond its own content**: §17.4's significant
A-vs-B result and §17.8's null C-vs-D-vs-B result were produced by the
*same* pre-registration protocol, applied the same way both times. A
protocol that always finds significance regardless of what's being tested
would be worth distrusting; one that finds it when the data supports it
(§17.4) and correctly withholds a conclusion when it doesn't (§17.8) is
doing its job. The pre-registered "stop at the omnibus test if it's not
significant" rule was written down before this specific result was known,
specifically so this section couldn't quietly relax it after seeing a
tempting-looking mean ordering — and it didn't need to be relaxed to
report this honestly.

Reproduce with: `python -m unlearning_meta.run_cd_ablation --start-index 0
--count 55` (regenerates the shipped `seed_results/results_cd.jsonl`;
no-op if already present) and `python -m
unlearning_meta.analyze_cd_ablation` (runs the pre-registered
Friedman-then-conditional-Wilcoxon analysis exactly as specified in
`precommit/commitment_cd.txt`).

---

## 18. Generalization, Started: Does the Effect Hold at a Different Forget Fraction?

§17.8's strategic call was to pivot from further C/D precision toward
testing whether §17.4's confirmed A-vs-B effect generalizes beyond the
single setup — digits, 64→128→64→10 MLP, forget_fraction=0.10 — used for
every one of the 140+ model-training runs across §10-17. This section
begins that with the cheapest dimension to vary: forget_fraction.

### 18.1 Design: exploratory, not a full replication

`run_generalization_check.py` reuses the exact same A/B infrastructure at
`forget_fraction=0.20` (double the original), using the same 15 seeds
already committed to elsewhere in this document (42, 123, 777, 2024,
31415, 8, 99, 1000-1007) — not to reuse their §17 *scores* (a different
forget_fraction is a different task, so those numbers don't transfer),
but so a reader can see the seed choice wasn't cherry-picked for this new
condition either. n=15 is explicitly **not** derived from a power
calculation the way §17.4's n=55 was — it's a deliberately small,
exploratory sample, run to get a directional signal before committing the
much larger investment a properly-powered check would need, consistent
with §17.8's own reasoning for not over-investing in secondary questions.

### 18.2 Result: same direction, comparable-or-larger magnitude

```
                    forget_fraction=0.10 (§17.4, n=55, full power)   forget_fraction=0.20 (n=15, exploratory)
Delta (B-A):        +0.0528                                          +0.0670
Cohen's d:           0.433                                            0.531
B win rate:          67% (37/55)                                      60% (9/15)
p-value:             0.0022 (significant)                             0.0589 (not significant — expected at n=15)
```

The effect held in the same direction, with a magnitude at least as
large as the properly-powered original estimate. The p-value not
crossing 0.05 here is not a contradictory finding — it's exactly what
§17.3-17.4's own experience with sample-size requirements predicts at
n=15 for an effect of this size (recall: 55 seeds were needed to confirm
significance for the very similar d≈0.43-0.48 effect at forget_fraction=
0.10). The honest reading is a positive, encouraging directional signal
that has not yet been independently confirmed at adequate power — the
same "suggestive but not yet confirmed" status §17.3 correctly assigned
to the *original* A-vs-B question at its own n=27 checkpoint, before §17.4
resolved it.

### 18.3 What this does and doesn't establish

This is one data point on one additional dimension (forget_fraction),
checked once, at low power, without its own pre-registration document
(a gap worth naming: §17's discipline — commitment.txt before data
collection — was not applied here with the same rigor, since this was
explicitly framed as a quick exploratory check rather than a claim-bearing
result). It does not establish that the effect generalizes across model
sizes or datasets, which remain completely untested. What it does
establish: the one generalization dimension checked so far didn't
immediately fall apart, which is a meaningfully better starting position
for further generalization work than no check at all, but is a long way
from the confirmed status of §17.4's headline result.

Reproduce with: `python -m unlearning_meta.run_generalization_check
--forget-fraction 0.20`.

---

*Generated by Unlearning Meta-Learning Research Prototype v2.2 — §18 added: the pivot to generalization testing (over further C/D precision) argued for in §17.8 was started with an exploratory, explicitly-labeled-as-preliminary check at a different forget_fraction, finding the confirmed §17.4 effect holds in the same direction at comparable-or-larger magnitude — encouraging, not yet independently confirmed, and reported at exactly that calibration rather than rounded up to a stronger claim.*

---

## 19. A Literature Baseline, Finally — Fisher Forgetting, and an Unexpected Robustness Finding

External review round 6's question (public release readiness) surfaced a
gap that had been flagged since round 2 but never addressed: no
comparison against any *existing* machine unlearning method from the
literature had ever been implemented — only the "fixed hyperparameters,
no adaptation" baseline (condition A). This section closes that gap with
Fisher Forgetting (Golatkar, Achille & Soatto, CVPR 2020 — already cited
in §9's related-work table, never implemented until now).

### 19.1 Implementation and a bug found by actually running it

`modules/unlearning/fisher_forgetting_baseline.py` implements the core
mechanism: a single-shot scrub perturbing each parameter with noise scaled
inversely to its Fisher information (`noise_std = noise_scale /
sqrt(F + epsilon)`), protecting retain-important parameters while
scrambling less-important ones — mechanistically distinct from both this
project's uniform noise injection and from doing nothing adaptive.

The first version used `epsilon=1e-6`, matching this project's own
`FisherInformation` module's typical usage elsewhere. Running it
immediately produced catastrophic retain damage (retain_acc ≈ 0.10) even
at very small `noise_scale` values. Inspecting the actual Fisher magnitude
distribution for this architecture explained why: median Fisher value
≈1.9e-8, maximum ≈8.2e-6 — `epsilon=1e-6` is *larger* than the median
Fisher value across ~98% of parameters, so `1/sqrt(F+epsilon)` collapsed
to a nearly-constant large multiplier instead of actually differentiating
important from unimportant parameters, defeating the entire mechanism the
method depends on. Fixed by reducing epsilon to 1e-10 (well below the
observed Fisher range), after which a proper dose-response curve emerged
and a usable operating point (`noise_scale=3e-6`) was found by direct
calibration.

A second bug, found the same way: the first version wrapped the entire
`scrub()` method in `@torch.no_grad()`, which silently broke the internal
`FisherInformation.compute()` call (it needs gradients enabled for its own
`loss.backward()`), raising "element 0 of tensors does not require grad."
Fixed by only wrapping the noise-injection step (which modifies `.data`
directly and needs no gradient tracking) in a local `with torch.no_grad():`
block, leaving the Fisher computation outside it.

### 19.2 Exploratory comparison (n=15, one fixed calibration point)

Using the same 15 seeds as §18's generalization check, at
`forget_fraction=0.10`:

```
                          mean score            catastrophic failures
A (fixed hyperparameters): 3.9698 ± 0.1746        0/15
B (full system):           4.0403 ± 0.1248        0/15
E (Fisher Forgetting):     3.0922 ± 3.6239         1/15  (retain_floor fired)
E excluding that failure:  4.0274 ± 0.1271         (n=14)
```

**When it doesn't fail, Fisher Forgetting performs comparably to B** —
4.0274 excluding the one failure is close to B's 4.0403, well within the
kind of gap this document's own §17.4 needed 55 seeds to resolve
confidently. This alone would be a modest, unsurprising finding (a
reasonable literature method performs reasonably). The more interesting
result is the failure itself.

### 19.3 The robustness finding

One seed (1004) — using the *exact same* `noise_scale=3e-6` that worked
safely across the other 14 — triggered the retain_floor guardrail
(retain_acc collapsed). Neither condition A nor condition B failed
catastrophically on *any* of the 15 seeds, in this run or any other run in
this document. This points at a real, previously undocumented difference
in *robustness*, not just average performance: Fisher Forgetting's noise
scale is calibrated once, globally, independent of the specific
pretrained model's actual Fisher magnitude distribution — which this
section's own §19.1 finding shows can vary enough (across nothing more
than different random initialization seeds of the *same* architecture) to
push a safe-everywhere-else setting into catastrophic territory. The
dual-engine system's adaptive hyperparameter adjustment, by contrast,
responds to each run's own observed metrics rather than committing to one
fixed setting in advance — and, empirically here, never produced a
catastrophic failure across any seed in any experiment in this document.

**This should be stated at the calibration this evidence actually
supports, not stronger**: one fixed-noise-scale implementation of one
literature method failed on one of 15 seeds. This is not a general proof
that Fisher Forgetting (or single-shot scrubbing methods generally) are
unsafe, nor that this project's adaptive approach is unconditionally safer
— a more sophisticated implementation (per-layer noise normalization
rather than one global `noise_scale`, for instance) might well close this
gap. What it does establish: a concrete, reproducible instance where
fixed-in-advance calibration failed in a way adaptive-at-runtime
calibration did not, on the same task, same seeds, same architecture —
worth investigating further rather than either dismissing as a fluke or
inflating into a general claim.

### 19.4 What remains before "public release" is a reasonable framing

This section closes the most significant remaining research gap flagged
since round 2. Repository hygiene (`LICENSE`, `requirements.txt`,
`.gitignore`, a `tests/` directory with pytest coverage of this project's
own found-and-fixed bugs — the BatchNorm guard, the exploration-rate fix,
the gradient-clip fix, the critical Experience-Engine-never-touches-
weights constraint) was also added this round. Model-size and dataset
generalization remain untested and are reasonable to frame as future work
rather than a blocker, consistent with external review round 6's own
assessment. The Fisher Forgetting comparison here is exploratory (n=15,
one fixed calibration point, no pre-registration) in the same spirit as
§18's forget_fraction check — a real comparison now exists where none did
before, at a calibration this document is explicit about rather than
overselling.

Reproduce with: `python -m pytest tests/` (24 tests, converted from this
project's ad-hoc development-time verification) and the Fisher Forgetting
module directly via `modules/unlearning/fisher_forgetting_baseline.py`'s
`FisherForgettingBaseline` class.

---

*Generated by Unlearning Meta-Learning Research Prototype v2.3 — §19 added: the literature-baseline gap flagged since external review round 2 was finally closed (Fisher Forgetting), two real bugs were found and fixed by actually running it rather than assuming the implementation was correct (an epsilon-scaling error and a no_grad-scoping error that broke the internal Fisher computation), and an exploratory comparison surfaced a genuine, previously undocumented robustness difference (0/15 vs 0/15 vs 1/15 catastrophic failures) alongside comparable average performance — reported at the modest, exploratory confidence this evidence actually supports. Repository hygiene (LICENSE, requirements.txt, tests/) was also completed this round. This section also documents a sandbox environment reset that occurred mid-development (all of this section's artifacts — LICENSE, requirements.txt, .gitignore, tests/, the Fisher Forgetting module — were lost before being saved to persistent output and had to be reconstructed from the conversation record; the exploratory comparison numbers in §19.2-19.3 are the original results, preserved exactly rather than re-run, since the calibration and seeds were already fully documented).*

---

## 20. Closing a Measure-Without-Control Gap: MemoryTraceMapper → GradientAscentForgetter

A code-presentation request (external review round 7 — a heavily
neuroscience-metaphor-framed audit request, "Glymphatic Clearance" for
asymmetric damping of unwanted weights while protecting useful ones)
prompted a direct re-reading of `dream_replay.py` and `memory_trace.py`
against that criterion. One finding was worth acting on regardless of
the framing it arrived in: `MemoryTraceMapper` computes per-neuron
forget/retain selectivity — exactly the "what's safe to clear vs. what
must be protected" distinction the criterion calls for — but its output
(`forget_mask`, `retain_mask`, `selectivity`) was never actually consumed
by `GradientAscentForgetter`'s noise injection or ascent step, which
perturbed every parameter uniformly regardless. Measurement without
control — a real, previously undocumented implementation gap, not a
narrative one.

**On the framing this arrived in**: the audit request's criterion ①
(mobile NPU / smartwatch edge deployment) was a new requirement, not a
pre-existing one from §1-19 — flagged directly and accepted as a
"stretch goal" rather than a retroactive pass/fail standard, before any
code was presented. Criteria ②-④ were substantially relabelings of
already-built mechanisms (EWC/retain_floor, the NOOP action, §17.8's
Friedman-test discipline) — worth noting plainly rather than either
rejecting the reframing outright or adopting the biological vocabulary as
if it added explanatory power beyond what the existing engineering terms
already provide.

### 20.1 Design decision: continuous weighting, not binary masks

Two designs were proposed for closing the gap: a hard/soft binary mask
(external review round 7, Gemini — should retain-critical neurons get
zero noise or a small residual baseline?) or a continuous, selectivity-
score-weighted map (external review round 7, ChatGPT — use the raw
[0,1] selectivity value directly as a per-parameter noise multiplier,
optionally staged binary-first-then-soft). The continuous version was
implemented directly, which resolves the hard/soft question by making it
a spectrum rather than a binary choice: `MemoryTraceMapper.selectivity`
is itself a noisy, sample-based estimate (computed from a bounded
`max_samples` subset), so treating it as a confident binary gate would
overstate that estimate's precision. The continuous weighting was also no
more complex to implement than the binary version — no top-k thresholding
logic needed — so there was no real cost/benefit tradeoff favouring a
staged rollout in this specific case.

### 20.2 Implementation

`MemoryTraceMapper.to_parameter_weights(model) -> Dict[str, Tensor]`
converts per-neuron selectivity into a per-parameter map matching
`model.named_parameters()` exactly (broadcasting each layer's neuron-level
selectivity across the weight matrix's input dimension; bias and
BatchNorm scale/shift use it directly). Parameters `get_activations()`
never measures (the output layer, excluded by design) default to 1.0 —
neutral, identical to current behavior — rather than guessing.

`GradientAscentForgetter._inject_noise()` gained an optional
`selectivity_weights` parameter: `None` (default) reproduces the original
uniform-noise formula exactly (verified by a byte-for-byte regression
test — same RNG seed, same resulting parameters, with vs. without the
parameter omitted entirely); when provided, each parameter's noise is
additionally scaled by its weight before being added.

Wired into `UnlearningEngine.run_cycle()` behind a new opt-in flag,
`UnlearningConfig.selective_noise_enabled` (default `False`) — consistent
with every other extension in this document (the contextual bandit, the
grad-clip action, target-aware scoring): nothing about existing validated
results changes unless a user explicitly opts in.

### 20.3 Status: wired and tested, not yet rigorously compared

Six new tests (`tests/test_selective_noise.py`) cover: output shapes
matching parameter shapes exactly, the output-layer neutral-default,
weight values staying in a sane [0,1] range, the critical None-preserves-
original-behavior regression test, and an end-to-end run through
`UnlearningEngine.run_cycle()` with the flag enabled. All pass, and both
whole-class and instance-level regression scripts re-verified passing
with the (default, disabled) flag.

What this section does **not** claim: that selective noise injection
actually improves anything. A single exploratory run showed a slightly
higher retain_acc with the flag enabled (0.9838 vs. 0.9815) than without,
on one seed — not remotely enough evidence to report as a finding, given
this document's own repeated demonstrations (§17.1-17.4, §18) of how
unreliable single-seed comparisons are. Whether this mechanism is
actually worth using is an open question for a properly pre-registered
multi-seed comparison, not yet run — tracked as the natural next backlog
item, using the exact same discipline (`run_seed_batch.py`-style
accumulation, Friedman/Wilcoxon or paired t-test as appropriate,
pre-registered sample size) already established in §17.

Reproduce with: `python -m pytest tests/test_selective_noise.py`.

---

*Generated by Unlearning Meta-Learning Research Prototype v2.4 — §20 added: a genuine measure-without-control gap (MemoryTraceMapper's selectivity never reaching GradientAscentForgetter) was found via a code-presentation request framed in neuroscience metaphor, closed with a continuous selectivity-weighted noise map rather than a binary mask (resolving a hard/soft design question by making it a spectrum), wired in behind an opt-in flag with a byte-for-byte regression test proving default behavior is unchanged, and explicitly NOT yet claimed to improve anything pending the same pre-registered multi-seed rigor used everywhere else in this document.*

---

## 21. §20's Mechanism, Tested — Pre-Registered Stop at Stage 1

§20 explicitly deferred the question of whether selective noise injection
actually helps, pending a proper multi-seed comparison. This section runs
it, using a two-stage design (`precommit/commitment_selective_noise.txt`,
written before any data collection) specifically to avoid repeating
§17.3's optional-stopping mistake: Stage 1 (n=15, exploratory) exists
*only* to estimate an effect size for computing Stage 2's sample size —
not to make a significance claim — with the sample-size formula's
ceiling (80) and the resulting action pre-committed in advance for
whatever Stage 1's estimate turned out to be.

### 21.1 Stage 1 result

Condition B (existing full system, `selective_noise_enabled=False`) vs.
condition F (B + §20's mechanism enabled), same bandit+momentum
configuration as §17-19, paired by seed:

```
n = 15 (exploratory)

B (selective_noise=False): 4.0563 ± 0.0801
F (selective_noise=True):  4.0443 ± 0.0972
Delta (F - B):             -0.0120 ± 0.1045
F win rate:                60% (9/15)
Cohen's d:                 -0.114
```

Per the pre-registered formula, 80% power at this effect size requires
n≈600 — far beyond the pre-set ceiling of 80. The plan's own advance
instruction for exactly this outcome: this counts as "no practically
meaningful effect detected," not a signal to chase an impractically large
n or to run a nominally-confirmatory Stage 2 that would in fact still be
badly underpowered for an effect this small (any "significance" reached
at n=80 for a true effect of d≈−0.11 would more likely reflect sampling
noise than a reliable confirmation — running it wouldn't actually answer
the question, just dress up more noise as a second stage).

### 21.2 Stage 2: not run, per pre-registration

Consistent with the plan written before Stage 1's result was known, Stage
2 is not executed. This is the intended, correct behavior of the
ceiling/floor design, not a shortcut — the whole reason that clause was
written in advance was to commit, before seeing the data, to treating a
tiny Stage 1 effect size as an answer rather than an invitation to keep
sampling until something crosses a threshold.

### 21.3 Conclusion: §20's mechanism does not yet demonstrate practical value

The single-seed observation in §20.3 (retain_acc 0.9838 vs. 0.9815 with
the flag enabled) does not generalize — across 15 properly paired seeds,
the effect is indistinguishable from zero and, if anything, points the
other direction. This does not mean the underlying idea (weight
perturbation targeted by measured forget/retain selectivity rather than
applied uniformly) is wrong in principle — it means that, as currently
implemented, on this benchmark, at this model size, it makes no
practically detectable difference. Plausible reasons, none yet tested:
the selectivity signal itself may be too noisy at this model's small
hidden-layer width to provide a meaningfully different weighting than
uniform noise in practice; the effect may be real but smaller than d≈0.11
can resolve even at large n; or genuinely there is no effect here and a
different perturbation mechanism (targeting the ascent step itself,
rather than only the post-ascent noise injection) would be needed to see
one. None of these are distinguished by the data collected here, and
inventing a preferred explanation among them without further evidence
would repeat exactly the mistake this whole document has tried not to
make.

This closes the loop opened in §20: the mechanism is implemented,
correctly tested for not breaking anything (§20.3's six tests), and now
honestly evaluated for whether it helps — with a pre-registered,
non-peeked answer of "not detectably, at this sample size and this
effect-size ceiling" rather than either an unearned claim of success or
an indefinite deferral.

Reproduce with: `python -m unlearning_meta.run_selective_noise_comparison
--seeds 6000 6001 ... 6014` (regenerates the shipped
`seed_results/results_selective_noise.jsonl`; no-op if already present).

---

*Generated by Unlearning Meta-Learning Research Prototype v2.5 — §21 added: §20's selective-noise mechanism was tested via a two-stage pre-registered design specifically built to avoid §17.3's optional-stopping mistake, and its own advance-committed stopping rule correctly triggered at Stage 1 (Cohen's d=-0.114, implying an impractical n≈600 for confirmation) — concluding "no practically meaningful effect detected" without running an underpowered Stage 2, exactly as pre-registered before the data were seen.*

---

## 22. Testing §19.3's Own Hypothesis: Per-Layer Epsilon Normalization for Fisher Forgetting

§19.3 found a genuine, previously undocumented robustness gap in the
literature Fisher Forgetting baseline: a single global `epsilon` floor,
calibrated once on seed=42, triggered the `retain_floor` guardrail on
seed=1004 (of the same 15 exploratory seeds) at the identical
`noise_scale=3e-6` that was safe on the other 14 — and speculated,
without yet testing it, that "a more sophisticated implementation
(per-layer noise normalization rather than one global `noise_scale`)
might well close this gap." This section implements that specific fix
and checks it against the exact case that motivated it. Whether it holds
up as a *general* improvement is a separate, still-open question — see
`IDEAS.md` #1 rather than this section, which (per a documentation
proposal adopted this round — see this section's footer) is restricted
to what has actually been implemented and run.

### 22.1 Why per-layer, specifically

`FisherForgettingBaseline` already weights noise inversely per
*parameter* (`noise_std = noise_scale / sqrt(F + epsilon)`, and `F` is a
full per-parameter tensor, not a scalar) — but `epsilon` itself has
always been one Python float shared by every layer in the model. §19.1's
own calibration reasoning already establishes why this is a problem: if
`epsilon` is much smaller than a layer's typical Fisher magnitude, the
inverse weighting works as intended; if `epsilon` is comparable to or
larger than it, `1/sqrt(F+epsilon)` collapses toward a constant and the
"protect important parameters" mechanism degenerates. §19.1 tuned
`epsilon=1e-10` against the *whole model's* median Fisher value
(~1.9e-8). That is only correct if every layer's typical Fisher
magnitude is close to that global median — which there is no reason to
expect in general, and which can plausibly vary seed-to-seed for the
*same* layer, given nothing more than a different random initialization
and training trajectory. A layer whose Fisher values happen to sit far
below the global median, for one specific seed, gets a floor calibrated
for a different, larger scale — under-protected against its own
near-zero entries, which is a direct mechanism for exactly the kind of
one-seed catastrophic blow-up §19.3 found.

### 22.2 Implementation

`modules/unlearning/fisher_forgetting_baseline.py::FisherForgettingBaseline`
gained two new constructor parameters, both defaulting to values that
leave existing behavior completely unchanged:

```python
FisherForgettingBaseline(noise_scale=0.1, epsilon=1e-10, device="cpu",
                         per_layer_normalize=False,
                         per_layer_eps_fraction=0.01)
```

- `per_layer_normalize=False` (default): identical to §19's original
  formula, byte-for-byte — every call site that doesn't pass this
  argument is completely unaffected.
- `per_layer_normalize=True`: each named parameter tensor's floor
  becomes `max(epsilon, per_layer_eps_fraction * median(F_layer))` —
  proportional to that specific layer's own median Fisher value in the
  current run, with the original global `epsilon` retained as an
  absolute safety net for a layer whose own median is itself ~0 (e.g. a
  dead layer, where no proportional floor would help).

This floor computation is factored into its own method,
`_effective_epsilon(f)`, specifically so the "default is unchanged"
claim is directly unit-testable without needing to reproduce `scrub()`'s
random noise draws: `test_effective_epsilon_default_matches_original_
global_epsilon` asserts `_effective_epsilon` returns exactly
`self.epsilon` for four Fisher tensors spanning the observed range
(1e-15 to 8.2e-6, plus all-zero) — i.e. it provably ignores `f` entirely
when the flag is off. Two more unit tests cover the enabled path (floor
scales with a layer's own median; the absolute floor still wins for a
dead layer), plus an integration smoke test that `scrub()` runs
end-to-end with the flag on and still leaves the input model untouched.
All 8 tests in `tests/test_fisher_forgetting_baseline.py` pass (34/34
across the full suite).

`per_layer_eps_fraction=0.01` is a first, deliberately untuned choice —
close to the original global epsilon's relationship to the *typical*
layer in §19.1's measurement, rather than a value searched or tuned
against seed=1004 specifically, which would risk fitting a fix to the
one case already known to fail rather than to the general mechanism.

### 22.3 Checked against the exact case that motivated it

Using the identical 15 seeds, identical `noise_scale=3e-6`/`epsilon=1e-10`,
and identical scoring (`target_forget_acc`, `retain_floor=0.90`) as
§19.2 — changing *only* `per_layer_normalize` — paired by seed against
the same pretrained starting model for both conditions:

```
                                mean score   std      catastrophic
E  (original, global eps):     3.0770       3.4985    1/15
E' (per-layer normalized):     4.0592       0.1553    0/15
E  excl. its own failure:      4.0111       0.1622    (n=14)
E' excl. its own failure:      4.0592       0.1553    (n=15, none to exclude)

seed=1004 specifically:
  E:  score=-10.0000  retain_acc=0.8775  (retain_floor fired)
  E': score= 4.1679   retain_acc=0.9961  (no guardrail triggered)
```

Two things are directly verified by this run. First, the reproduction:
re-running condition E from scratch (fresh environment, current library
versions) reproduces both the *existence* of a catastrophic failure at
n=15 and its *location* — seed=1004 fails here exactly as it did in
§19.2/§19.3's original run. Second, the fix: under identical conditions
otherwise, per-layer normalization keeps seed=1004 comfortably clear of
the guardrail (retain_acc 0.9961, far above the 0.90 floor) and produces
zero catastrophic failures across all 15 seeds.

These 15 seeds were reused deliberately, *because* one of them is the
known failure case — which is exactly what makes this a direct check of
"does the fix resolve the known problem" (it does), and exactly what
disqualifies it from being read as a blind estimate of general average
performance (it can't be — the sample was never a fair draw for that
question). The observed mean scores above (4.0592 for E' vs. 4.0111 for
E excluding its own failure) are reported as what this specific run
produced, not as evidence of a general improvement; whether per-layer
normalization holds up on seeds that were not selected for containing a
known failure is the open question tracked as `IDEAS.md` #1, with a
pre-registered design (`precommit/commitment_fisher_forgetting_per_layer.txt`)
already written and ready to run.

Reproduce with: `python -m unlearning_meta.run_fisher_forgetting_robustness_check`
(writes `seed_results/results_fisher_forgetting_per_layer.jsonl`).

---

*Generated by Unlearning Meta-Learning Research Prototype v2.6 — §22
added: §19.3's own suggested fix (per-layer epsilon normalization) was
implemented as an opt-in `per_layer_normalize` flag with default
behavior proven unchanged via a dedicated unit test on the extracted
`_effective_epsilon` method (no dependence on stochastic reproduction),
then checked against the exact seeds/configuration that originally
surfaced the seed=1004 catastrophic failure — which the fix resolves
(retain_acc 0.9961 vs. the original 0.8775-triggered guardrail), with
zero catastrophic failures across all 15 seeds. Documentation change
adopted this round: this file is now restricted to implemented,
already-run findings only — the open question of whether this fix
generalizes as an average-performance improvement, along with its
pre-registered confirmatory design, lives in the new companion file
`IDEAS.md` instead of being narrated here, so a reader of this file is
never left guessing whether a claim is a finding or a plan.*

---

## 23. `IDEAS.md` #1, Tested — Pre-Registered Stop at Stage 1

`precommit/commitment_fisher_forgetting_per_layer.txt` (§22, `IDEAS.md`
#1) asked whether per-layer epsilon normalization improves *average*
performance on seeds not selected for containing the known seed=1004
failure case — the question §22's own reused-seed check was explicit it
could not answer. Stage 1 (n=15, fresh seeds 7000-7014, not overlapping
any seed used anywhere else in this document) has now been run.

```
n = 15 fresh seeds (7000-7014)
mean(E' - E) = -0.0290   sample std = 0.1581   Cohen's d = -0.1834
catastrophic failures: E=0/15   E'=0/15
```

Zero catastrophic failures in *either* condition on this batch — unlike
§22's reused seeds, none of these 15 happened to trigger the original
bug, so this batch is a clean, uncontaminated read on the
average-performance question specifically. The point estimate is small
and slightly negative (per-layer normalization scoring marginally
*lower* on average here, not higher — 7 of 15 seeds favor E', 8 favor
E), with `|d|`=0.1834 implying a Stage 2 n of 233, far past the
pre-registered ceiling of 80.

Per the plan's own advance instruction, written before this data was
collected: an effect this small, at this ceiling, is treated as "no
practically meaningful effect detected," and Stage 2 does not run. This
is §21's pattern repeating for a different mechanism — a small,
directionally inconsistent per-seed delta that averages out to noise at
any sample size this project can realistically collect.

**This does not reopen §22.** The seed=1004 fix is a separate,
already-verified claim (a specific documented failure, reproduced, and
shown not to recur under the fix) that does not depend on this result.
What Stage 1 closes out is only the broader hypothesis — average
performance across typical seeds — which `IDEAS.md` #1 was explicit
could not be answered by §22's own check. The honest combined picture:
per-layer normalization fixes the one concrete robustness problem this
project has ever found in this baseline, with no detectable cost or
benefit to average-case performance on seeds that don't hit that
problem. That is arguably exactly what a targeted floor-calibration fix
*should* do, and is a more modest, more defensible claim than "improves
the baseline" would have been.

Reproduce with: `python -m unlearning_meta.run_fisher_forgetting_confirmatory
--seeds 7000 7001 7002 7003 7004 7005 7006 7007 7008 7009 7010 7011 7012 7013 7014`
(writes `seed_results/results_fisher_forgetting_confirmatory.jsonl`;
no-op if already present).

---

*Generated by Unlearning Meta-Learning Research Prototype v2.7 — §23
added: `IDEAS.md` #1's pre-registered Stage 1 (n=15 fresh seeds) found
Cohen's d=-0.1834 for per-layer normalization's average-performance
effect, implying a Stage 2 n of 233 against a pre-committed ceiling of
80 — concluding "no practically meaningful effect detected" and correctly
not running Stage 2, exactly as pre-registered before the data were
seen. `IDEAS.md` #1 updated to reflect this and no longer tracked as
open.*

---

## 24. `IDEAS.md` Idea 3, Tested — Selective Gradient Ascent, and a 2x2 Factorial Pre-Registered Stop at Stage 1

Both external reviews in round 3 (`IDEAS.md`, "External Review Round 3")
converged with this project's own §21.3 on the same next hypothesis:
does connecting `selectivity_weights` to the gradient ASCENT step itself
— not only post-ascent noise injection, §20/§21's mechanism — produce a
detectable effect? This section implements that (`selective_ascent_enabled`),
calibrates it against this architecture's actual measured values rather
than guessed constants, tests it via a pre-registered 2x2 factorial, and
reports what that factorial actually found — which is not what either
external review, or this project's own §21.3, predicted.

### 24.1 Calibration before implementation

The proposed mechanism (external review, `IDEAS.md` Idea 3):
`g'_i = g_i * (alpha * s_i + beta)`, continuous rather than a binary
mask, consistent with this project's existing preference (§20 already
treats selectivity as continuous, explicit about the risk of treating a
sample-based estimate as a hard 0/1 decision).

Before picking `alpha`/`beta`, their actual inputs were measured on this
project's own model/data — the same discipline §19.1 applied to
`epsilon` (and which the external review did not itself specify a value
for). Result, measured directly (3 seeds, instance-level forgetting):
raw selectivity is tightly clustered around 0.5 (mean~0.50, std~0.03,
full range roughly [0.39, 0.59]). This is expected once stated plainly —
forget and retain are different SAMPLES of the *same* classes in this
benchmark, not different classes, so most neurons' activation
statistics are naturally similar either way — but it matters
mechanically: feeding that ~0.2-wide raw range through `alpha=1, beta=0`
would only ever produce multipliers in roughly [0.89, 1.09]. That is too
narrow a manipulation to fairly test whether selective ascent does
anything at all; a null result from it would be at least partly
explained by the input signal barely varying, not necessarily by the
mechanism not working.

`MemoryTraceMapper.to_ascent_weights()` (`modules/unlearning/memory_trace.py`)
therefore min-max normalizes selectivity to [0, 1] across all covered
neurons *before* applying `alpha`/`beta`, decoupling the effect size from
how compressed the raw selectivity happens to be for a given seed or
task. With the resulting defaults (`alpha=1.0, beta=0.5`), the least-
selective neuron in any given computation gets multiplier 0.5 (suppressed
but not frozen) and the most-selective gets 1.5 (amplified) — a full,
meaningful range, always, regardless of the raw spread. Layers this class
has no activation data for (`output_layer`) get an explicit, unscaled
multiplier of 1.0 — not `alpha*1.0+beta` — since 1.0 is not this
transform's neutral value (0.5 is); passing an uncovered layer through
the transform would have silently and always amplified it. The
degenerate case (a run where every covered neuron's selectivity is
numerically identical, spread≈0) is floored to the neutral 0.5 rather
than dividing by a near-zero spread.

### 24.2 Implementation

`GradientAscentForgetter.run()` gained an `ascent_weights` parameter,
applied via a new `_scale_ascent_gradients()` call after `loss.backward()`
and before `clip_grad_norm_` — that ordering matters: clipping rescales
the whole gradient vector by one global scalar if its norm exceeds
`max_grad_norm`, so scaling first means clipping only caps the overall
magnitude and preserves the *relative* per-parameter differences this
mechanism introduces. Default (`ascent_weights=None`) leaves every
gradient exactly as computed — no scaling call happens at all, not a
no-op scaling call — verified directly (not just by code inspection) via
`test_ascent_weights_none_never_calls_scale_ascent_gradients`, which
mocks the scaling method and asserts it is never invoked when the
parameter is omitted. Wired into `UnlearningConfig` as
`selective_ascent_enabled` (default `False`) plus
`selective_ascent_alpha`/`selective_ascent_beta`, and into
`UnlearningEngine.run_cycle()`, mirroring `selective_noise_enabled`'s
existing wiring exactly (same file, same pattern, same opt-in
default-preserving structure).

Neither `gradient_ascent.py` nor `memory_trace.py` had a dedicated test
file before this section — `tests/test_gradient_ascent.py` (7 tests) and
`tests/test_memory_trace.py` (6 tests) were added, covering the
normalization math in isolation (no model training needed), the
neutral-default-for-uncovered-layers property, the degenerate-spread
floor, and an end-to-end check that asymmetric ascent weights actually
change training dynamics relative to unweighted ascent. All 47 tests in
the suite pass (34 before this section + 13 new).

### 24.3 Pre-registered 2x2 factorial

A single selective-ascent-vs-not comparison would be ambiguous — per the
external review's own point — between "selectivity doesn't help" and
"selectivity doesn't help when noise injection is also selective (or
isn't)". `precommit/commitment_selective_ascent.txt` (written before any
of this comparison's new data was collected) pre-registers a 2x2
factorial instead:

```
       Noise: uniform   Noise: selective
Ascent: uniform    UU              SU
Ascent: selective  US              SS
```

UU and SU are exactly §21's B and F conditions (`selective_ascent_enabled`
did not exist when that data was collected, so ascent was implicitly
uniform throughout) — reused directly from
`seed_results/results_selective_noise.jsonl` at seeds 6000-6014, rather
than re-run, exactly as §17.8's C/D ablation reused §17.4's A/B scores on
the same seeds. US and SS are new, collected on those same 15 seeds,
paired. Labeled UU/SU/US/SS specifically to avoid colliding with this
document's pre-existing, unrelated A/B/C/D labels from §17.4/§17.8.

Primary pre-registered contrast — the actual Idea 3 hypothesis, averaged
over both noise settings so it isolates ascent selectivity specifically:

```
Effect_ascent = [ (US - UU) + (SS - SU) ] / 2
```

```
  seed       UU       SU       US       SS
  6000   4.1019   4.0054   4.1031   4.0124
  6001   3.9571   3.9990   3.9740   3.8787
  6002   3.9909   4.0725   3.9953   4.0275
  6003   4.0563   4.0968   4.0540   4.0911
  6004   4.2220   4.0220   4.2821   4.2925
  6005   4.1141   4.2775   4.1882   3.8282
  6006   3.9382   3.9602   3.9288   3.9262
  6007   4.1068   3.9740   4.1003   4.0959
  6008   4.0945   3.8907   4.1421   4.1583
  6009   4.0477   4.0333   4.0421   4.0750
  6010   4.0983   4.1694   3.9733   4.2529
  6011   3.9167   3.9518   3.9641   4.0731
  6012   4.0459   4.0068   3.9632   4.0477
  6013   4.0405   4.0711   4.0322   4.0166
  6014   4.1135   4.1348   4.1083   4.0994

Effect_ascent (PRIMARY): mean=+0.0072  sample_std=0.0859  d=+0.0842  n=15
Effect_noise  (secondary): mean=-0.0052  sample_std=0.0769  d=-0.0672  n=15
Interaction   (descriptive, underpowered at this n): mean=+0.0136  d=+0.0740
```

`|d|`=0.0842 implies a Stage 2 n of 1,105 — far past the pre-registered
ceiling of 80. Per the plan's own advance instruction: "no practically
meaningful effect detected," Stage 2 not run. `Effect_noise` at this n
also lands near zero (d=-0.0672), broadly consistent with — not a
contradiction of — §21's original noise-only finding (d=-0.114); the
`Interaction` term, exactly as pre-registered as "descriptive only,"
isn't resolvable at n=15 and isn't claimed to be.

### 24.4 What actually happened, versus what was predicted

This is worth stating plainly rather than quietly filing away: two
independent external reviews and this project's own §21.3 all converged
on selective ascent as the well-motivated next step, for good reasons —
and it did not show a detectable effect either, at an effect size
smaller than even §21's original null result. That convergence was a
reasonable basis for *prioritizing what to test next*; it was never
evidence about what the test would find, and it didn't turn out to
predict it. This is precisely why this project pre-registers before
collecting comparison data regardless of how well-motivated a hypothesis
seems — including, and perhaps especially, when multiple independent
sources agree on it in advance.

A specific, falsifiable hypothesis for *why*, worth stating rather than
leaving implicit: §24.1's calibration finding may point past the
noise-vs-ascent question entirely. Selectivity is narrow (std~0.03
around 0.5) specifically because this benchmark's forget and retain sets
are different SAMPLES of the *same* classes, not different classes — so
there may be little genuine forget-vs-retain distinction for
`MemoryTraceMapper` to find here in the first place, largely independent
of which downstream mechanism (noise, ascent, or both) that signal gets
routed to. If so, the more fundamental open question was never "noise or
ascent" but "does this task give selectivity anything real to detect" —
which points back toward generalization (§19.4's already-flagged gap):
does selectivity show a clearer signal, and a clearer effect on either
mechanism, on CLASS-level forgetting (structurally different forget vs.
retain data) rather than instance-level? Untested; a reasonable next
thread, not pursued in this section.

Reproduce with: `python -m unlearning_meta.run_selective_ascent_comparison
--seeds 6000 6001 6002 6003 6004 6005 6006 6007 6008 6009 6010 6011 6012 6013 6014`
(reads existing UU/SU from `results_selective_noise.jsonl`, writes new
US/SS to `seed_results/results_selective_ascent.jsonl`; no-op re-analysis
if already present).

---

*Generated by Unlearning Meta-Learning Research Prototype v2.8 — §24
added: `IDEAS.md` Idea 3 (Selective Gradient Ascent, converged on by
external review round 3 and this project's own §21.3) was implemented
as `selective_ascent_enabled`, calibrated against this architecture's
actually-measured selectivity distribution (found tightly clustered
around 0.5, motivating a normalize-then-scale design rather than the
raw-selectivity approach the review proposed), covered by 13 new tests
(47/47 passing), and tested via a pre-registered 2x2 factorial isolating
ascent selectivity's effect from noise selectivity's. Stage 1 (n=15,
partly reusing §21's UU/SU data, partly new US/SS data) found
Cohen's d=+0.0842 for the primary Effect_ascent contrast, implying a
Stage 2 n of 1,105 against the pre-committed ceiling of 80 — concluding
"no practically meaningful effect detected" and correctly not running
Stage 2, despite this being the direction two independent external
reviews and this project's own prior analysis all predicted would work.
`IDEAS.md` Idea 3 updated to reflect this and no longer tracked as open.*

---

## 25. `IDEAS.md` Idea 9 Phase 1 — the Selectivity Signal Itself, Measured Directly

Round-4 external review's refinement of §24.4's hypothesis: before
testing whether selectivity helps on a different task, check whether
selectivity *carries different information* on that task at all — a
diagnostic, not a performance comparison. This section is that
diagnostic.

### 25.1 Design

Same model architecture (`MLP(64, [128,64], 10)`), same 3 seeds
(42, 123, 777) as §24.1's original calibration, same measurement code
(`MemoryTraceMapper.compute()` then mean/median/std/min/max/p10/p90 over
every covered neuron), changing only the task structure:

- **Instance-level** (this project's benchmark since §12,
  `load_digits_instance_forgetting`): forget/retain are different
  SAMPLES of the same 10 classes.
- **Class-level** (`load_digits_unlearning_datasets`, `forget_classes=[0]`
  — this project's *original* benchmark, §10 and earlier, superseded
  for forgetting-performance evaluation from §12 onward specifically
  because it was found too easy on that axis; never before checked on
  the selectivity-signal axis specifically, which is a different
  question): forget/retain are structurally different classes.

No noise, no ascent, no `composite_score` — this measures
`MemoryTraceMapper`'s raw output only.

### 25.2 Result

```
                mean(mean)   mean(std)   mean(max-min)
instance-level    0.5013       0.0303        0.1636
class-level       0.3007       0.2958        0.9016

class-level std / instance-level std = 9.76x
```

Per-seed detail (n=192 covered neurons each):

```
                seed    mean    median   std     min     max     p10     p90
instance-level  42     0.5012  0.5001  0.0289  0.4382  0.5647  0.4603  0.5372
instance-level  123    0.5046  0.5028  0.0314  0.4252  0.5946  0.4684  0.5481
instance-level  777    0.4980  0.4998  0.0307  0.3889  0.5838  0.4550  0.5352
class-level     42     0.2951  0.1631  0.2963  0.0000  0.9018  0.0133  0.7910
class-level     123    0.3022  0.1861  0.2853  0.0000  0.9147  0.0160  0.7378
class-level     777    0.3046  0.1633  0.3059  0.0000  0.8883  0.0082  0.7939
```

Not a marginal difference. Class-level selectivity spans nearly the
full possible [0,1) range in every seed (max consistently >0.88, min at
or near 0.0000) with a std almost 10x larger than instance-level's — a
qualitatively different distribution, not a noisier version of the same
one (instance-level is unimodal and tight around 0.5; class-level's
median sitting well below its mean, ~0.16 vs ~0.30, indicates a skewed,
long-tailed shape — most neurons carry little forget-vs-retain
information even here, but a meaningful minority carry a great deal,
which is exactly the kind of structure a selectivity-weighted mechanism
would have something real to act on).

### 25.3 What this does and does not establish

This substantially strengthens §24.4's hypothesis with a direct
measurement rather than an inference from two null results: the
instance-level benchmark gives `MemoryTraceMapper` very little to find
in the first place (§24.1's original point, now with a contrast case
confirming it isn't simply how this class always behaves), independent
of whichever downstream mechanism that signal is routed to. §21 and
§24's null findings remain exactly as reported — this doesn't change
what happened on instance-level — but it reframes what those nulls most
likely mean: not "selectivity-weighted noise/ascent don't work as
mechanisms," but "neither mechanism had a real signal to weight by, on
the specific benchmark both were tested on."

What this does not establish, per Idea 9's own pre-registered-style
framing (a diagnostic, not a performance claim): that selective
noise/ascent will show a detectable effect on class-level forgetting. A
wide, informative selectivity distribution is what a selectivity-based
mechanism needs in order to have a chance of mattering — necessary-
looking, not sufficient. Whether it actually improves the
forget/retain tradeoff, measured the same target-aware,
retain-floor-guarded way as every other comparison in this document,
is Idea 9 Phase 2 — untested, and the natural next step if this thread
continues.

Reproduce with: `python -m unlearning_meta.run_selectivity_generalization_phase1`
(prints the full per-seed table; writes no results file, since this
step keeps no comparison to score — it is a measurement, not a
comparison).

---

*Generated by Unlearning Meta-Learning Research Prototype v2.9 — §25
added: `IDEAS.md` Idea 9 Phase 1 (round-4 external review's
diagnostic-before-performance refinement of §24.4's hypothesis) measured
`MemoryTraceMapper`'s selectivity distribution directly on class-level
vs. instance-level forgetting, same model/seeds/code otherwise. Result:
class-level selectivity std is 9.76x instance-level's (0.296 vs. 0.030),
spanning nearly the full [0,1) range in every seed versus instance-
level's tight band around 0.5 — strong, direct support that §21/§24's
null results most likely reflect the instance-level benchmark giving
the mechanism little genuine signal, not a failure of the noise/ascent
mechanisms themselves. Does not by itself establish that selective
mechanisms improve class-level forgetting performance — that remains
Idea 9 Phase 2, untested.*

---

## 26. `IDEAS.md` Idea 9 Phase 2 — Selective Noise Confirmed Harmful on Class-Level Forgetting; Selective Ascent Still Null

§25 established that class-level forgetting gives `MemoryTraceMapper` a
far richer selectivity signal than the instance-level benchmark §21 and
§24 were tested on. `precommit/commitment_class_level_selective.txt`
(written before any of this section's data was collected) pre-registers
re-testing both mechanisms on class-level forgetting, now that signal
starvation is no longer a plausible confound. The result is not the
simple "now it works" this section's own motivation might suggest — one
mechanism remains null, and the other shows a real, but harmful, effect.

### 26.1 Design

Identical 2x2 factorial structure to §24 (UU/SU/US/SS, same target-aware
scoring, same bandit+momentum system), on `load_digits_unlearning_datasets`
(`forget_classes=[0]`) instead of instance-level. Unlike §24, no existing
data could be reused — all four conditions collected fresh. Both
`Effect_ascent` and `Effect_noise` treated as primary (unlike §24, where
noise was secondary — neither mechanism had been tested on class-level
before this section). A pilot check (single seed, UU only, not treated
as comparison data) found `retain_acc` reaches 1.0000 almost immediately
on this task and stays there regardless of condition — forgetting one
class doesn't interfere with classifying the other nine — so
differentiation between conditions was expected to show up as
convergence speed (reflected in the mean `composite_score` across
cycles, the same primary measure used throughout this document) rather
than differential retain protection.

### 26.2 Stage 1 (n=15, seeds 9000-9014)

```
Effect_ascent (PRIMARY): mean=+0.0091  d=+0.2216*  n=15
Effect_noise  (PRIMARY): mean=-0.0330  d=-0.8330   n=15
Interaction   (descriptive):            n=15
```
*(§26 Stage 1's own console output; recomputed here with the same
paired-difference method as every other Stage 1 in this document.)*

`Effect_ascent`: implied Stage 2 n=94,939 — even with class-level's far
richer selectivity signal, selective ascent shows no more of an effect
than it did on instance-level (§24: d=+0.0842). **Closed here per
pre-registration: no practically meaningful effect detected, Stage 2 not
run.** This is worth sitting with rather than passing over: signal
richness alone did not rescue this mechanism, which weakens (without
ruling out entirely) the pure "signal starvation" explanation for
selective ascent specifically, as opposed to selective noise.

`Effect_noise`: implied Stage 2 n=13.8, floor-adjusted to 30 — within
the pre-registered ceiling. **Proceeds to Stage 2**, per the plan's own
advance instruction.

### 26.3 Stage 2 (confirmatory, n=30, seeds 10000-10029)

```
n = 30
mean Effect_noise = -0.0351
sample std         =  0.0466
t(29)              = -4.1297
p (two-tailed)      =  0.000281
Cohen's d           = -0.7540
95% CI              = [-0.0525, -0.0177]
```

A large, statistically significant effect, consistent in sign and
magnitude with Stage 1's exploratory estimate (d=-0.833 → -0.754), and
the 95% CI excludes zero comfortably. Analyzed exactly once, per
pre-registration.

**This is a confirmed effect in the direction opposite to what the
mechanism intends.** Selective noise injection, on class-level
forgetting, measurably *hurts* mean `composite_score` relative to
uniform noise injection — the first mechanism in this document's entire
history of selective-mechanism testing (§21, §23's Fisher work, §24) to
show a properly-powered, statistically significant effect at all, and
it is a harmful one.

`cycles_to_target` (pre-registered as a descriptive metric, mean cycles
until `forget_acc` first lands within 0.02 of target):

```
                UU      SU      US      SS
Stage 1 (n=15) 3.27    3.40    3.27    3.13
Stage 2 (n=30) 3.27    3.13    3.10    3.13
Combined(n=45) 3.27    3.22    3.16    3.13
```

Essentially flat across all four conditions — see §27.1 for what this
means for §26.4's causal story below.

### 26.4 Why, plausibly — and how to check it

§25's own measured distributions offer a specific, checkable
explanation rather than leaving this as a bare surprising fact.
`to_parameter_weights()` (the function `selective_noise_enabled` uses)
passes RAW, unnormalized selectivity directly into
`noise = noise * weight` — deliberately unlike `to_ascent_weights()`
(§24.1), which normalizes first specifically because raw values were
found too compressed to matter on instance-level. §25 measured mean raw
selectivity at 0.5013 for instance-level but only 0.3007 for
class-level. Since `noise_scale` was calibrated (§17 onward) assuming
roughly uniform noise application, selective noise's AVERAGE effective
multiplier is roughly half-strength on instance-level (~0.50 — a modest
perturbation, consistent with §21's small, non-significant effect) but
only around three-tenths-strength on class-level (~0.30) — a
meaningfully weaker aggregate scrub under the identical `noise_scale`
that uniform noise uses at full strength. A systematically
under-scrubbed model would plausibly converge to the forgetting target
more slowly over the 25-cycle budget, which is exactly what a lower mean
`composite_score` reflects. This is offered as a plausible, specific
mechanism consistent with measurements already in hand — not
independently verified by a dedicated follow-up in this section, and
stated at that calibration rather than a stronger one.

If correct, the practical implication is not "selective noise is a bad
idea" so much as "selective noise's effective strength needs to be
renormalized against its own mean, the same fix §24.1 already applied to
selective ascent for a different reason" — untested, and not pursued
here; recorded as a candidate explanation rather than built into a new
mechanism, consistent with this document's practice of not chasing every
new hypothesis a result suggests without first deciding it's worth the
scope.

### 26.5 Combined picture

Two mechanisms, two different outcomes, once given a task where the
input signal is actually rich:

- **Selective ascent**: null on both instance-level (§24, d=+0.084) and
  class-level (§26, d=+0.22, well short of the pre-registered bar).
  Signal richness didn't rescue it — the more parsimonious explanation
  at this point is that scaling the ascent gradient by selectivity
  specifically doesn't move this benchmark's outcome, not that it was
  merely signal-starved.
- **Selective noise**: null on instance-level (§21, d=-0.114, signal-
  starved per §25) but a confirmed, significant, *harmful* effect on
  class-level (§26, d=-0.754) — plausibly a calibration artifact
  (§26.4) rather than evidence the underlying idea (protect important
  parameters, scramble unimportant ones) is unsound.

Reproduce with: `python -m unlearning_meta.run_class_level_selective_comparison
--seeds 9000 9001 ... 9014` (Stage 1) then `--seeds 10000 10001 ... 10029`
(Stage 2); writes `seed_results/results_class_level_selective.jsonl`,
resumable/no-op on already-collected seeds.

---

*Generated by Unlearning Meta-Learning Research Prototype v3.0 — §26
added: `IDEAS.md` Idea 9 Phase 2, pre-registered per
`precommit/commitment_class_level_selective.txt`. Stage 1 (n=15) closed
`Effect_ascent` as null (d=+0.22, implied n=94,939) and advanced
`Effect_noise` to Stage 2 (d=-0.83, implied n=13.8). Stage 2 (n=30,
confirmatory) found `Effect_noise` = -0.0351, t(29)=-4.13, p=0.00028,
d=-0.754, 95% CI=[-0.053,-0.018] — a large, statistically significant
effect, and the first properly-powered significant result across every
selective-mechanism comparison in this document, in the direction
opposite the mechanism's intent. §26.4 offers a specific, checkable
candidate explanation (raw vs. normalized selectivity weighting, echoing
§24.1's fix for a different mechanism) without independently verifying
it. `IDEAS.md` Idea 9 updated to reflect both results.*

---

## 27. Caught During Review: §26.4's Speed Story Doesn't Hold Up, and a Calibration Gap Shared by Both Mechanisms

A review pass over §26 checked two things §26 itself did not: whether
the pre-registered `cycles_to_target` metric actually supports the
causal story §26.4 offered, and whether §24.1's normalization fix for
selective ascent actually solves the same problem §26.4 diagnoses for
selective noise. Neither checked out as originally assumed.

### 27.1 The "slower convergence" story is not supported

§26.4 attributed selective noise's harmful effect to systematic
under-scrubbing causing slower convergence to the forgetting target.
§26.3's `cycles_to_target` numbers, added on review, directly test this
and don't support it: UU/SU/US/SS reach the target in essentially the
same ~3.1-3.3 cycles on average, no condition systematically slower.
Whatever separates the conditions on mean `composite_score`, it is not
how quickly `forget_acc` first crosses the target threshold.

The more likely explanation, not independently verified here: mean
`composite_score` averages over all 25 cycles, so a condition that
reaches the target early but then drifts or oscillates away from it in
later cycles would score lower than one that reaches it at the same
cycle and stays there — a stability difference invisible to a
first-crossing metric like `cycles_to_target`. Distinguishing this from
other possibilities would need the full per-cycle trajectory, which
this section did not save (only the mean score and first-crossing cycle
per run) — exactly the gap `IDEAS.md` Idea 5 (per-cycle observability
logging) already exists to close. §26's confirmed statistical result
(d=-0.754, p=0.00028) is unaffected by this — only the specific
mechanism offered to explain *why* is weakened.

### 27.2 `to_ascent_weights()`'s normalization has the same gap, to a lesser degree

§24.1 normalized selectivity to [0,1] specifically to fix a calibration
problem (raw selectivity too compressed to matter on instance-level).
Checked directly against class-level data (same 3 seeds as §25, using
`to_ascent_weights(model, alpha=1.0, beta=0.5)` and averaging the
resulting multiplier over exactly the parameters `MemoryTraceMapper`
covers):

```
seed    raw selectivity          ascent multiplier (covered params)
        mean     median          mean     median      (neutral = 1.0)
42      0.2951   0.1631          0.8266   0.6706
123     0.3022   0.1861          0.8289   0.6953
777     0.3046   0.1633          0.8358   0.6758
```

Min-max normalization fixes the *range* (every computation spans the
full [0,1] before alpha/beta), but does not fix the *skew*: class-level
selectivity is heavily right-skewed (median well below mean, §25.2), and
a linear rescaling preserves skew exactly. The result is that the
*average* ascent multiplier across covered parameters lands around
0.83, not the intended neutral 1.0, on this task — milder than selective
noise's dilution (§26.4: raw mean 0.30, no floor) specifically because
`to_ascent_weights()`'s `beta=0.5` floor puts a hard lower bound under
how far any single parameter's multiplier can drop, but the aggregate
is still measurably below neutral.

### 27.3 Revised combined picture

§26.5's original framing — selective ascent's null "weakens the pure
signal-starvation explanation," implying it simply doesn't work as a
mechanism — was written without checking whether ascent's own
normalization was actually calibration-neutral on this specific
distribution shape. It was not. A more unified account, consistent with
both results without needing two separate explanations: both mechanisms
are systematically under-strength in aggregate on class-level's
right-skewed selectivity, to different degrees (noise: no floor,
~0.30x average; ascent: floored at 0.5, ~0.83x average) — which would
predict noise showing a larger deviation from baseline than ascent
shows, which is exactly what §26 found (d=-0.754 vs. d=+0.22). This
does not prove the dilution is the whole story for either mechanism
(§27.1 already shows the specific speed-based causal path for noise
doesn't hold up, and no equivalent direct check has been run for
ascent) — it is offered as a better-supported, more parsimonious
starting hypothesis than treating the two null/harmful results as
unrelated.

### 27.4 What this changes going forward

Neither §26's confirmed statistical result nor §24's null result is
altered by this section — both stand exactly as reported. What changes
is which follow-up is best motivated: `IDEAS.md` Idea 10 (originally
scoped to selective noise only) is broadened to cover both mechanisms,
since a normalization that preserves the *mean* (not just the range) of
the selectivity distribution — so the aggregate multiplier stays at 1.0
regardless of skew — is now a shared, specific, checkable fix rather
than two separate ones.

---

*Generated by Unlearning Meta-Learning Research Prototype v3.1 — §27
added during a review pass over §26 (no new pre-registered comparison
data collected): (1) §26.3's promised but previously unreported
`cycles_to_target` metric was computed and found essentially flat across
all four conditions (~3.1-3.3 cycles), which does not support §26.4's
"slower convergence" causal story — the confirmed effect (d=-0.754,
p=0.00028) stands, but the specific mechanism offered for it does not,
pending per-cycle trajectory data (`IDEAS.md` Idea 5) not collected here.
(2) `to_ascent_weights()`'s min-max normalization was checked directly
against class-level data and found to preserve the underlying
distribution's skew, leaving the aggregate ascent multiplier at ~0.83
(not the intended neutral 1.0) rather than fixing calibration the way
§24.1 intended — milder than selective noise's ~0.30x dilution (no
floor vs. ascent's 0.5 floor) but the same underlying gap. `IDEAS.md`
Idea 10 broadened accordingly.*

---

## 28. `IDEAS.md` Idea 10, Tested — Mean-Normalization Fixes Selective Noise's Harm, But Doesn't Make It Beneficial; Ascent Unmoved

`precommit/commitment_mean_normalization.txt` (written before any of
this section's new data was collected) pre-registers exactly the test
§26.4 and §27 called for: does mean-preserving normalization — fixing
the calibration gap those sections diagnosed, not searched for after
seeing a result (one scheme, decided in advance, per external review
round 5's caution) — change selective noise's confirmed harm and/or
selective ascent's null?

### 28.1 Design

Two independent 1-D comparisons (not a factorial), each mechanism
holding the other at uniform. Critically efficient given what already
existed: U (uniform), R_noise (§26's `su_score`), and R_ascent (§26's
`us_score`) were read directly from
`seed_results/results_class_level_selective.jsonl` — not re-run, exactly
as §24 reused §21's data. Only two new conditions were collected,
`N_noise` (`selective_noise_normalization="mean"`) and `N_ascent`
(`selective_ascent_normalization="mean"`), on all 45 of §26's
already-existing seeds (9000-9014, 10000-10029) — the full set, fixed in
advance, not a subset chosen after seeing anything and not a two-stage
design, since the sample size here isn't being estimated from a Stage 1
peek: it's the complete already-collected seed set. Per pre-registration,
two separate questions per mechanism, neither substituted for the other:
does mean-normalization move the raw/current result (N vs. R), and does
mean-normalized selectivity-weighting actually beat uniform once
correctly calibrated (N vs. U).

### 28.2 Result (n=45, analyzed exactly once)

```
                                        mean      std     t(44)    p       Cohen's d   95% CI
NOISE
  N_noise vs R_noise (fixes SS26's harm?)  +0.0409  0.0692   3.963  0.0003   +0.591   [+0.020, +0.062]
  N_noise vs U        (beats uniform?)     +0.0133  0.0511   1.745  0.0880   +0.260   [-0.002, +0.029]

ASCENT
  N_ascent vs R_ascent (moves the null?)   -0.0132  0.0492  -1.805  0.0780   -0.269   [-0.028, +0.002]
  N_ascent vs U         (beats uniform?)   +0.0000  0.0516   0.002  0.9987   +0.000   [-0.016, +0.016]
```
*(CIs corrected during a review pass — the script that produced this
table originally used the z-critical value 1.96 rather than the correct
t-distribution critical value for df=44 [~2.015]; the difference is
small at this df and changes no conclusion below, but the numbers above
are the corrected ones. p-values added at the same time, not present in
the original run's console output.)*

**Noise: both questions answered, and they're different answers.**
`N_noise` significantly outperforms `R_noise` (p=0.0003, 95% CI excludes
zero, medium-large effect) — mean-normalization fixes the calibration
gap §26.4 and §27.2 diagnosed, confirming that hypothesis rather than
merely leaving it plausible. But `N_noise` vs. `U` does not reach
significance (p=0.088, CI = [-0.002, +0.029], touching zero) —
mean-normalized selective noise is statistically indistinguishable from
uniform noise on this benchmark. Fixing the calibration bug removed the
harm; it did not turn selective noise into an improvement. Both are true
at once, and reporting only the first (as external review round 5
specifically warned against) would have overstated this section's
finding.

**Ascent: unmoved in both directions.** `N_ascent` vs. `R_ascent`
doesn't reach significance either (p=0.078, CI barely includes zero —
a small, not-quite-significant hint in the negative direction, if
anything), and `N_ascent` vs. `U` is essentially exactly zero
(mean=0.0000, p=0.9987). Mean-normalization
does not rescue selective ascent, on this benchmark, at this sample
size. Combined with §26's original null (d=+0.22) and §27's
under-strength-multiplier finding, the calibration-gap explanation that
worked for noise does not appear to be the story for ascent — ascent's
null looks more likely to be a property of the mechanism (scaling the
ascent gradient by selectivity, specifically) than an artifact of how
that selectivity was normalized.

### 28.3 What this establishes, stated at the calibration it supports

Selective noise's harmful effect (§26) was very likely a calibration
artifact, not evidence against the underlying idea (protect important
parameters, scramble unimportant ones) — this is now a confirmed
finding, not a hypothesis. That idea, correctly calibrated, is not yet
evidence of a *beneficial* mechanism on this benchmark either — it is
evidence that the mechanism, done right, is roughly neutral here.
Whether it would show a positive effect on a different benchmark, a
larger sample, or a different perturbation strength remains open and is
not addressed by this section. Selective ascent's null looks
increasingly like it is not a calibration story.

Reproduce with: `python -m unlearning_meta.run_mean_normalization_comparison
--seeds 9000 9001 ... 9014 10000 10001 ... 10029` (reads existing
U/R_noise/R_ascent from `results_class_level_selective.jsonl`, writes new
N_noise/N_ascent to `seed_results/results_mean_normalization.jsonl`;
no-op re-analysis if already present).

---

*Generated by Unlearning Meta-Learning Research Prototype v3.2 — §28
added: `IDEAS.md` Idea 10 tested per
`precommit/commitment_mean_normalization.txt`, reusing 45 of §26's
already-collected seeds for U/R and collecting two new mean-normalized
conditions. Noise: `N_noise` significantly beat `R_noise` (d=+0.591,
p=0.0003, 95% CI excludes zero) — confirming §26.4/§27.2's
calibration-gap hypothesis — but did not significantly beat `U`
(d=+0.260, p=0.088, CI [-0.002,+0.029]) — mean-normalized selective
noise is neutral relative to uniform, not beneficial. Ascent: neither
comparison reached significance (both p>0.07); mean-normalization does
not move selective ascent's null.
`to_parameter_weights_mean_normalized()` and
`to_ascent_weights_mean_normalized()` added to `MemoryTraceMapper`
(5 new tests; one test's original assumption — that mean-normalized and
min-max-normalized weights would be numerically close on a tight,
roughly-symmetric distribution — was itself found incorrect while
writing it, since min-max always stretches to fill its target range
regardless of input spread while mean-normalization does not, and the
test was corrected to check the property that is actually true rather
than the one assumed). 52/52 tests passing. `IDEAS.md` Idea 10 updated
to reflect this and no longer tracked as open.*

---

## 29. External Review Round 6: Shadow MIA Data Leakage — Found, Traced, and Fixed

External review round 6 (ChatGPT), reviewing v3.2 with the actual test
suite run locally (confirmed 52/52 passing at that time, matching this
document's own reported count), flagged a specific, checkable claim
about `evaluation/mia_evaluator.py`'s `ShadowMIA` class. Read directly
rather than taken on the review's word: the claim was exactly right.

### 29.1 The bug, verified directly

`ShadowMIA.evaluate()` collected test-set model outputs once and reused
the identical tensor as the non-member class in both the meta-classifier's
own training data (paired with retain as the member class) and its
evaluation data (paired with forget as the member class under test). The
meta-classifier's "held-out" evaluation was against data whose
distribution it had already learned during its own training — not a
genuine test of the attack's ability to generalize to unseen non-member
data, which is the entire point of a shadow-model membership inference
audit.

### 29.2 Impact, traced rather than assumed

Before fixing anything: does this bug touch any result already reported
in this document? Traced directly, not assumed:

- `composite_score` — used by every pre-registered comparison in this
  document (§17 onward) — computes its privacy term via
  `UnlearningEvaluator._mia_privacy_score`, a separate, independent,
  confidence-only implementation that never imports or calls `ShadowMIA`
  or `MIAEvaluator`. Confirmed by reading `evaluator.py`'s imports and
  method body directly.
- `ShadowMIA`/`MIAEvaluator` are only reachable from `main.py`,
  `run_real_experiment.py`, and `run_instance_level_experiment.py` — in
  each, the result is printed as a supplementary, end-of-run diagnostic
  and never stored in any `seed_results/*.jsonl` file or fed back into
  any scoring or comparison decision. Confirmed by grep across every
  `.py` file in the project for any other call site — there is none.
- A search of this document for "Shadow MIA" by name, before this
  section, returns zero matches — it was never cited as part of any
  reported finding.

**This bug affected no result in this document.** It was real, and worth
fixing since the affected code is still part of the shipped project, but
this section is not a correction to anything claimed in §1-28.

### 29.3 Fix

`ShadowMIA._split_test_outputs()` (new method, pulled out for direct
testability, mirroring `_effective_epsilon`/`_mean_rescale`'s pattern)
splits collected test outputs into two disjoint halves via
`torch.randperm` before either is used: one half becomes the non-member
class for training the meta-classifier, the other becomes the non-member
class for evaluating it. The two halves never share a sample. Test
collection was doubled (`2 * n` instead of `n`) so each half remains
comparable in size to what a single, unsplit collection provided before
the fix. A degenerate case (fewer than 2 test samples available, so no
split is possible) falls back to the pre-fix behavior for that one edge
case rather than raising — noted as a known, accepted limitation of the
fix rather than silently handled.

`tests/test_mia_evaluator.py` (new file — no test file existed for this
module before): 10 tests, covering the no-overlap property directly on
`_split_test_outputs()` (via distinguishable fingerprints, not the full
stochastic pipeline), full-coverage and no-duplicates on the split,
the degenerate tiny-input case both directly and end-to-end, the
`strict_split` observability flag in both the normal and degenerate
cases, `_compute_auc`'s missing-class fallback, and basic end-to-end
smoke tests for `ShadowMIA`, `ConfidenceMIA` (unaffected by this change
— no shadow classifier, no leakage concern), and the unified
`MIAEvaluator`. Built up in three passes, starting from 52 project-wide
tests before this section: 7 in the original fix, 1 more for
`_compute_auc`'s degenerate-class branch (closing a coverage gap found
during a review pass, reaching 60/60 project-wide at that point), and
2 more for `strict_split` in a follow-up review round (§29.4), reaching
this section's final 62/62.

Reproduce: `python -m pytest unlearning_meta/tests/test_mia_evaluator.py -v`.

### 29.4 Follow-up round: what got refined, what got deferred, and what was already covered

Both reviewers (ChatGPT, Gemini) independently validated the fix and
impact assessment, and each made small additional observations —
treated with the same scrutiny as the original finding rather than
accepted or dismissed wholesale:

- **Implemented**: a `strict_split: bool` field added to `evaluate()`'s
  return dict (propagates through `MIAEvaluator`'s combined result at
  `result["shadow_mia"]["strict_split"]`). `False` only in the
  degenerate (<2 test samples) fallback case, where the leak-prevention
  guarantee does not hold — previously a silent internal branch, now
  machine-checkable by any caller. Two new tests. Cheap, directly closes
  a real observability gap both reviews raised independently.
- **Implemented**: a forward-pointing note added to §7's metrics table
  (Gemini's specific suggestion, for paper-level rigor) — additive only,
  the original design-spec text is unchanged.
- **Checked, already covered, no new work needed**: both reviews
  independently raised whether odd/small test-set sizes are handled
  correctly. `test_split_covers_all_samples_no_duplicates_no_drops`
  (added with the original fix) already covers this directly with
  n=51 (odd): floor(51/2)=25 samples train-side, 26 eval-side, verified
  no duplicates and no drops.
- **Deferred, not implemented**: a dedicated `torch.Generator` for the
  split (rather than consuming the global RNG stream via bare
  `torch.randperm`), for independent reproducibility isolated from
  whatever else is consuming random state elsewhere in a run. Both
  reviews explicitly flagged this as optional for v3.3, not required.
  Logged in `IDEAS.md` rather than built now, consistent with this
  document's practice of not expanding scope on suggestions the
  reviewers themselves marked low-priority.
- **Noted, not actioned**: ChatGPT's point that 60/60 passing tests
  establish implementation correctness (no leakage, correct split,
  pipeline executes) and not the separate question of statistical
  validity or whether the now-unbiased Shadow AUC would read differently
  on real data — correct, and worth stating plainly rather than letting
  "tests pass" imply more than it does. Actually running the fixed
  evaluator on real data is not part of this section's scope; both
  reviews' own recommended next step (dataset/model generalization,
  `IDEAS.md` Idea 11) is a more direct route back to hypothesis-testing
  than re-running MIA diagnostics that were never wired into any scored
  comparison to begin with.

---

*Generated by Unlearning Meta-Learning Research Prototype v3.3 — §29
added: external review round 6 (ChatGPT) flagged a specific, checkable
claim about `ShadowMIA` reusing identical test-set samples as the
non-member class in both its meta-classifier's training and evaluation
data. Verified directly by reading the code (the claim was correct), and
traced — not assumed — to have affected zero results in this document,
since `composite_score`'s privacy term uses a separate implementation
that never calls `ShadowMIA`, and `ShadowMIA`'s only call sites print a
supplementary diagnostic never stored or scored. Fixed via
`_split_test_outputs()`, a new directly-testable method that splits
collected test outputs into disjoint train/eval halves before either is
used. 8 new tests in a new `tests/test_mia_evaluator.py` (no test file
existed for this module before), covering the split's no-overlap
property directly, the degenerate cases, and (added during a subsequent
review pass, closing a coverage gap) `_compute_auc`'s missing-class
fallback. A follow-up review round (ChatGPT, Gemini, §29.4) added a
`strict_split` observability flag (2 more tests) and a cross-reference
note in §7, confirmed the odd-sample-count edge case was already
covered, and explicitly deferred an optional RNG-generator refinement
neither review required. 62/62 tests passing.*

---

## 30. External Review Round 9: `_compute_auc` Tie-Handling Bug — Found by Actually Running the Code

External review round 9 (ChatGPT) did something the previous rounds
hadn't: downloaded the actual `v3.3.zip`, extracted it, and ran
`pytest -q` directly, rather than reviewing pasted text. This caught two
separate things — one a documentation staleness issue, one a genuine
second bug in the same file §29 had just fixed.

### 30.1 Documentation staleness, confirmed and fixed

The reviewer's own local test run reported 69 passing tests, not the
62 this document and `README.md` both claimed. Both were correct at the
time they were written — `tests/test_dataset_utils.py` (7 tests, the
wine-dataset loader for `IDEAS.md` Idea 11) was added afterward, in this
session, without updating either file. Fixed by updating both to the
current, verified count (73, after §30.2's fix below — see this
section's own footer for the full 52→...→73 progression).

### 30.2 The bug, verified directly

`_compute_auc`'s rank-based Mann-Whitney U computation used plain
`np.argsort`, which assigns tied scores a strict, arbitrary order rather
than the average rank proper ROC-AUC requires for ties. Verified by
direct reproduction, not taken on the review's word:

```
scores=[0.5, 0.5], labels=[1, 0]  (one tied positive/negative pair)
  old implementation: 0.0
  sklearn.metrics.roc_auc_score reference: 0.5

scores=[0.5, 0.5, 0.7, 0.7], labels=[1, 0, 1, 0]  (two tied pairs)
  old implementation: 0.25
  sklearn reference: 0.5
```

Both wrong in the same direction — understating the true AUC whenever
ties are present, which is exactly the situation a small MIA evaluation
set or a saturated/quantized model output can produce, making this more
than a hypothetical edge case for this specific use.

### 30.3 Impact, traced rather than assumed

Same audit pattern as §29.2, applied to a different function:
`modules/unlearning/evaluator.py`'s `_mia_privacy_score` — the function
that actually feeds `composite_score`, used by every pre-registered
comparison in this document — already called
`sklearn.metrics.roc_auc_score` directly (confirmed by reading the code),
not the buggy hand-rolled rank computation. The tie bug lived only in
`evaluation/mia_evaluator.py`'s `ShadowMIA`-associated `_compute_auc`,
which §29.2 already established is not reachable from any scored or
reported comparison in this document. **This bug affected no result in
this document**, for the same structural reason §29's leak did not.

### 30.4 Fix

`_compute_auc` now delegates to `sklearn.metrics.roc_auc_score` directly
— scikit-learn is already a required dependency and was already used for
this identical computation elsewhere in this codebase, so this also
removes a previously-undetected inconsistency where two different AUC
implementations coexisted in the same project for no reason. The
degenerate (`n_pos==0` or `n_neg==0`) fallback is preserved as a
wrapper, since `roc_auc_score` raises in that case rather than returning
a neutral value, and every caller of this function expects a float back
unconditionally.

4 new tests in `tests/test_mia_evaluator.py`: the two exact cases the
review specified (single tied pair, multiple tied pairs), a cross-check
against sklearn's own reference implementation on a case combining ties
and clear separation (not just hand-computed expected values), and a
regression check that cases without ties — where the old implementation
was already correct — remain correct under the new one.

Reproduce: `python -m pytest unlearning_meta/tests/test_mia_evaluator.py -v`.

---

*Generated by Unlearning Meta-Learning Research Prototype v3.4 — §30
added: external review round 9 (ChatGPT) downloaded and ran v3.3's actual
test suite, catching a stale test count (README/ARCHITECTURE claimed 62;
actually 69 after this session's earlier, unrelated addition of
`tests/test_dataset_utils.py`) and a second, independent bug in
`evaluation/mia_evaluator.py`: `_compute_auc`'s rank computation didn't
average ranks for tied scores, understating AUC whenever ties occur
(verified by direct reproduction against sklearn's reference
implementation: 0.0 vs. correct 0.5 for a single tied pair). Traced,
not assumed, to have affected no result in this document —
`composite_score`'s privacy term already used sklearn's
`roc_auc_score` directly, unlike `ShadowMIA`'s now-fixed hand-rolled
version, which §29.2 already established is not reachable from any
scored or reported comparison. Fixed by switching to
`sklearn.metrics.roc_auc_score` directly, removing the hand-rolled
implementation entirely. 4 new tests. Test count corrected throughout
this document and README.md. 73/73 tests passing.*

---

## 31. `IDEAS.md` Idea 11 — First Cross-Dataset Exploratory Check: B Underperforms A on Wine, and a Root-Cause Decomposition

### 31.1 Exploratory check (n=5, NOT pre-registered, mirroring §18's style)

`load_wine_instance_forgetting` (`data/dataset_utils.py`) — sklearn's
bundled wine dataset (13 tabular features, 3 classes, 178 samples) —
tested with the SAME Condition A (fixed hyperparameters) vs Condition B
(full dual-engine system) comparison as §17.4's original digits
confirmation. Every hyperparameter left exactly as calibrated for
digits (`build_base_config()`'s defaults), changed only where the data
shape itself requires it (model input/output dims 13/3 not 64/10,
batch_size 8 not 32, given wine's ~130-sample retain set). Experimental
parity with digits confirmed directly, not assumed: identical
`test_fraction=0.2`, identical `num_cycles=25`, identical
`composite_score` formula, identical `set_seed()` pattern, no early
stopping in either case.

```
seed=20000: A=4.2512  B=3.6559  B-A=-0.5954
seed=20001: A=4.1951  B=4.0992  B-A=-0.0958
seed=20002: A=4.1606  B=2.4925  B-A=-1.6681
seed=20003: A=4.4125  B=4.3198  B-A=-0.0927
seed=20004: A=4.4100  B=3.6990  B-A=-0.7110

n=5  mean(B-A)=-0.6326  std=0.6441  [0/5 seeds favor B]
```

5/5 seeds favor A — the opposite direction from §17.4's confirmed
digits result (B beat A, d=0.433, p=0.0022, n=55). Exploratory only; no
significance claim at n=5. But the CONSISTENCY (5/5, not a near-even
split) was informative enough to warrant the diagnostic decomposition
below before deciding whether this is worth a properly-powered
confirmatory design.

### 31.2 Root-cause decomposition

Per-cycle instrumentation (`run_wine_root_cause_analysis.py`) captured
what the exploratory check's summary-only metrics couldn't: full
`UnlearningMetrics` per cycle, the proposed `StrategyUpdate` (action,
delta, confidence, `source_rule`), `StrategyMemory`'s active/dormant/
archive rule counts, and a full hyperparameter config snapshot — for
all 5 wine seeds plus 2 fresh digits seeds run through the identical
instrumentation, as a known-positive contrast case.

**Methodological trap found and fixed during this analysis's own
development, worth recording since it is easy to reproduce by
accident:** `set_seed()` resets the RNG once per seed, and every
downstream call in a run (pretrain, baseline computation, condition A,
condition B) shares that ONE continuous stream. An early version of the
diagnostic script instrumented condition B directly without first
running condition A — since only B's per-cycle detail was needed — which
silently started B from a *different* point in the shared RNG stream
than §31.1's own condition B did for "the same seed," producing
different numbers (3.7331 vs. 3.6770 for a case checked directly) with
no logic bug in either implementation, purely from this ordering
difference. Fixed by running condition A first (via the same
`run_condition()` used everywhere else in this project) before the
instrumented condition B, exactly matching §31.1's sequence, in every
run reported below.

**One candidate mechanism ruled out before analysis, by reading the code
directly:** `StrategyMemory.__init__` takes no path or file argument —
every `ExperienceEngine()` instantiation starts with empty active/
dormant/archive lists, confirmed directly. There is no cross-run
persistence anywhere in this architecture. "Negative transfer from
prior experience" in the sense of a previous task's rules actively
misleading a new task cannot be what's happening here, because no
condition-B run on any dataset in this project has ever carried
memory in from a prior run — each starts equally blank, wine included.

**What the data shows instead — retain-floor violations, concentrated
in 3 of 5 seeds, tracking the size of the B-A gap almost exactly:**

```
             retain_floor penalty cycles   min retain_acc   B-A
wine  20000:  1/25                          0.8154          -0.5954
wine  20001:  0/25                          0.9077          -0.0958
wine  20002:  3/25                          0.8538          -1.6681
wine  20003:  0/25                          0.9615          -0.0927
wine  20004:  1/25                          0.8846          -0.7110
digits 30000: 0/25                          0.9692          -0.2119
digits 30001: 0/25                          0.9630          -0.0091
```

Seeds with zero floor violations (20001, 20003) show only small B-A
gaps (-0.10, -0.09) — comparable in magnitude to what the digits
contrast seeds show even without any violation (-0.21, -0.01), well
within the kind of per-seed noise §17.4's own n=55 confirmation is
built to average over. The large gaps are concentrated exactly where
the floor was violated, and scale with how often: 1 violation → -0.60
and -0.71; 3 violations → -1.67 (the worst case, seed=20002).

**The mechanism, traced cycle-by-cycle for the worst case (seed=20002,
3 violations):**

```
cycles 0-3: forgetting_strength adjustments only; noise_scale stays at
            default (~0.004); retain_acc stable at 0.9846; scores healthy (~4.2-4.3)
cycle 4:    action=increase_noise -> noise_scale jumps to 0.2 (≈50x the
            default 0.005) in a single step; retain_acc still 0.9923 this
            cycle, but score already drops to 3.32
cycles 5-8: noise_scale HELD at 0.2 for 4 more cycles; retain_acc erodes
            gradually: 0.9692 -> 0.9000 -> 0.9077
cycle 9:    action=decrease_ewc (reducing the regularization that would
            have protected retain performance); retain_acc=0.8692 -- FLOOR (1st)
cycle 10:   action=increase_noise AGAIN (noise_scale unchanged at 0.2);
            retain_acc=0.8923 -- FLOOR (2nd)
cycle 11:   action=decrease_noise -> noise_scale crashes to exactly 0.0
            (full overcorrection, not graduated); retain_acc=0.8538 (still
            below floor) AND forget_acc collapses 1.0->0.9167 (near-zero
            noise barely perturbs anything) -- FLOOR (3rd)
cycle 12:   action=decrease_noise (noise_scale stays 0.0); retain_acc
            recovers to 0.9385; forget_acc back to 1.0; score=4.2243 (recovered)
cycles 13-24: noise_scale remains EXACTLY 0.0 for the rest of the run --
            noise-based forgetting is never used again; healthy scores
            (~4.2-4.35) maintained through other levers (EWC, grad_clip, replay)
```

A single `increase_noise` action (cycle 4) moved `noise_scale` by a
factor calibrated to have a moderate effect at digits' scale; on wine's
~130-sample retain set it took 5 more cycles before this was severe
enough to cross the floor, then 2 further cycles of continued
exploration (`decrease_ewc`, then `increase_noise` again) before the
bandit's reward signal reflected the problem clearly enough for
`decrease_noise` to be selected — and when it was, it overcorrected
completely (0.2 → 0.0, not a graduated reduction), collapsing
`forget_acc` as a side effect before a final correction recovered both.
The system did recover within the same run (3 bad cycles out of 25,
not a permanent failure) — but by avoiding noise-based forgetting
entirely for the remaining 13 cycles rather than re-exploring a
moderate value, which is itself informative about how the bandit
responds to a punished action.

**Rule-guidance was not selectively rare on wine, ruling out an easy
alternative story:** wine seeds showed 1-5 rule-guided proposals out of
25 (`source_rule != None`); digits seeds showed 1-2 out of 25 — both
datasets are overwhelmingly driven by raw bandit exploration rather
than extracted-rule guidance within a single 25-cycle run. This is not
a case of "digits gets rule-guided help that wine doesn't."

### 31.3 Which hypothesis this supports

Three candidate explanations were distinguished, not assumed:

- **"Adaptation itself is harmful on wine"** — not supported. 2 of 5
  seeds show B performing comparably to the digits contrast seeds
  (small negative gaps, not large ones) when no floor violation occurs.
- **"Negative transfer from prior experience"** — not applicable to
  this architecture as it currently exists (§31.2) — there is no prior
  experience to transfer, on any dataset.
- **"Exploration step sizes, calibrated for digits' scale, are
  proportionally too large for wine's much smaller retain set"** —
  supported by direct evidence: the traced mechanism (§31.2) shows an
  absolute hyperparameter delta (`noise_scale` reaching 0.2) causing
  retain-floor violations concentrated in a minority (3/5) of seeds,
  with the size of each seed's B-A gap tracking its violation count
  almost exactly, and zero violations in either digits contrast seed
  under the identical mechanism.

This is the same calibration-mismatch theme that has now recurred
across §19 (Fisher epsilon), §26/§27 (selective noise/ascent
normalization), and here — a constant or step size implicitly
calibrated against one task's scale not transferring cleanly to a task
of meaningfully different scale, rather than a failure of the
underlying adaptive mechanism itself.

### 31.4 What this does not establish, and what's next

This is a diagnostic decomposition of an n=5 exploratory result, not a
confirmatory claim, and not a fix. Per explicit direction, no new
mechanism (e.g. a "transfer gating" or scale-aware step-size system) is
proposed or built here. What would be needed before drawing a
confirmatory conclusion either way: a properly-powered pre-registered
design on wine (mirroring §17.4's own n=55 confirmatory structure), and
separately, a diagnostic check of whether recalibrating exploration step
sizes for wine's scale (analogous to §24.1's and Idea 10's calibration
fixes for a different mechanism) changes the floor-violation rate —
without yet building or running either, per instruction.

Reproduce: `python -m unlearning_meta.run_wine_exploratory_comparison`
(5-seed exploratory check) then
`python -m unlearning_meta.run_wine_root_cause_analysis` (per-cycle
diagnostic decomposition, wine + digits contrast); writes
`seed_results/results_wine_exploratory.jsonl` and
`seed_results/wine_root_cause_analysis.jsonl`.

---

*Generated by Unlearning Meta-Learning Research Prototype v3.6 — §31
added: `IDEAS.md` Idea 11's first cross-dataset check (wine, n=5,
exploratory) found B underperforming A in all 5 seeds, opposite of
§17.4's digits result (mean B-A=-0.6326). Root-cause decomposition
(per-cycle instrumentation, wine + digits contrast) ruled out cross-run
experience transfer directly from code (no persistence exists in this
architecture) and found the effect concentrated in 3/5 seeds where
specific hyperparameter actions (`noise_scale` reaching 0.2, ~50x
default) triggered the retain_floor guardrail, with the size of each
seed's B-A gap tracking its violation count closely and zero violations
in either digits contrast seed. Supports "exploration step sizes
calibrated for digits' scale are proportionally too large for wine's
much smaller retain set" over "adaptation itself is harmful" or
"negative transfer" (the latter ruled structurally impossible — no
cross-run memory exists in this architecture). A methodological trap in
this analysis's own development (condition ordering silently shifting a
shared RNG stream) was found and fixed before this section was written,
not after — recorded in §31.2 since it is easy to reproduce by
accident. No new mechanism proposed or built, per explicit instruction
pending further confirmation.*

---

## Appendix A: Registered Analysis Plans (verbatim)

Per external review round 6's Open Science suggestion, both
pre-registration documents referenced in §17 are reproduced here in full,
exactly as written before their respective data collection began (also
shipped as separate files at `precommit/commitment.txt` and
`precommit/commitment_cd.txt` — kept as literal artifacts rather than only
quoted here, so their file timestamps remain independently checkable
evidence of when they were written, not just prose asserting it).

### A.1 `precommit/commitment.txt` (before the 28-seed batch behind §17.4)

```
PRE-REGISTRATION (written before data collection for this batch)
Target sample size: n=55
Seeds to add: 5000-5027 inclusive (28 seeds)
Analysis to run: exactly once, after ALL 28 seeds complete
No intermediate significance checks will be performed or reported.
```

### A.2 `precommit/commitment_cd.txt` (before the C/D ablation behind §17.8)

```
PRE-REGISTRATION 2 (written before C/D data collection)
Date: 2026-07-04

Question: Does Strategy Evolution (D removed) or Rule Extraction (C removed)
contribute more to the full system's (B) performance?

Design: Reuse the EXACT SAME 55 seeds already in seed_results/results.jsonl
(B's scores already collected there). For each of those 55 seeds, regenerate
the identical pretrained model + baseline (deterministic given seed), then
run ONLY conditions C (no rule extraction) and D (no strategy evolution).
Store as seed_results/results_cd.jsonl, keyed by seed, joined with the
existing file at analysis time. B's existing data is not re-run or modified.

Analysis plan (fixed in advance):
1. Omnibus test: Friedman test (non-parametric, repeated-measures, 3 groups:
   B, C, D) on the 55 matched seeds. This is run FIRST and ALONE.
2. Only if the omnibus test is significant (p<0.05): follow up with
   Wilcoxon signed-rank pairwise tests (B-vs-C, B-vs-D, C-vs-D), each at
   Bonferroni-corrected threshold alpha=0.05/3=0.0167.
3. If the omnibus test is NOT significant: report that directly and do NOT
   run pairwise tests (this would be exactly the multiple-comparisons
   problem this design exists to avoid).

No intermediate significance checks during C/D data collection. Analysis
runs exactly once, after all 55 seeds have both C and D scores.
```

Note on §18: the forget_fraction=0.20 generalization check did not have
its own pre-registration document — flagged explicitly in §18.3 as a gap,
since it was framed from the start as a quick exploratory check rather
than a claim-bearing result. A properly-powered generalization study
would warrant the same discipline as A.1/A.2 above.

### A.3 `precommit/commitment_selective_noise.txt` (before the §21 comparison)

```
PRE-REGISTRATION 3 (written before any selective-noise comparison data collection)
Date: 2026-07-29

Question: Does connecting MemoryTraceMapper's selectivity to noise
injection (selective_noise_enabled=True, §20) improve outcomes over the
existing full system (selective_noise_enabled=False, the §17.4-confirmed
configuration) on the instance-level forgetting benchmark?

Design: Same instance-level benchmark (forget_fraction=0.10) and same
bandit+momentum mechanism (use_contextual_bandit=True) used throughout
§14-19, so this isolates ONLY the selective_noise_enabled toggle.
Condition F = B + selective_noise_enabled=True. Condition B = existing
baseline (selective_noise_enabled=False, identical otherwise).
Paired by seed (same pretrained starting model for both conditions at
each seed), same target-aware scoring (§16) as every other comparison in
this document.

TWO-STAGE PLAN, fixed in advance to avoid §17.3's optional-stopping
mistake:

Stage 1 (exploratory): n=15 seeds. Compute mean_score(F) - mean_score(B)
per seed, then Cohen's d for this specific comparison. This stage's ONLY
purpose is to get a first effect-size estimate for computing Stage 2's
sample size - it is NOT analyzed for significance and no p-value claim
will be made from it alone.

Stage 2 (confirmatory): sample size computed from Stage 1's Cohen's d
using the standard paired-test formula n = ((1.96+0.84)/d)^2 for 80%
power at alpha=0.05, with a floor of n=30 and a ceiling of n=80 (to keep
this bounded regardless of what Stage 1's d turns out to be - an
extremely small d would imply an impractically large n, at which point
the honest conclusion is "no practically meaningful effect detected",
not "let's chase an arbitrarily large n"). Stage 2 uses NEW seeds, not
overlapping Stage 1's, run to completion, analyzed exactly once with a
paired t-test + 95% CI + Cohen's d, exactly as §17.4.

No significance checks during Stage 1 collection. Stage 1's result
determines Stage 2's n but is not itself a significance test.
```

Result: Stage 1's Cohen's d (-0.114) implied n≈600 for Stage 2, exceeding
the pre-set ceiling of 80 — per the plan's own advance instruction, this
was treated as "no practically meaningful effect detected" and Stage 2
was not run. See §21.

### A.4 `precommit/commitment_fisher_forgetting_per_layer.txt` (before the §23 comparison)

```
PRE-REGISTRATION 4 (written before any fresh-seed Fisher Forgetting per-layer comparison data collection)
Date: 2026-08-11

Question: Does per-layer epsilon normalization (per_layer_normalize=True,
§22) improve average performance and/or reduce the catastrophic-failure
rate relative to the existing Fisher Forgetting baseline
(per_layer_normalize=False, the §19-established configuration) on the
instance-level forgetting benchmark, on seeds NOT already known to
contain the one documented failure case?

Design: Same instance-level benchmark (forget_fraction=0.10) and same
target-aware scoring (target_forget_acc, retain_floor=0.90, §16) as
every other comparison in this document. Same noise_scale=3e-6 and
epsilon=1e-10 held fixed for both conditions, so this isolates ONLY the
per_layer_normalize toggle (per_layer_eps_fraction fixed at §22's
untuned default of 0.01). Condition E' = E + per_layer_normalize=True.
Condition E = existing baseline (per_layer_normalize=False, identical
otherwise). Paired by seed (same pretrained starting model for both
conditions at each seed).

Seeds: a fresh block (7000, 7001, ...), chosen before any data
collection and NOT overlapping any seed used anywhere else in this
document (the §17-19 15-seed set, the 5000-5027 batch behind §17.4, or
6000-6014 behind §21) - specifically because §22's own 15-seed check
deliberately reused seeds already known to contain the one documented
failure case (seed=1004), which would bias an effect-size estimate if
reused here.

TWO-STAGE PLAN, fixed in advance, following §20/§21's precedent to avoid
§17.3's optional-stopping mistake:

Stage 1 (exploratory): n=15 seeds (7000-7014). Compute
mean_score(E') - mean_score(E) per seed, then Cohen's d for this specific
comparison. This stage's ONLY purpose is to get a first effect-size
estimate for computing Stage 2's sample size - it is NOT analyzed for
significance and no p-value claim will be made from it alone. Also
record, descriptively only (not power-analyzed - catastrophic failures
are rare by design and n=15 will not power a formal rate comparison),
the count of retain_floor-triggered outcomes under each condition.

Stage 2 (confirmatory): sample size computed from Stage 1's Cohen's d
using the standard paired-test formula n = ((1.96+0.84)/d)^2 for 80%
power at alpha=0.05, with a floor of n=30 and a ceiling of n=80 (same
bounding logic as §21's precommit: an extremely small d implies an
impractically large n, at which point the honest conclusion is "no
practically meaningful average-performance effect detected," not "chase
an arbitrarily large n" - this would not contradict §22's separate,
already-established finding about the one specific reproduced failure
case, which does not depend on this stage running at all). Stage 2 uses
NEW seeds, starting immediately after Stage 1's block and not
overlapping it, run to completion, analyzed exactly once with a paired
t-test + 95% CI + Cohen's d, exactly as §17.4/§21.

No significance checks during Stage 1 collection. Stage 1's result
determines Stage 2's n but is not itself a significance test. The
catastrophic-failure count is reported at whatever n is actually
collected (Stage 1 alone, or Stage 1+2 combined) as descriptive evidence
alongside - not instead of - the pre-registered continuous-score
analysis above.
```

Result: Stage 1's Cohen's d (-0.1834) implied n=233 for Stage 2,
exceeding the pre-set ceiling of 80 — per the plan's own advance
instruction, this was treated as "no practically meaningful effect
detected" and Stage 2 was not run. See §23.

### A.5 `precommit/commitment_selective_ascent.txt` (before the §24 comparison)

```
PRE-REGISTRATION 5 (written before any selective-ascent comparison data collection)
Date: 2026-08-11

Question: Does connecting MemoryTraceMapper's selectivity to the
GRADIENT ASCENT step itself (selective_ascent_enabled=True, IDEAS.md
Idea 3) improve outcomes over the existing system, where selectivity
has so far only ever been connected to post-ascent NOISE injection
(selective_noise_enabled, §20, tested in §21 with no detected effect,
Cohen's d=-0.114)? §21.3 speculated the mechanism might need to target
ascent itself rather than only noise - this is that test.

Design: A 2x2 factorial, not a single A/B, per the external review round
3 recommendation (IDEAS.md, ChatGPT review) - this is necessary because
a null result on selective_ascent_enabled ALONE would be ambiguous
between "selectivity doesn't help" and "selectivity doesn't help when
noise injection is also selective" (or isn't). Same instance-level
benchmark (forget_fraction=0.10), same bandit+momentum mechanism
(use_contextual_bandit=True), same target-aware scoring
(target_forget_acc, retain_floor=0.90) used throughout SS14-23.

  Condition UU: selective_noise_enabled=False, selective_ascent_enabled=False
  Condition SU: selective_noise_enabled=True,  selective_ascent_enabled=False
  Condition US: selective_noise_enabled=False, selective_ascent_enabled=True
  Condition SS: selective_noise_enabled=True,  selective_ascent_enabled=True

(Labeled UU/SU/US/SS - noise-then-ascent - specifically to avoid
colliding with this document's pre-existing and unrelated A/B/C/D
labels from SS17.4/SS17.8.)

Reusing existing data for UU and SU: these are EXACTLY SS21's B and F
conditions (selective_ascent_enabled did not exist when that data was
collected, so ascent was implicitly uniform throughout) - already
collected at seeds 6000-6014, in seed_results/results_selective_noise.jsonl
(b_score=UU, f_score=SU). Reused rather than re-run, exactly as SS17.8's
C/D ablation reused SS17.4's A/B scores on the same seeds ("reuse the
EXACT SAME seeds... joined at analysis time"). This pre-registration
covers collecting the two NEW conditions, US and SS, on the SAME 15
seeds (6000-6014) - paired by seed against the already-existing UU/SU
scores at those seeds, and against each other.

Because UU/SU at these seeds were already analyzed once (SS21, for the
noise-only question), this is not a blind sample for a fresh estimate of
that same noise-only question - it remains a valid blind test of the two
NEW questions (does ascent selectivity matter; is there an interaction),
since neither was computed or looked at before this document was written.

Primary contrast (this section's actual hypothesis): main effect of
ASCENT selectivity, averaged over both noise settings:

  Effect_ascent = [ (US - UU) + (SS - SU) ] / 2

Secondary contrasts (reported, not the focus - noise's main effect is
already substantially addressed by SS21; the interaction term has
roughly double the variance of a simple paired difference since it is a
difference of differences, and n=15 is not expected to power a real read
on it - reported descriptively only):

  Effect_noise       = [ (SU - UU) + (SS - US) ] / 2
  Interaction        = (SS - US) - (SU - UU)

TWO-STAGE PLAN for the primary contrast (Effect_ascent), fixed in
advance, following SS20/SS21's and SS22/SS23's precedent to avoid SS17.3's
optional-stopping mistake:

Stage 1 (exploratory): n=15 (seeds 6000-6014, per above). Compute
Effect_ascent per seed, then Cohen's d for this specific contrast. This
stage's ONLY purpose is a first effect-size estimate for computing
Stage 2's sample size - it is NOT analyzed for significance and no
p-value claim will be made from it alone. Effect_noise and Interaction
are computed and reported at this same n, explicitly labeled descriptive
only (Interaction in particular is not expected to be resolvable at
n=15).

Stage 2 (confirmatory, for Effect_ascent only): sample size computed
from Stage 1's Cohen's d using the standard paired-test formula
n = ((1.96+0.84)/d)^2 for 80% power at alpha=0.05, with a floor of n=30
and a ceiling of n=80 (same bounding logic as SS21/SS23's precommits: an
extremely small d implies an impractically large n, at which point the
honest conclusion is "no practically meaningful effect detected," not
"chase an arbitrarily large n"). Stage 2 uses a fresh seed block, not
overlapping 6000-6014 or any other seed used elsewhere in this document,
run for all four conditions (UU/SU/US/SS, none reused this time, since
a truly fresh block has no prior data to reuse), analyzed exactly once
with a paired t-test + 95% CI + Cohen's d on Effect_ascent, exactly as
SS17.4/SS21/SS23.

No significance checks during Stage 1 collection. Stage 1's result
determines Stage 2's n but is not itself a significance test.
alpha=1.0, beta=0.5 (selective_ascent_alpha/beta) are fixed at the
values already documented and justified in
modules/unlearning/memory_trace.py's to_ascent_weights() docstring
(empirically motivated by measuring this architecture's actual
selectivity distribution, not tuned against this comparison's outcome)
and are not adjusted based on any result at any stage.
```

Result: Stage 1's Cohen's d for the primary Effect_ascent contrast
(+0.0842) implied n=1,105 for Stage 2, exceeding the pre-set ceiling of
80 by more than an order of magnitude — per the plan's own advance
instruction, this was treated as "no practically meaningful effect
detected" and Stage 2 was not run. See §24.

### A.6 `precommit/commitment_class_level_selective.txt` (before the §26 comparison)

```
PRE-REGISTRATION 6 (written before any class-level selective noise/ascent comparison data collection)
Date: 2026-08-13

Question: Does selective noise (selective_noise_enabled, SS20/SS21) and/or
selective ascent (selective_ascent_enabled, SS24) improve forgetting
performance on CLASS-level forgetting, now that IDEAS.md Idea 9 Phase 1
(ARCHITECTURE.md SS25) has shown the selectivity signal itself is far
richer there (std=0.296, spanning nearly the full [0,1) range) than on
the instance-level benchmark (std=0.030) where both mechanisms
previously showed no detectable effect (SS21: d=-0.114; SS24: d=+0.0842)?

Design: Same 2x2 factorial structure as SS24 (UU/SU/US/SS), same
target-aware scoring (target_forget_acc, retain_floor=0.90), same
bandit+momentum system (use_contextual_bandit=True), same model
architecture, but on CLASS-level forgetting
(load_digits_unlearning_datasets, forget_classes=[0]) instead of
instance-level. All four conditions collected FRESH - unlike SS24, there
is no existing class-level data to reuse, since this benchmark has never
been tested in this project's pre-registered comparison format before
(it was this project's ORIGINAL benchmark, SS10 and earlier, but only
ever evaluated for raw forgetting performance, never for a
selective-mechanism comparison).

Seeds: a fresh block (9000, 9001, ...), not overlapping any seed used
elsewhere in this document (SS17-19's set, 5000-5027, 6000-6014,
7000-7014).

Interpretive note established by a single-seed, UU-only pilot check
(2026-08-13, not treated as comparison data - no SU/US/SS collected
during the pilot, and the seed used for it is excluded from the 9000
block above): on this class-level task, retain_acc reaches and holds at
1.0000 very early even for the plain baseline condition, since
forgetting one class does not naturally interfere with classifying the
other nine - unlike instance-level, where retain_acc is a live,
varying quantity throughout. This means differentiation between
conditions here is expected to come primarily through how QUICKLY
forget_acc converges toward its target (0.0000 - the retrain-baseline
model, having never seen class 0, does not predict it at all) - already
reflected in the mean composite_score across cycles used as the primary
contrast below, so no change to that machinery is needed. Stated in
advance specifically so a null finding on retain-protection differences
specifically is not later over-interpreted as evidence against the
mechanisms, when it may simply reflect this task giving every condition
an easy ceiling on that one dimension.

TWO PRIMARY CONTRASTS (both treated as primary here, unlike SS24, where
noise was secondary because it had already been tested at scale on
instance-level - on class-level, neither mechanism has been tested
before):

  Effect_ascent = [ (US - UU) + (SS - SU) ] / 2
  Effect_noise  = [ (SU - UU) + (SS - US) ] / 2

Secondary (descriptive only, same reasoning as SS24 - a difference of
differences, roughly double the variance, not expected to be resolvable
at n=15):

  Interaction = (SS - US) - (SU - UU)

Secondary descriptive metric, new to this pre-registration (motivated
by the pilot observation above): cycles_to_target - the first cycle
(0-indexed) at which forget_acc falls within 0.02 of target_forget_acc,
per condition per seed, capped at num_cycles if never reached within the
run. Reported as a mean per condition, purely descriptive - not run
through the Stage 1/Stage 2 machinery below, since it was not the
question that motivated this study and no power analysis has been done
for it.

TWO-STAGE PLAN, fixed in advance, applied INDEPENDENTLY to each of the
two primary contrasts (Effect_ascent and Effect_noise may reach
different conclusions - each gets its own Stage 1 estimate and, if
warranted, its own Stage 2), following SS20-SS24's precedent to avoid
SS17.3's optional-stopping mistake:

Stage 1 (exploratory): n=15 (seeds 9000-9014). Compute each contrast per
seed, then Cohen's d for each. This stage's ONLY purpose is a first
effect-size estimate for computing each contrast's own Stage 2 sample
size - NOT analyzed for significance, no p-value claim from Stage 1
alone, for either contrast.

Stage 2 (confirmatory, computed independently per contrast that
qualifies): sample size from that contrast's Stage 1 Cohen's d via
n = ((1.96+0.84)/d)^2 for 80% power at alpha=0.05, floor 30 / ceiling 80
(same bounding logic as every prior precommit in this document: an
extremely small d implies an impractically large n, treated as "no
practically meaningful effect detected" rather than chasing significance
with an arbitrarily large n). A contrast whose Stage 1 d implies n>80
does not get a Stage 2; a contrast whose Stage 1 d implies n<=80 does,
using a fresh seed block not overlapping 9000-9014 or any other seed
used elsewhere in this document, analyzed exactly once with a paired
t-test + 95% CI + Cohen's d.

No significance checks during Stage 1 collection for either contrast.
alpha=1.0, beta=0.5 (selective_ascent_alpha/beta) held at SS24's already-
documented, already-justified values - not retuned for this benchmark,
so this remains a test of whether the SAME mechanism (not a
class-level-specific variant of it) shows an effect once given a richer
signal to work with.
```

Result: Stage 1 (n=15) closed Effect_ascent (d=+0.2216, implied n=94,939,
far past ceiling) and advanced Effect_noise to Stage 2 (d=-0.8330,
implied n=13.8, floor-adjusted to 30). Stage 2 (n=30, fresh seeds
10000-10029) confirmed Effect_noise: mean=-0.0351, t(29)=-4.1297,
p=0.000281, Cohen's d=-0.7540, 95% CI=[-0.0525,-0.0177] — a large,
statistically significant, harmful effect, analyzed exactly once per
pre-registration. See §26.

### A.7 `precommit/commitment_mean_normalization.txt` (before the §28 comparison)

```
PRE-REGISTRATION 7 (written before any mean-normalization comparison data collection)
Date: 2026-08-15

Question: Does mean-preserving normalization (IDEAS.md Idea 10) --
rescaling selectivity so its own mean lands exactly at each mechanism's
neutral point, rather than to_parameter_weights()'s raw pass-through or
to_ascent_weights()'s min-max (which fixes range but not skew, SS27.2) --
change selective noise's confirmed harmful effect (SS26: d=-0.754,
p=0.00028) and/or selective ascent's null effect (SS26: d=+0.22), on the
same class-level forgetting benchmark?

Per external review round 5 (ChatGPT), this pre-registration fixes TWO
things in advance that were not fixed before seeing any result, closing
off exactly the researcher-degrees-of-freedom risk that review flagged:

1. ONE normalization scheme, decided now, not searched afterward: mean
   normalization (weight = selectivity * (target_mean / mean(selectivity)),
   implemented as to_parameter_weights_mean_normalized() and
   to_ascent_weights_mean_normalized()). No other scheme (variance-
   preserving, alternative target means, etc.) is tried; if this
   scheme's result is unclear or null, that is reported as this scheme's
   result, not a prompt to try another.

2. TWO separate questions, both asked, neither substituted for the
   other:
   (a) N vs R -- does mean-normalization change the RAW/current
       implementation's result (shrink SS26's harmful noise effect;
       possibly move ascent's null in either direction)?
   (b) N vs U -- does mean-normalized selectivity-weighting actually
       BEAT uniform, once correctly calibrated? A result confirming only
       (a) is not reported as confirming (b).

Design: Same class-level forgetting benchmark as SS26
(load_digits_unlearning_datasets, forget_classes=[0]), same target-aware
scoring, same bandit+momentum system, same alpha=1.0/beta=0.5 for ascent
(unchanged from SS24.1 -- this tests a recalibrated INPUT to the same
formula, not a retuned formula). Two separate 1-D comparisons (not a
factorial -- noise and ascent are tested independently, each holding the
other mechanism at uniform):

  Noise:  U (uniform) / R_noise (raw selective, = SS26's SU) / N_noise (mean-normalized selective, NEW)
  Ascent: U (uniform) / R_ascent (minmax selective, = SS26's US) / N_ascent (mean-normalized selective, NEW)

U, R_noise, and R_ascent are read directly from
seed_results/results_class_level_selective.jsonl (SS26's uu_score,
su_score, and us_score fields respectively) -- not re-run, exactly as
SS24 reused SS21's data and SS17.8 reused SS17.4's. Only N_noise and
N_ascent are new data collected by this pre-registration.

Seeds: ALL 45 of SS26's already-collected seeds (9000-9014, 10000-10029)
-- not a subset chosen after seeing anything, and not a fresh two-stage
design, because unlike every other precommit in this document the
sample here is not being sized from a Stage-1 effect estimate: it is the
complete, already-fixed set of seeds SS26 collected U/R data for, known
and committed to in full before N_noise/N_ascent are collected. Using
all 45 rather than a subset is the more statistically powerful, less
discretionary choice.

Analysis: paired by seed (N_noise, R_noise, and U all come from the same
pretrained starting model at each seed -- U and R_noise already were, by
construction, paired with each other in SS26; N_noise is collected from
that same seed's data loaders and pretrain recipe, keeping the pairing
intact). Two paired t-tests per mechanism (N-vs-R, N-vs-U), each with a
95% CI and Cohen's d, analyzed exactly once, n=45 for each -- no interim
looks, no stopping rule needed since n is fixed in advance by the
already-existing data being reused, not adaptively determined.
```

Result: N_noise significantly beat R_noise (mean=+0.0409, t(44)=3.963,
p=0.0003, d=+0.591, 95% CI=[+0.020,+0.062]) but did not significantly
beat U (mean=+0.0133, t(44)=1.745, p=0.088, d=+0.260, 95%
CI=[-0.002,+0.029], touching zero). N_ascent showed neither effect (vs.
R_ascent: p=0.078, d=-0.269, CI=[-0.028,+0.002]; vs. U: p=0.999,
d=+0.000, CI=[-0.016,+0.016]). Both questions answered as pre-registered,
neither substituted for the other. See §28.
