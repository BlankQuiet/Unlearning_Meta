"""
tests/test_integration.py
============================
End-to-end smoke tests, including the CRITICAL CONSTRAINT from the
original project brief: the Experience Engine must never modify model
weights directly — only the Unlearning Engine does, via
apply_strategy()'s hyperparameter changes.
"""

import copy

import torch
from torch.utils.data import DataLoader, TensorDataset

from unlearning_meta.config import Config
from unlearning_meta.models.base_model import MLP
from unlearning_meta.engines.unlearning_engine import UnlearningEngine
from unlearning_meta.engines.experience_engine import ExperienceEngine


def _fake_loader(n=64, seed=0):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(n, 1, 8, 8, generator=g)
    y = torch.randint(0, 10, (n,), generator=g)
    return DataLoader(TensorDataset(x, y), batch_size=16, shuffle=True)


class TestCriticalConstraint:
    """The original brief's core architectural rule: Experience Engine
    proposes; only Unlearning Engine touches weights."""

    def test_experience_engine_process_does_not_touch_model_weights(self):
        model = MLP(64, [32, 16], 10)
        cfg = Config()
        ue = UnlearningEngine(model, cfg.unlearning, device="cpu")
        ee = ExperienceEngine(cfg.experience, seed=0)

        forget_loader = _fake_loader(32, seed=1)
        retain_loader = _fake_loader(64, seed=2)
        test_loader = _fake_loader(64, seed=3)

        metrics = ue.run_cycle(forget_loader, retain_loader, test_loader, cycle=0)

        # Snapshot weights, then call ExperienceEngine.process() ONLY —
        # no UnlearningEngine method call in between.
        weights_before = copy.deepcopy(list(model.parameters()))
        ee.process(metrics)
        weights_after = list(model.parameters())

        for before, after in zip(weights_before, weights_after):
            assert torch.equal(before, after), (
                "ExperienceEngine.process() must never modify model "
                "weights — this is the project's core architectural "
                "constraint."
            )

    def test_strategy_update_carries_no_weight_references(self):
        """StrategyUpdate must be a pure hyperparameter-change descriptor
        with no tensors or model references at all."""
        cfg = Config()
        ee = ExperienceEngine(cfg.experience, seed=0)
        from unlearning_meta.schemas import UnlearningMetrics
        m = UnlearningMetrics(forget_acc=0.3, retain_acc=0.9, accuracy=0.85,
                              privacy=0.7, hallucination=0.05, stability=0.9,
                              cycle=0)
        proposal = ee.process(m)
        for field_name in vars(proposal):
            value = getattr(proposal, field_name)
            assert not isinstance(value, torch.Tensor)
            assert not isinstance(value, torch.nn.Module)


class TestShortPipelineRun:
    """A few real cycles through the full dual-engine loop should
    complete without error and produce sane metric ranges."""

    def test_five_cycles_complete_without_error(self):
        model = MLP(64, [32, 16], 10)
        cfg = Config()
        ue = UnlearningEngine(model, cfg.unlearning, device="cpu")
        ee = ExperienceEngine(cfg.experience, cfg.training.score_weights, seed=0)

        forget_loader = _fake_loader(32, seed=10)
        retain_loader = _fake_loader(64, seed=11)
        test_loader = _fake_loader(64, seed=12)

        for cycle in range(5):
            metrics = ue.run_cycle(forget_loader, retain_loader, test_loader,
                                   cycle=cycle)
            proposal = ee.process(metrics)
            ue.apply_strategy(proposal)

            for value in (metrics.forget_acc, metrics.retain_acc,
                         metrics.accuracy, metrics.privacy):
                assert 0.0 <= value <= 1.0
