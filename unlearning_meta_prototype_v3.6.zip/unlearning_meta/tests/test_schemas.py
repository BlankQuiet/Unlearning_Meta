"""
tests/test_schemas.py
=======================
Tests for schemas.py — the StrategyAction pairing/sign logic and
composite_score's target-aware behavior (ARCHITECTURE.md §16), converted
from the ad-hoc verification performed during development into a
permanent, re-runnable test suite.
"""

import pytest

from unlearning_meta.schemas import (
    StrategyAction, UnlearningMetrics, StrategyRecord, StrategyState,
)


class TestStrategyActionPairing:
    """ARCHITECTURE.md §15: static opposite-pair mapping."""

    def test_paired_actions_have_correct_opposites(self):
        pairs = [
            (StrategyAction.INCREASE_FORGETTING_STRENGTH,
             StrategyAction.DECREASE_FORGETTING_STRENGTH),
            (StrategyAction.INCREASE_NOISE, StrategyAction.DECREASE_NOISE),
            (StrategyAction.INCREASE_EWC, StrategyAction.DECREASE_EWC),
            (StrategyAction.INCREASE_GRAD_CLIP, StrategyAction.DECREASE_GRAD_CLIP),
        ]
        for a, b in pairs:
            assert a.opposite == b
            assert b.opposite == a

    def test_unpaired_actions_have_no_opposite(self):
        # increase_replay / increase_correction_replay never had a
        # decrease_ counterpart, even in the original 7-action spec.
        assert StrategyAction.INCREASE_REPLAY.opposite is None
        assert StrategyAction.INCREASE_CORRECTION_REPLAY.opposite is None
        assert StrategyAction.NOOP.opposite is None

    def test_sign_matches_direction(self):
        assert StrategyAction.INCREASE_NOISE.sign == +1
        assert StrategyAction.DECREASE_NOISE.sign == -1
        assert StrategyAction.INCREASE_GRAD_CLIP.sign == +1
        assert StrategyAction.DECREASE_GRAD_CLIP.sign == -1

    def test_config_attr_mapping_complete_for_non_noop_actions(self):
        for action in StrategyAction:
            if action == StrategyAction.NOOP:
                assert action.config_attr is None
            else:
                assert action.config_attr is not None


class TestCompositeScore:
    """ARCHITECTURE.md §16: target-aware scoring, added without breaking
    the original whole-class-forgetting default behavior."""

    def _metrics(self, forget_acc, retain_acc=1.0):
        return UnlearningMetrics(
            forget_acc=forget_acc, retain_acc=retain_acc, accuracy=0.9,
            privacy=0.8, hallucination=0.1, stability=0.9, cycle=0,
        )

    def test_default_target_none_matches_original_formula(self):
        m = self._metrics(forget_acc=0.15)
        expected = (
            (1.0 - 0.15) + 0.8 + 0.9 + 1.0 + (-1.0) * 0.1 + 0.5 * 0.9
        )
        assert m.composite_score() == pytest.approx(expected, abs=1e-9)

    def test_target_aware_penalizes_overforgetting(self):
        # forget_acc=0.0 with target=0.9856 (an instance-level retrain
        # baseline) should score LOWER than forget_acc==target exactly,
        # since driving to 0 is over-forgetting relative to the baseline.
        over_forgotten = self._metrics(forget_acc=0.0)
        on_target = self._metrics(forget_acc=0.9856)
        score_over = over_forgotten.composite_score(target_forget_acc=0.9856)
        score_on_target = on_target.composite_score(target_forget_acc=0.9856)
        assert score_over < score_on_target

    def test_retain_floor_guardrail_dominates(self):
        m = self._metrics(forget_acc=0.5, retain_acc=0.5)
        # Without a floor, this scores normally.
        normal_score = m.composite_score()
        assert normal_score > -10.0
        # With a floor above the actual retain_acc, the guardrail fires.
        guarded_score = m.composite_score(retain_floor=0.9)
        assert guarded_score == -10.0

    def test_retain_floor_does_not_fire_when_retain_is_healthy(self):
        m = self._metrics(forget_acc=0.5, retain_acc=0.95)
        score = m.composite_score(retain_floor=0.9)
        assert score != -10.0


class TestStrategyRecordImportance:
    """The importance formula from the original project spec:
    0.35*success + 0.25*generalization + 0.20*recency + 0.20*usage."""

    def test_importance_formula_matches_spec_weights(self):
        rec = StrategyRecord(
            id="test", rule="if x > 0.5: increase_noise",
            action=StrategyAction.INCREASE_NOISE,
            condition_key="forget_acc", condition_op=">", condition_thresh=0.5,
            success_rate=1.0, generalization_score=1.0,
            usage_frequency=100, last_used=10, confidence=1.0,
            state=StrategyState.ACTIVE, created_at=0,
        )
        # At current_cycle == last_used, recency = 1.0 exactly (no elapsed
        # time), and usage_frequency=100 with max_freq=100 gives usage=1.0.
        # So importance should equal the sum of all four weights (=1.0)
        # when every component is maxed out.
        importance = rec.importance(current_cycle=10, max_freq=100)
        assert importance == pytest.approx(1.0, abs=1e-6)
