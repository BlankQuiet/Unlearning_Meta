"""
tests/test_memory_trace.py
=============================
Tests for MemoryTraceMapper, focused on to_ascent_weights() (IDEAS.md
Idea 3): converting per-neuron selectivity into a gradient-scaling map
for the ascent step itself, distinct from the existing
to_parameter_weights() (noise-injection scaling, §20/§21).

Covers two things found during calibration (measured directly on this
project's model/data, not assumed): raw selectivity is tightly clustered
around 0.5 for this task (instance-level forgetting -- forget and retain
are different samples of the same classes, so most neurons' activations
look similar either way), so to_ascent_weights() normalizes selectivity
to [0,1] before applying alpha/beta; and layers to_ascent_weights() has
no data for (output_layer) must default to an unscaled 1.0 multiplier,
NOT alpha*1.0+beta, since alpha/beta's neutral point is 0.5 here, not 1.0.
"""

import pytest
import torch

from unlearning_meta.models.base_model import MLP
from unlearning_meta.modules.unlearning.memory_trace import MemoryTraceMapper


def _mapper_with_selectivity(sel_layer_0: torch.Tensor) -> MemoryTraceMapper:
    """Bypass compute() and set selectivity directly for a controlled,
    deterministic test of to_ascent_weights()'s math in isolation."""
    m = MemoryTraceMapper(top_k=5, device="cpu")
    m.selectivity = {"layer_0": sel_layer_0}
    return m


class TestToAscentWeights:
    def test_uncovered_layer_gets_neutral_1_0_not_alpha_beta_transformed(self):
        """The critical default-safety property: output_layer has no
        entry in self.selectivity (get_activations() excludes it), and
        must get an unscaled multiplier of 1.0 -- NOT alpha*1.0+beta,
        which would silently and always amplify a layer this class has
        no actual activation data for."""
        model = MLP(64, [32, 16], 10)
        m = _mapper_with_selectivity(torch.full((32,), 0.5))
        weights = m.to_ascent_weights(model, alpha=1.0, beta=0.5)

        assert torch.all(weights["output_layer.weight"] == 1.0)
        assert torch.all(weights["output_layer.bias"] == 1.0)
        # sanity: alpha*1.0+beta would be 1.5, which the above must NOT equal
        assert not torch.all(weights["output_layer.weight"] == 1.5)

    def test_normalization_maps_full_observed_range_to_0_1_before_scaling(self):
        """With default alpha=1.0, beta=0.5: the neuron with the lowest
        selectivity in this computation should land at multiplier 0.5
        (fully suppressed floor), and the highest at 1.5 (fully
        amplified) -- regardless of how narrow the raw selectivity
        values actually are, which is the whole point of normalizing
        first (see to_ascent_weights()'s docstring for the measured
        ~[0.39, 0.59] raw range that motivated this)."""
        model = MLP(64, [4], 10)  # single hidden layer of width 4
        sel = torch.tensor([0.48, 0.50, 0.52, 0.49])  # narrow, like real data
        m = _mapper_with_selectivity(sel)
        weights = m.to_ascent_weights(model, alpha=1.0, beta=0.5)

        bias_w = weights["linears.0.bias"]
        assert bias_w[torch.argmin(sel)].item() == pytest.approx(0.5, abs=1e-5)
        assert bias_w[torch.argmax(sel)].item() == pytest.approx(1.5, abs=1e-5)

    def test_degenerate_constant_selectivity_does_not_blow_up(self):
        """If every covered neuron has identical selectivity (spread=0),
        dividing by that near-zero spread must not produce inf/nan --
        every covered neuron should land exactly at the neutral midpoint
        instead."""
        model = MLP(64, [4], 10)
        sel = torch.full((4,), 0.5013)  # constant
        m = _mapper_with_selectivity(sel)
        weights = m.to_ascent_weights(model, alpha=1.0, beta=0.5)

        bias_w = weights["linears.0.bias"]
        assert torch.isfinite(bias_w).all()
        assert torch.allclose(bias_w, torch.full_like(bias_w, 1.0), atol=1e-5)

    def test_no_selectivity_computed_yet_returns_all_neutral(self):
        """Before compute() has ever been called, self.selectivity is
        empty -- to_ascent_weights() must return neutral 1.0 everywhere
        rather than erroring."""
        model = MLP(64, [16], 10)
        m = MemoryTraceMapper(top_k=5, device="cpu")
        weights = m.to_ascent_weights(model)
        assert all(torch.all(w == 1.0) for w in weights.values())

    def test_alpha_zero_gives_uniform_beta_everywhere(self):
        """alpha=0 should collapse every covered neuron to exactly beta,
        regardless of its (normalized) selectivity -- a basic sanity
        check on the linear formula itself."""
        model = MLP(64, [4], 10)
        sel = torch.tensor([0.40, 0.55, 0.45, 0.59])
        m = _mapper_with_selectivity(sel)
        weights = m.to_ascent_weights(model, alpha=0.0, beta=0.5)
        assert torch.allclose(weights["linears.0.bias"], torch.full((4,), 0.5))

    def test_to_parameter_weights_unaffected_by_this_change(self):
        """to_ascent_weights() is new, additive code -- the existing
        to_parameter_weights() method (used by §20/§21's selective noise
        injection) must be completely untouched."""
        model = MLP(64, [4], 10)
        sel = torch.tensor([0.40, 0.55, 0.45, 0.59])
        m = _mapper_with_selectivity(sel)
        weights = m.to_parameter_weights(model)
        # Original semantics: raw selectivity, not normalized or rescaled.
        assert torch.allclose(weights["linears.0.bias"], sel)
        assert torch.all(weights["output_layer.weight"] == 1.0)


class TestMeanNormalizedWeights:
    """IDEAS.md Idea 10: does mean-normalization (fixing the AGGREGATE
    mean, not just the range) succeed where to_parameter_weights() (raw)
    and to_ascent_weights() (min-max) both left an aggregate dilution gap
    on skewed distributions (ARCHITECTURE.md §26.4, §27.2)?"""

    def test_noise_weights_mean_is_exactly_one_even_when_skewed(self):
        """The whole point of this method: unlike raw selectivity (whose
        mean varies with the task, §25/§26.4) or min-max normalization
        (which preserves skew, §27.2), the covered-parameter mean must
        land at exactly 1.0 regardless of how skewed the input is."""
        model = MLP(64, [6], 10)
        # Heavily right-skewed, like §25's measured class-level shape
        # (median << mean): mostly small values, one large outlier.
        skewed = torch.tensor([0.01, 0.02, 0.03, 0.02, 0.01, 0.85])
        m = _mapper_with_selectivity(skewed)
        weights = m.to_parameter_weights_mean_normalized(model)
        assert weights["linears.0.bias"].mean().item() == pytest.approx(1.0, abs=1e-5)
        # Relative order preserved (still differentiates high/low selectivity)
        assert weights["linears.0.bias"][5] > weights["linears.0.bias"][0]

    def test_ascent_weights_mean_is_exactly_one_even_when_skewed(self):
        """Same property for the ascent formula: mean(alpha*s+beta) must
        land at alpha*0.5+beta (=1.0 with the §24.1 defaults), not the
        ~0.83 §27.2 found min-max normalization actually produces on a
        skewed distribution."""
        model = MLP(64, [6], 10)
        skewed = torch.tensor([0.01, 0.02, 0.03, 0.02, 0.01, 0.85])
        m = _mapper_with_selectivity(skewed)
        weights = m.to_ascent_weights_mean_normalized(model, alpha=1.0, beta=0.5)
        assert weights["linears.0.bias"].mean().item() == pytest.approx(1.0, abs=1e-5)

    def test_noise_uncovered_layer_still_gets_neutral_1_0(self):
        """Same default-safety property as to_ascent_weights(): a layer
        this class has no data for must not be swept into either
        transform."""
        model = MLP(64, [4], 10)
        m = _mapper_with_selectivity(torch.tensor([0.1, 0.2, 0.15, 0.9]))
        noise_w = m.to_parameter_weights_mean_normalized(model)
        ascent_w = m.to_ascent_weights_mean_normalized(model)
        assert torch.all(noise_w["output_layer.weight"] == 1.0)
        assert torch.all(ascent_w["output_layer.weight"] == 1.0)

    def test_degenerate_near_zero_mean_does_not_explode(self):
        """A layer whose selectivity happens to average out near zero
        must not produce an enormous scale factor (target_mean / ~0) --
        floored to the neutral value instead, mirroring
        _effective_epsilon's floor for the same class of edge case."""
        model = MLP(64, [4], 10)
        near_zero = torch.tensor([1e-8, 2e-8, 0.0, 1e-8])
        m = _mapper_with_selectivity(near_zero)
        noise_w = m.to_parameter_weights_mean_normalized(model)
        ascent_w = m.to_ascent_weights_mean_normalized(model)
        assert torch.isfinite(noise_w["linears.0.bias"]).all()
        assert torch.isfinite(ascent_w["linears.0.bias"]).all()
        assert torch.allclose(noise_w["linears.0.bias"], torch.ones(4))

    def test_mean_normalized_stays_close_to_neutral_when_input_is_already_tight(self):
        """The key behavioral DIFFERENCE from to_ascent_weights(), worth
        making explicit rather than assumed: min-max normalization always
        stretches its input to fill [0,1], regardless of how narrow the
        raw range was -- so on a tight, roughly-symmetric distribution
        (like §24.1's real instance-level measurement, std~0.03),
        to_ascent_weights() still produces the full [0.5, 1.5] spread.
        Mean-normalization does not have this property: it preserves
        each element's proportional distance from the distribution's OWN
        mean, so a tight input stays close to the neutral multiplier
        rather than being stretched out. Confirms these are genuinely
        different transforms, not just two ways of writing the same one
        that happen to agree when skew is low."""
        model = MLP(64, [4], 10)
        tight = torch.tensor([0.47, 0.52, 0.49, 0.51])  # narrow, like real instance-level data
        m = _mapper_with_selectivity(tight)

        existing = m.to_ascent_weights(model, alpha=1.0, beta=0.5)
        new = m.to_ascent_weights_mean_normalized(model, alpha=1.0, beta=0.5)

        # min-max: stretched to the full intended [0.5, 1.5] spread regardless
        assert existing["linears.0.bias"].max() - existing["linears.0.bias"].min() == pytest.approx(1.0, abs=1e-4)
        # mean-normalized: stays close to neutral, since the raw input
        # was already close to its own mean everywhere
        assert torch.allclose(new["linears.0.bias"], torch.ones(4), atol=0.05)
