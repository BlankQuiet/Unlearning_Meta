"""
tests/test_fisher_forgetting_baseline.py
============================================
Tests for the Fisher Forgetting literature baseline (ARCHITECTURE.md
§19), covering the epsilon-scaling bug found during development: an
epsilon larger than the architecture's typical Fisher magnitude collapses
the inverse-weighting mechanism into a near-constant multiplier instead
of actually differentiating important from unimportant parameters.
"""

import pytest
import torch
from torch.utils.data import DataLoader, TensorDataset

from unlearning_meta.models.base_model import MLP
from unlearning_meta.modules.unlearning.fisher_forgetting_baseline import (
    FisherForgettingBaseline,
)


def _fake_retain_loader(n=64, seed=0):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(n, 1, 8, 8, generator=g)
    y = torch.randint(0, 10, (n,), generator=g)
    return DataLoader(TensorDataset(x, y), batch_size=16)


class TestFisherForgettingBaseline:
    def test_scrub_runs_without_error(self):
        """Regression test for the original bug: wrapping the whole
        scrub() method in @torch.no_grad() silently broke the internal
        FisherInformation.compute() call, which needs gradients enabled
        for its own loss.backward()."""
        model = MLP(64, [32, 16], 10)
        loader = _fake_retain_loader()
        ff = FisherForgettingBaseline(noise_scale=1e-6, device="cpu")
        scrubbed = ff.scrub(model, loader, fisher_samples=32)
        assert scrubbed is not None

    def test_scrub_returns_a_different_object_than_the_input(self):
        """The original model must be left untouched (matching how every
        other condition in this project works from a fresh deep-copy)."""
        model = MLP(64, [32, 16], 10)
        loader = _fake_retain_loader()
        original_params = [p.clone() for p in model.parameters()]

        ff = FisherForgettingBaseline(noise_scale=1e-4, device="cpu")
        scrubbed = ff.scrub(model, loader, fisher_samples=32)

        assert scrubbed is not model
        for orig, current in zip(original_params, model.parameters()):
            assert torch.equal(orig, current), (
                "scrub() must not modify the input model in place"
            )

    def test_epsilon_default_is_small_relative_to_typical_fisher_magnitude(self):
        """Regression test for the calibration bug: epsilon must be well
        below typical Fisher magnitudes (~1e-8 to 1e-6 for this project's
        MLP architecture, per §19.1's measurement) or the inverse
        weighting degenerates into an undifferentiated constant."""
        ff = FisherForgettingBaseline()
        assert ff.epsilon <= 1e-9, (
            "epsilon should be well below the ~1e-8 median Fisher "
            "magnitude found during calibration (§19.1) — the original "
            "1e-6 default was larger than that median, which silently "
            "broke the Fisher-inverse-weighting mechanism"
        )

    def test_effective_epsilon_default_matches_original_global_epsilon(self):
        """Regression test for the §19.3 per-layer-normalization extension:
        with per_layer_normalize left at its default (False), _effective_
        epsilon must return exactly self.epsilon for ANY input tensor —
        no dependence on the Fisher values at all. This is what guarantees
        every existing result in ARCHITECTURE.md (§19's n=15 comparison,
        the epsilon-calibration tests above) is completely unaffected by
        adding this option."""
        ff = FisherForgettingBaseline(noise_scale=3e-6, epsilon=1e-10, device="cpu")
        assert ff.per_layer_normalize is False

        # Wildly different Fisher tensors — a global-epsilon default must
        # ignore their content entirely and always return self.epsilon.
        tiny = torch.full((10,), 1e-15)
        typical = torch.full((10,), 1.9e-8)
        huge = torch.full((10,), 8.2e-6)
        zeros = torch.zeros(10)

        for f in (tiny, typical, huge, zeros):
            assert ff._effective_epsilon(f) == 1e-10

    def test_effective_epsilon_per_layer_uses_layer_median(self):
        """When enabled, the floor should scale with this specific layer's
        own median Fisher value, not a global constant."""
        ff = FisherForgettingBaseline(
            noise_scale=3e-6, epsilon=1e-10, device="cpu",
            per_layer_normalize=True, per_layer_eps_fraction=0.01,
        )
        f_layer = torch.full((100,), 1e-6)  # this layer's median is 1e-6
        expected = max(1e-10, 0.01 * 1e-6)  # = 1e-8
        # approx, not ==: torch.median().item() round-trips through
        # float32, so it won't bit-exact-match a pure-Python float64
        # multiplication even though both compute "the same" value.
        assert ff._effective_epsilon(f_layer) == pytest.approx(expected, rel=1e-5)
        assert ff._effective_epsilon(f_layer) > ff.epsilon, (
            "for a layer with typical (non-tiny) Fisher values, the "
            "per-layer floor should exceed the absolute global floor"
        )

    def test_effective_epsilon_per_layer_respects_absolute_floor(self):
        """A layer whose own median Fisher value is itself ~0 (e.g. a
        dead layer) must not produce an even-smaller proportional floor —
        self.epsilon remains the absolute safety net in that case."""
        ff = FisherForgettingBaseline(
            noise_scale=3e-6, epsilon=1e-10, device="cpu",
            per_layer_normalize=True, per_layer_eps_fraction=0.01,
        )
        dead_layer = torch.zeros(50)
        assert ff._effective_epsilon(dead_layer) == 1e-10

    def test_scrub_runs_with_per_layer_normalize_enabled(self):
        """Integration smoke test: the new mode must not error, and must
        still leave the input model untouched (same contract as default)."""
        model = MLP(64, [32, 16], 10)
        loader = _fake_retain_loader()
        original_params = [p.clone() for p in model.parameters()]

        ff = FisherForgettingBaseline(
            noise_scale=3e-6, epsilon=1e-10, device="cpu",
            per_layer_normalize=True,
        )
        scrubbed = ff.scrub(model, loader, fisher_samples=32)

        assert scrubbed is not None
        assert scrubbed is not model
        for orig, current in zip(original_params, model.parameters()):
            assert torch.equal(orig, current)

    def test_higher_noise_scale_causes_more_forgetting(self):
        """Sanity check on the dose-response direction: more noise should
        move forget_acc further from its pre-scrub value, on average."""
        torch.manual_seed(0)
        model = MLP(64, [32, 16], 10)
        loader = _fake_retain_loader(n=128, seed=1)

        ff_small = FisherForgettingBaseline(noise_scale=1e-8, device="cpu")
        ff_large = FisherForgettingBaseline(noise_scale=1e-4, device="cpu")

        scrubbed_small = ff_small.scrub(model, loader, fisher_samples=64)
        scrubbed_large = ff_large.scrub(model, loader, fisher_samples=64)

        # Larger noise_scale should move parameters further from the
        # original model, on average across all parameters.
        def total_drift(scrubbed):
            return sum(
                (p1 - p2).norm().item()
                for p1, p2 in zip(model.parameters(), scrubbed.parameters())
            )

        assert total_drift(scrubbed_large) > total_drift(scrubbed_small)
