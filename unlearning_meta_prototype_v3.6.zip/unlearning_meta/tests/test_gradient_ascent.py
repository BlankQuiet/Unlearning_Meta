"""
tests/test_gradient_ascent.py
================================
Tests for GradientAscentForgetter, focused on the new ascent_weights
parameter (IDEAS.md Idea 3): scaling the ascent GRADIENT itself by
selectivity, distinct from the existing selectivity_weights parameter
(which scales post-ascent NOISE injection, §20/§21). No test file
existed for this module before -- these also cover baseline run()
behavior needed as a safety net for the ascent_weights addition.
"""

from unittest.mock import patch

import pytest
import torch
from torch.utils.data import DataLoader, TensorDataset

from unlearning_meta.models.base_model import MLP
from unlearning_meta.modules.unlearning.gradient_ascent import GradientAscentForgetter


def _fake_forget_loader(n=32, seed=0):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(n, 1, 8, 8, generator=g)
    y = torch.randint(0, 10, (n,), generator=g)
    return DataLoader(TensorDataset(x, y), batch_size=16)


class TestScaleAscentGradients:
    def test_scales_matching_parameters_by_their_weight(self):
        model = MLP(64, [4], 10)
        forgetter = GradientAscentForgetter(model, max_epochs=1, device="cpu")

        for p in model.parameters():
            p.grad = torch.ones_like(p.data)

        weights = {name: torch.full_like(p.data, 2.0)
                   for name, p in model.named_parameters()}
        forgetter._scale_ascent_gradients(weights)

        for p in model.parameters():
            assert torch.allclose(p.grad, torch.full_like(p.data, 2.0))

    def test_parameters_missing_from_weights_dict_are_left_alone(self):
        model = MLP(64, [4], 10)
        forgetter = GradientAscentForgetter(model, max_epochs=1, device="cpu")

        for p in model.parameters():
            p.grad = torch.full_like(p.data, 3.0)

        forgetter._scale_ascent_gradients({})  # no entries at all

        for p in model.parameters():
            assert torch.allclose(p.grad, torch.full_like(p.data, 3.0))

    def test_parameters_with_no_grad_are_skipped_not_errored(self):
        model = MLP(64, [4], 10)
        forgetter = GradientAscentForgetter(model, max_epochs=1, device="cpu")
        # No .grad set on anything (as if backward() was never called)
        weights = {name: torch.full_like(p.data, 2.0)
                   for name, p in model.named_parameters()}
        forgetter._scale_ascent_gradients(weights)  # must not raise


class TestRunDefaultBehaviorUnchanged:
    def test_ascent_weights_none_never_calls_scale_ascent_gradients(self):
        """Regression test: the default (ascent_weights=None) must take
        the exact code path this module had before Idea 3 -- i.e.
        _scale_ascent_gradients must never even be invoked, not just
        invoked with a no-op weight."""
        model = MLP(64, [8], 10)
        forgetter = GradientAscentForgetter(model, max_epochs=1, device="cpu")
        loader = _fake_forget_loader()

        with patch.object(
            forgetter, "_scale_ascent_gradients", wraps=forgetter._scale_ascent_gradients
        ) as mocked:
            forgetter.run(loader)  # ascent_weights omitted -> default None
            mocked.assert_not_called()

    def test_ascent_weights_provided_does_call_scale_ascent_gradients(self):
        model = MLP(64, [8], 10)
        forgetter = GradientAscentForgetter(model, max_epochs=1, device="cpu")
        loader = _fake_forget_loader()
        weights = {name: torch.ones_like(p.data)
                   for name, p in model.named_parameters()}

        with patch.object(
            forgetter, "_scale_ascent_gradients", wraps=forgetter._scale_ascent_gradients
        ) as mocked:
            forgetter.run(loader, ascent_weights=weights)
            assert mocked.call_count > 0


class TestRunWithAscentWeightsIntegration:
    def test_run_completes_and_changes_model(self):
        model = MLP(64, [8], 10)
        original = [p.clone() for p in model.parameters()]
        forgetter = GradientAscentForgetter(model, forget_lr=0.05, max_epochs=2, device="cpu")
        loader = _fake_forget_loader()
        weights = {name: torch.full_like(p.data, 1.5)
                   for name, p in model.named_parameters()}

        stats = forgetter.run(loader, ascent_weights=weights)

        assert "avg_forget_loss" in stats
        assert any(not torch.equal(o, p) for o, p in zip(original, model.parameters()))

    def test_asymmetric_weights_produce_different_result_than_uniform(self):
        """A meaningful end-to-end check that ascent_weights actually
        changes training dynamics, not just that the code runs: scaling
        one layer's gradient much harder than another, from the same
        starting point, should not land at the same parameters as
        leaving ascent unweighted."""
        torch.manual_seed(0)
        model_a = MLP(64, [8], 10)
        model_b = MLP(64, [8], 10)
        model_b.load_state_dict(model_a.state_dict())  # identical start

        loader_a = _fake_forget_loader(seed=1)
        loader_b = _fake_forget_loader(seed=1)

        torch.manual_seed(1)
        GradientAscentForgetter(model_a, forget_lr=0.05, max_epochs=2,
                                noise_scale=0.0, device="cpu").run(loader_a)

        weights = {}
        for name, p in model_b.named_parameters():
            weights[name] = torch.full_like(p.data, 3.0 if "linears.0" in name else 0.3)
        torch.manual_seed(1)
        GradientAscentForgetter(model_b, forget_lr=0.05, max_epochs=2,
                                noise_scale=0.0, device="cpu").run(loader_b, ascent_weights=weights)

        diffs = [not torch.allclose(pa, pb, atol=1e-6)
                 for pa, pb in zip(model_a.parameters(), model_b.parameters())]
        assert any(diffs)
