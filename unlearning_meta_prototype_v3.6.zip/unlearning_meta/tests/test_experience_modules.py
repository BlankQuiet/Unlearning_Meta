"""
tests/test_experience_modules.py
===================================
Tests for the Experience Engine's modules, converting ad-hoc verification
performed during development (rule evolution's exact spec example, the
exploration-rate independent-resampling bug fix) into a permanent suite.
"""

import pytest

from unlearning_meta.schemas import (
    StrategyRecord, StrategyAction, StrategyState, UnlearningMetrics,
)
from unlearning_meta.modules.experience.strategy_memory import StrategyMemory
from unlearning_meta.modules.experience.strategy_evolution import StrategyEvolution
from unlearning_meta.config import ExperienceConfig
from unlearning_meta.engines.experience_engine import ExperienceEngine


class TestStrategyEvolution:
    """The exact example from the original project spec:
    forget_acc > 0.25/0.30/0.35 -> increase_noise, merged into one rule."""

    def test_spec_example_merges_into_one_evolved_rule(self):
        mem = StrategyMemory()
        for i, thresh in enumerate([0.25, 0.30, 0.35]):
            mem.add(StrategyRecord(
                id=f"r{i}", rule=f"if forget_acc > {thresh}: increase_noise",
                action=StrategyAction.INCREASE_NOISE,
                condition_key="forget_acc", condition_op=">",
                condition_thresh=thresh, success_rate=0.7,
                generalization_score=0.5, usage_frequency=5,
                last_used=10, confidence=0.7, state=StrategyState.ACTIVE,
                created_at=0,
            ))

        evolver = StrategyEvolution(similarity_thresh=0.5)
        n_merges = evolver.evolve(mem, current_cycle=10)

        survivors = [r for r in mem.records.values()
                    if r.state != StrategyState.DELETED]
        assert n_merges == 1
        assert len(survivors) == 1
        assert survivors[0].usage_frequency == 15  # 5+5+5 summed
        assert "EVOLVED" in survivors[0].rule


class TestExplorationRateFix:
    """ARCHITECTURE.md §11.2: the explore/exploit coin flip must be sampled
    exactly once per call, not independently at each tier — an earlier
    version resampled up to 3x, making the true P(explore) ~4x lower than
    the configured exploration_rate."""

    def test_empirical_explore_rate_matches_configured_rate(self):
        cfg = ExperienceConfig()
        cfg.exploration_rate = 0.15
        ee = ExperienceEngine(cfg, seed=0)

        explore_count = 0
        n = 1000
        for i in range(n):
            m = UnlearningMetrics(
                forget_acc=0.3, retain_acc=0.9, accuracy=0.85,
                privacy=0.7, hallucination=0.05, stability=0.9, cycle=i,
            )
            p = ee.process(m)
            if p.rationale.startswith("ε-explore"):
                explore_count += 1

        empirical_rate = explore_count / n
        # Should be close to 0.15, NOT close to ~0.04 (the old bug's rate)
        assert empirical_rate == pytest.approx(0.15, abs=0.03)


class TestContextualBanditMomentum:
    """ARCHITECTURE.md §15: paired actions (increase_X/decrease_X) should
    not thrash every cycle once momentum is engaged."""

    def test_bandit_is_opt_in_and_disabled_by_default(self):
        cfg = ExperienceConfig()
        ee = ExperienceEngine(cfg, seed=0)
        assert ee.bandit is None

    def test_bandit_enabled_when_configured(self):
        cfg = ExperienceConfig()
        cfg.use_contextual_bandit = True
        ee = ExperienceEngine(cfg, seed=0)
        assert ee.bandit is not None
