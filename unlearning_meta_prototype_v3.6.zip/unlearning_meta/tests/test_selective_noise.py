"""
tests/test_selective_noise.py
================================
Tests for MemoryTraceMapper.to_parameter_weights() and its connection to
GradientAscentForgetter's noise injection — closing the gap found during
external review where selectivity was computed but never used to
actually target weight perturbation (measurement without control).
"""

import torch
from torch.utils.data import DataLoader, TensorDataset

from unlearning_meta.config import Config
from unlearning_meta.models.base_model import MLP
from unlearning_meta.modules.unlearning.memory_trace import MemoryTraceMapper
from unlearning_meta.modules.unlearning.gradient_ascent import GradientAscentForgetter
from unlearning_meta.engines.unlearning_engine import UnlearningEngine


def _loader(n, seed):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(n, 1, 8, 8, generator=g)
    y = torch.randint(0, 10, (n,), generator=g)
    return DataLoader(TensorDataset(x, y), batch_size=16)


class TestToParameterWeights:
    def test_output_shapes_match_model_parameters_exactly(self):
        model = MLP(64, [128, 64], 10)
        trace = MemoryTraceMapper(top_k=20, device="cpu")
        trace.compute(model, _loader(50, 1), _loader(200, 2))

        weights = trace.to_parameter_weights(model)
        for name, param in model.named_parameters():
            assert name in weights
            assert weights[name].shape == param.shape

    def test_output_layer_is_neutral_since_it_was_never_measured(self):
        """get_activations() explicitly excludes the output layer, so
        to_parameter_weights() must default it to 1.0 (unmodified),
        not guess a value for something that was never measured."""
        model = MLP(64, [128, 64], 10)
        trace = MemoryTraceMapper(top_k=20, device="cpu")
        trace.compute(model, _loader(50, 1), _loader(200, 2))

        weights = trace.to_parameter_weights(model)
        assert torch.allclose(weights["output_layer.weight"],
                              torch.ones_like(weights["output_layer.weight"]))
        assert torch.allclose(weights["output_layer.bias"],
                              torch.ones_like(weights["output_layer.bias"]))

    def test_weight_values_are_bounded_reasonably(self):
        model = MLP(64, [64, 32], 10)
        trace = MemoryTraceMapper(top_k=10, device="cpu")
        trace.compute(model, _loader(50, 1), _loader(200, 2))
        weights = trace.to_parameter_weights(model)
        for name, w in weights.items():
            assert w.min() >= 0.0
            assert w.max() <= 1.0 + 1e-6


class TestSelectiveNoiseInjection:
    def test_none_gives_identical_behavior_to_uniform_noise(self):
        """Regression test: selectivity_weights=None must reproduce the
        exact original uniform-noise formula, byte for byte given the
        same RNG state."""
        model_a = MLP(64, [32, 16], 10)
        model_b = MLP(64, [32, 16], 10)
        model_b.load_state_dict(model_a.state_dict())  # identical start

        loader = _loader(64, 5)

        torch.manual_seed(0)
        fg_a = GradientAscentForgetter(model_a, device="cpu", noise_scale=0.01)
        fg_a.run(loader, selectivity_weights=None)

        torch.manual_seed(0)
        fg_b = GradientAscentForgetter(model_b, device="cpu", noise_scale=0.01)
        fg_b.run(loader)  # omitted entirely, same default

        for p_a, p_b in zip(model_a.parameters(), model_b.parameters()):
            assert torch.equal(p_a, p_b)

    def test_selective_noise_end_to_end_via_config_flag(self):
        """The opt-in config flag correctly threads through
        UnlearningEngine.run_cycle() end to end without error."""
        model = MLP(64, [32, 16], 10)
        cfg = Config().unlearning
        cfg.selective_noise_enabled = True
        ue = UnlearningEngine(model, cfg, device="cpu")

        forget_loader = _loader(32, 10)
        retain_loader = _loader(64, 11)
        test_loader = _loader(64, 12)

        metrics = ue.run_cycle(forget_loader, retain_loader, test_loader, cycle=0)
        assert 0.0 <= metrics.forget_acc <= 1.0
        assert 0.0 <= metrics.retain_acc <= 1.0

    def test_default_config_flag_is_false(self):
        """Opt-in: existing behavior must be unaffected unless explicitly
        enabled."""
        cfg = Config().unlearning
        assert cfg.selective_noise_enabled is False
