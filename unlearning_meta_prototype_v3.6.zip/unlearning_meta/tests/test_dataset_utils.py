"""
tests/test_dataset_utils.py
==============================
Tests for data/dataset_utils.py, focused on load_wine_instance_forgetting
(IDEAS.md Idea 11's first cross-dataset generalization check). No test
file existed for this module before.
"""

import numpy as np

from unlearning_meta.data.dataset_utils import load_wine_instance_forgetting


class TestLoadWineInstanceForgetting:
    def test_runs_and_returns_four_loaders(self):
        fl, rl, tl, full = load_wine_instance_forgetting(seed=42)
        assert fl is not None and rl is not None and tl is not None and full is not None

    def test_feature_dimension_is_13_not_64(self):
        """Sanity check this is genuinely a different input shape from
        the digits benchmark (64 features) -- confirms this isn't
        accidentally loading the same data under a new name."""
        fl, rl, tl, full = load_wine_instance_forgetting(seed=42)
        x, y = next(iter(rl))
        assert x.shape[1] == 13

    def test_three_classes_not_ten(self):
        fl, rl, tl, full = load_wine_instance_forgetting(seed=42)
        all_y = []
        for _, y in full:
            all_y.append(y)
        import torch
        classes = torch.cat(all_y).unique()
        assert len(classes) == 3

    def test_forgets_approximately_10_percent_of_each_class(self):
        """Stratified per-class forgetting, not whole-class or
        dataset-wide-fraction forgetting -- mirrors
        load_digits_instance_forgetting's own design intent."""
        fl, rl, tl, full = load_wine_instance_forgetting(forget_fraction=0.10, seed=42)
        forget_ys, retain_ys = [], []
        for _, y in fl:
            forget_ys.append(y)
        for _, y in rl:
            retain_ys.append(y)
        import torch
        forget_counts = np.bincount(torch.cat(forget_ys).numpy(), minlength=3)
        retain_counts = np.bincount(torch.cat(retain_ys).numpy(), minlength=3)
        for f, r in zip(forget_counts, retain_counts):
            total = f + r
            assert total > 0
            frac = f / total
            # small-sample rounding (max(1, int(n*0.10))) means this
            # won't be exactly 10% for every class -- checked loosely
            assert 0.05 <= frac <= 0.20

    def test_no_overlap_between_forget_and_retain(self):
        """Same-seed determinism + disjointness: every training sample
        must be in exactly one of forget/retain, never both."""
        fl, rl, tl, full = load_wine_instance_forgetting(seed=42)
        forget_n = sum(len(y) for _, y in fl)
        retain_n = sum(len(y) for _, y in rl)
        full_n = sum(len(y) for _, y in full)
        assert forget_n + retain_n == full_n

    def test_same_seed_is_reproducible(self):
        """Matches how every run_*.py script in this project actually
        calls these loaders: set_seed() first, then the loader's own
        seed= parameter. The seed= parameter alone determines WHICH
        samples land in forget/retain/test (via train_test_split's
        random_state and the per-class rng.choice calls) -- but
        DataLoader(shuffle=True)'s ITERATION order depends on the global
        torch RNG, which set_seed() controls and the loader function
        does not touch itself. Without calling set_seed() first, this
        property doesn't hold (found while writing this test -- the
        first version asserted it without calling set_seed(), and
        failed; confirmed independently, outside pytest, that adding
        set_seed() fixes it, matching every other loader in this
        project including load_digits_instance_forgetting, which has
        the identical shuffle=True dependency)."""
        from unlearning_meta.main import set_seed

        set_seed(7)
        fl1, rl1, tl1, _ = load_wine_instance_forgetting(seed=7)
        x1, y1 = next(iter(rl1))

        set_seed(7)
        fl2, rl2, tl2, _ = load_wine_instance_forgetting(seed=7)
        x2, y2 = next(iter(rl2))

        import torch
        assert torch.equal(x1, x2)
        assert torch.equal(y1, y2)

    def test_different_seeds_produce_different_splits(self):
        """Different seed= values must select different samples into
        retain (not merely produce a different shuffle order at fixed
        content) -- checked via the full retain set's sorted content,
        not just the first (shuffle-order-dependent) batch."""
        from unlearning_meta.main import set_seed
        import torch

        set_seed(7)
        _, rl1, _, _ = load_wine_instance_forgetting(seed=7)
        x1 = torch.cat([x for x, _ in rl1]).sort(dim=0).values

        set_seed(8)
        _, rl2, _, _ = load_wine_instance_forgetting(seed=8)
        x2 = torch.cat([x for x, _ in rl2]).sort(dim=0).values

        assert not torch.equal(x1, x2), (
            "different seeds selected the identical retain set -- "
            "the seed parameter isn't actually varying the split"
        )
