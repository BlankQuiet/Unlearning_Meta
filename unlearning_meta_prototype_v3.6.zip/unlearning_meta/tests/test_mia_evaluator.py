"""
tests/test_mia_evaluator.py
==============================
Tests for evaluation/mia_evaluator.py, focused on the ShadowMIA data
leakage fix (external review, 2026-08-16): the meta-classifier's
evaluation-time non-member samples must never overlap with the samples
it saw as non-members during its own training. No test file existed for
this module before -- these also cover basic end-to-end behavior needed
as a safety net for the fix.
"""

import torch
from torch.utils.data import DataLoader, TensorDataset

from unlearning_meta.models.base_model import MLP
from unlearning_meta.evaluation.mia_evaluator import ShadowMIA, ConfidenceMIA, MIAEvaluator


def _loader(n=64, seed=0):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(n, 1, 8, 8, generator=g)
    y = torch.randint(0, 10, (n,), generator=g)
    return DataLoader(TensorDataset(x, y), batch_size=16)


class TestShadowMIANoLeakage:
    def test_split_produces_disjoint_halves(self):
        """The core regression test for the fix: with a distinguishable
        fingerprint per row, the train-side and eval-side halves must
        never share a fingerprint."""
        shadow = ShadowMIA(device="cpu")
        n = 40
        fingerprints = torch.arange(n).unsqueeze(1).float().expand(n, 3)

        train_half, eval_half = shadow._split_test_outputs(fingerprints)

        train_ids = set(train_half[:, 0].tolist())
        eval_ids = set(eval_half[:, 0].tolist())
        assert train_ids.isdisjoint(eval_ids), (
            "train-side and eval-side test fingerprints must never overlap"
        )
        assert len(train_ids) + len(eval_ids) == n

    def test_split_covers_all_samples_no_duplicates_no_drops(self):
        shadow = ShadowMIA(device="cpu")
        n = 51  # odd, to also check the floor-division remainder is dropped consistently
        fingerprints = torch.arange(n).unsqueeze(1).float().expand(n, 3)
        train_half, eval_half = shadow._split_test_outputs(fingerprints)
        combined = sorted(train_half[:, 0].tolist() + eval_half[:, 0].tolist())
        # floor(51/2)=25 in train, remaining 26 in eval -- 51 total, no dupes
        assert len(combined) == n
        assert len(set(combined)) == n

    def test_degenerate_tiny_input_returns_same_tensor_both_sides(self):
        """Fewer than 2 samples can't be split -- must degrade gracefully
        (returns the same tensor for both, matching pre-fix behavior for
        this edge case) rather than raising."""
        shadow = ShadowMIA(device="cpu")
        single = torch.tensor([[0.1, 0.2, 0.7]])
        train_half, eval_half = shadow._split_test_outputs(single)
        assert torch.equal(train_half, single)
        assert torch.equal(eval_half, single)

    def test_evaluate_runs_end_to_end(self):
        model = MLP(64, [8], 10)
        forget_loader = _loader(n=32)
        retain_loader = _loader(n=32)
        test_loader = _loader(n=32)

        shadow = ShadowMIA(device="cpu", max_samples=32, meta_epochs=2)
        result = shadow.evaluate(model, forget_loader, test_loader, retain_loader)
        assert 0.0 <= result["auc"] <= 1.0
        assert 0.0 <= result["privacy_score"] <= 1.0

    def test_degenerate_tiny_test_set_does_not_crash_end_to_end(self):
        model = MLP(64, [4], 10)
        forget_loader = _loader(n=16)
        retain_loader = _loader(n=16)
        tiny_test_loader = _loader(n=1)

        shadow = ShadowMIA(device="cpu", max_samples=20, meta_epochs=1)
        result = shadow.evaluate(model, forget_loader, tiny_test_loader, retain_loader)
        assert "auc" in result

    def test_strict_split_flag_true_in_normal_case(self):
        """External review round 6 (Gemini/ChatGPT) suggested surfacing
        whether the leak-prevention split actually held for a given run,
        rather than only handling the degenerate case silently."""
        model = MLP(64, [8], 10)
        shadow = ShadowMIA(device="cpu", max_samples=32, meta_epochs=1)
        result = shadow.evaluate(model, _loader(n=32), _loader(n=32), _loader(n=32))
        assert result["strict_split"] is True

    def test_strict_split_flag_false_in_degenerate_case(self):
        model = MLP(64, [4], 10)
        shadow = ShadowMIA(device="cpu", max_samples=20, meta_epochs=1)
        result = shadow.evaluate(model, _loader(n=16), _loader(n=1), _loader(n=16))
        assert result["strict_split"] is False


class TestMIAEvaluatorIntegration:
    def test_unified_evaluator_runs_both_attacks(self):
        model = MLP(64, [8], 10)
        forget_loader = _loader(n=32)
        retain_loader = _loader(n=32)
        test_loader = _loader(n=32)

        evaluator = MIAEvaluator(device="cpu", max_samples=32)
        result = evaluator.evaluate(model, forget_loader, retain_loader, test_loader)
        assert "confidence_mia" in result
        assert "shadow_mia" in result
        assert 0.0 <= result["final_privacy"] <= 1.0
        assert result["shadow_mia"]["strict_split"] is True


class TestConfidenceMIAUnaffectedByThisChange:
    """ConfidenceMIA has no shadow classifier and no leakage concern --
    confirms the ShadowMIA fix left it untouched."""

    def test_confidence_mia_runs_end_to_end(self):
        model = MLP(64, [8], 10)
        forget_loader = _loader(n=32)
        test_loader = _loader(n=32)
        conf = ConfidenceMIA(device="cpu", max_samples=32)
        result = conf.evaluate(model, forget_loader, test_loader)
        assert 0.0 <= result["auc"] <= 1.0


class TestComputeAUCDegenerateCase:
    """Found during review: _compute_auc's defensive fallback (one class
    entirely absent) had no direct test, unlike every other defensive
    branch already covered elsewhere in this module."""

    def test_missing_class_returns_neutral_auc(self):
        from unlearning_meta.evaluation.mia_evaluator import _compute_auc
        import numpy as np

        all_positive = _compute_auc(np.array([0.1, 0.5, 0.9]), np.array([1, 1, 1]))
        assert all_positive == 0.5

        all_negative = _compute_auc(np.array([0.1, 0.5, 0.9]), np.array([0, 0, 0]))
        assert all_negative == 0.5


class TestComputeAUCTieHandling:
    """Found by external review (2026-08-16, ran the actual test suite
    and additionally exercised _compute_auc directly): the previous
    plain-argsort rank computation assigned tied scores a strict,
    arbitrary order instead of the average rank ROC-AUC requires,
    producing systematically too-low AUC values whenever ties occur --
    exactly the kind of case a small MIA evaluation set or a
    saturated/quantized model can produce. Fixed by delegating to
    sklearn.metrics.roc_auc_score (already a project dependency, already
    used for this exact computation in evaluator.py)."""

    def test_single_tied_pair_gives_neutral_auc(self):
        from unlearning_meta.evaluation.mia_evaluator import _compute_auc
        import numpy as np

        result = _compute_auc(np.array([0.5, 0.5]), np.array([1, 0]))
        assert result == 0.5

    def test_multiple_tied_pairs_give_neutral_auc(self):
        from unlearning_meta.evaluation.mia_evaluator import _compute_auc
        import numpy as np

        result = _compute_auc(
            np.array([0.5, 0.5, 0.7, 0.7]), np.array([1, 0, 1, 0])
        )
        assert result == 0.5

    def test_matches_sklearn_reference_on_a_non_trivial_case(self):
        """Cross-check against the authoritative reference implementation
        directly, on a case with both ties and clear separation, rather
        than only checking hand-computed expected values."""
        from unlearning_meta.evaluation.mia_evaluator import _compute_auc
        from sklearn.metrics import roc_auc_score
        import numpy as np
        import pytest

        scores = np.array([0.9, 0.5, 0.5, 0.5, 0.1, 0.5])
        labels = np.array([1,   1,   0,   1,   0,   0])
        ours = _compute_auc(scores, labels)
        reference = float(roc_auc_score(labels, scores))
        assert ours == pytest.approx(reference)

    def test_no_ties_still_matches_original_correct_behavior(self):
        """Regression check: cases WITHOUT ties (where the old
        implementation was already correct) must still be correct after
        switching to sklearn's implementation."""
        from unlearning_meta.evaluation.mia_evaluator import _compute_auc
        import numpy as np
        import pytest

        perfect_separation = _compute_auc(
            np.array([0.9, 0.8, 0.2, 0.1]), np.array([1, 1, 0, 0])
        )
        assert perfect_separation == pytest.approx(1.0)

        perfect_inversion = _compute_auc(
            np.array([0.1, 0.2, 0.8, 0.9]), np.array([1, 1, 0, 0])
        )
        assert perfect_inversion == pytest.approx(0.0)
