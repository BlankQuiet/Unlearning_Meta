"""
tests/test_unlearning_modules.py
===================================
Tests for Unlearning Engine modules, covering two real bugs found and
fixed during development (ARCHITECTURE.md §10, §12): a BatchNorm1d crash
on size-1 trailing batches, and the gradient-clip saturation that
silently capped increase_forgetting_strength's effect.
"""

import torch
from torch.utils.data import DataLoader, TensorDataset

from unlearning_meta.config import UnlearningConfig
from unlearning_meta.models.base_model import MLP
from unlearning_meta.modules.unlearning.dream_replay import DreamReplayer
from unlearning_meta.modules.unlearning.gradient_ascent import GradientAscentForgetter
from unlearning_meta.engines.unlearning_engine import UnlearningEngine


class TestBatchNormGuard:
    """ARCHITECTURE.md §10: BatchNorm1d requires >=2 samples per batch in
    train() mode; a trailing batch of exactly 1 sample used to crash."""

    def test_gradient_ascent_survives_size_one_trailing_batch(self):
        model = MLP(64, [32, 16], 10)
        # 17 samples, batch_size=16 -> trailing batch has exactly 1 sample
        loader = DataLoader(
            TensorDataset(torch.randn(17, 1, 8, 8), torch.randint(0, 10, (17,))),
            batch_size=16,
        )
        forgetter = GradientAscentForgetter(model, device="cpu")
        result = forgetter.run(loader)  # must not raise
        assert "avg_forget_loss" in result

    def test_dream_replay_handles_zero_confident_samples(self):
        model = MLP(64, [32, 16], 10)
        loader = DataLoader(
            TensorDataset(torch.randn(50, 1, 8, 8), torch.randint(0, 10, (50,))),
            batch_size=16,
        )
        # Impossibly high confidence threshold -> zero samples qualify
        dreamer = DreamReplayer(model, confidence_thresh=0.999, device="cpu")
        result = dreamer.run(loader)  # must not raise
        assert result["dream_count"] == 0


class TestGradClipFix:
    """ARCHITECTURE.md §12.3: max_grad_norm is a real, adjustable
    UnlearningConfig field with sane bounds enforced by
    UnlearningEngine.apply_strategy()'s clamp."""

    def test_max_grad_norm_has_a_default(self):
        cfg = UnlearningConfig()
        assert cfg.max_grad_norm == 1.0

    def test_grad_clip_action_is_multiplicative_and_bounded(self):
        from unlearning_meta.schemas import StrategyUpdate, StrategyAction

        model = MLP(64, [32, 16], 10)
        ue = UnlearningEngine(model, UnlearningConfig(), device="cpu")
        for _ in range(30):
            ue.apply_strategy(StrategyUpdate(
                action=StrategyAction.INCREASE_GRAD_CLIP, delta=0.3,
            ))
        # Should be clamped, not run away unboundedly
        assert ue.config.max_grad_norm <= 50.0
        assert ue.config.max_grad_norm > 1.0  # did actually increase
