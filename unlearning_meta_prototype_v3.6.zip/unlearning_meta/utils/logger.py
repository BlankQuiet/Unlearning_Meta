"""
utils/logger.py
================
Structured experiment logger.

Writes to:
  • stdout        (human-readable, colour-coded)
  • logs/exp.log  (plain text)
  • logs/exp.jsonl (structured JSON Lines)
"""

from __future__ import annotations
import json
import logging
import os
import time
from typing import Any, Dict, Optional

from unlearning_meta.schemas import UnlearningMetrics, StrategyUpdate


# ANSI colour codes
_GREEN  = "\033[92m"
_YELLOW = "\033[93m"
_RED    = "\033[91m"
_CYAN   = "\033[96m"
_BOLD   = "\033[1m"
_RESET  = "\033[0m"


def _colour(score: float) -> str:
    if score >= 4.0:
        return _GREEN
    elif score >= 3.0:
        return _YELLOW
    return _RED


class ExperimentLogger:
    """
    Logs metrics, strategies, and free-text messages.

    Args:
        log_dir:  Directory where log files are written.
        verbose:  If True, prints to stdout.
        name:     Experiment name (used in log file names).
    """

    def __init__(
        self,
        log_dir: str = "./logs",
        verbose: bool = True,
        name:    str  = "exp",
    ) -> None:
        self.verbose  = verbose
        self.log_dir  = log_dir
        self.name     = name
        self._start_t = time.time()

        os.makedirs(log_dir, exist_ok=True)

        # File handlers
        log_path  = os.path.join(log_dir, f"{name}.log")
        jsonl_path = os.path.join(log_dir, f"{name}.jsonl")

        self._file_logger = logging.getLogger(f"exp.{name}")
        self._file_logger.setLevel(logging.DEBUG)
        if not self._file_logger.handlers:
            fh = logging.FileHandler(log_path, mode="a", encoding="utf-8")
            fh.setFormatter(logging.Formatter("%(asctime)s | %(message)s"))
            self._file_logger.addHandler(fh)

        self._jsonl_path = jsonl_path
        self._jsonl_f    = open(jsonl_path, "a", encoding="utf-8")

    # ──────────────────────────────────────────────────────────────────────────

    def log_cycle(
        self,
        cycle:       int,
        metrics:     UnlearningMetrics,
        strategy:    Optional[StrategyUpdate],
        score:       float,
        explanation: str = "",
        extra:       Optional[Dict] = None,
    ) -> None:
        """Log one complete unlearning cycle."""
        elapsed = time.time() - self._start_t

        # ── Stdout ────────────────────────────────────────────────────────
        if self.verbose:
            col = _colour(score)
            action_str = (
                strategy.action.value[:22] if strategy and not strategy.is_noop()
                else "noop"
            )
            print(
                f"{_BOLD}[{cycle:03d}]{_RESET} {col}score={score:.3f}{_RESET} | "
                f"forget={metrics.forget_acc:.3f} retain={metrics.retain_acc:.3f} "
                f"acc={metrics.accuracy:.3f} priv={metrics.privacy:.3f} "
                f"hall={metrics.hallucination:.3f} stab={metrics.stability:.3f} | "
                f"{_CYAN}{action_str}{_RESET} "
                f"({elapsed:.0f}s)"
            )
            if explanation:
                print(f"         {explanation}")

        # ── File log ──────────────────────────────────────────────────────
        msg = (
            f"[{cycle:03d}] score={score:.3f} | "
            f"forget={metrics.forget_acc:.3f} retain={metrics.retain_acc:.3f} "
            f"acc={metrics.accuracy:.3f} priv={metrics.privacy:.3f} | "
            f"strategy={strategy.action.value if strategy else 'noop'}"
        )
        self._file_logger.info(msg)
        if explanation:
            self._file_logger.debug(f"  explanation: {explanation}")

        # ── JSONL ─────────────────────────────────────────────────────────
        row: Dict[str, Any] = {
            "cycle":    cycle,
            "score":    round(score, 4),
            "elapsed":  round(elapsed, 1),
            "metrics":  metrics.to_dict(),
            "strategy": strategy.action.value if strategy else "noop",
            "delta":    strategy.delta if strategy else 0.0,
            "confidence": strategy.confidence if strategy else 0.0,
            "explanation": explanation[:200],
        }
        if extra:
            row.update(extra)
        self._jsonl_f.write(json.dumps(row) + "\n")
        self._jsonl_f.flush()

    def log_event(self, tag: str, msg: str) -> None:
        """Log a free-text event (rule extraction, evolution, etc.)."""
        if self.verbose:
            print(f"  {_CYAN}[{tag}]{_RESET} {msg}")
        self._file_logger.info(f"[{tag}] {msg}")

    def log_report(self, report: Dict) -> None:
        """Log the ExperienceEngine report at end of run."""
        if self.verbose:
            print(f"\n{'═'*60}")
            print(f"  {_BOLD}Experience Engine Report{_RESET}")
            print(f"{'═'*60}")
            print(f"  Journal entries  : {report.get('journal_entries', 0)}")
            print(f"  Extracted rules  : {report.get('extracted_rules', 0)}")
            mem = report.get("memory_stats", {})
            print(f"  Memory (active)  : {mem.get('active', 0)}")
            print(f"  Memory (dormant) : {mem.get('dormant', 0)}")
            print(f"  Memory (archive) : {mem.get('archive', 0)}")
            meta = report.get("meta_summary", {})
            print(f"  Best score       : {meta.get('best_score', 0.0):.4f} "
                  f"@ cycle {meta.get('best_cycle', 0)}")
            print(f"  Trend            : {meta.get('trend', 'unknown')}")
            print(f"{'═'*60}\n")
        self._file_logger.info(f"[REPORT] {json.dumps(report)}")

    def section(self, title: str) -> None:
        bar = "─" * 56
        if self.verbose:
            print(f"\n{bar}\n  {_BOLD}{title}{_RESET}\n{bar}")
        self._file_logger.info(f"=== {title} ===")

    def close(self) -> None:
        self._jsonl_f.close()
        for h in self._file_logger.handlers:
            h.close()
