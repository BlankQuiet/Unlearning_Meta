"""
utils/visualization.py
========================
Matplotlib-based visualisation for experiment results.

Plots:
  1. Metric trajectories    — 6-panel time series for all metrics
  2. Strategy effectiveness — bar chart of mean score-delta per action
  3. Rule memory state      — pie chart of lifecycle states
  4. Score heatmap          — cycle × metric value heatmap
  5. MIA AUC curve          — ROC-style confidence distribution
"""

from __future__ import annotations
from typing import Dict, List
import os

import matplotlib
matplotlib.use("Agg")   # non-interactive backend for server environments
import matplotlib.pyplot as plt
import numpy as np

from unlearning_meta.evaluation.metrics import MetricsTracker


# ─────────────────────────────────────────────────────────────────────────────
# Colour palette
# ─────────────────────────────────────────────────────────────────────────────

PALETTE = {
    "forget_acc":    "#e74c3c",   # red    (want low)
    "retain_acc":    "#2ecc71",   # green  (want high)
    "accuracy":      "#3498db",   # blue   (want high)
    "privacy":       "#9b59b6",   # purple (want high)
    "hallucination": "#e67e22",   # orange (want low)
    "stability":     "#1abc9c",   # teal   (want high)
    "score":         "#f1c40f",   # yellow (composite)
}


# ─────────────────────────────────────────────────────────────────────────────
# 1. Metric trajectories
# ─────────────────────────────────────────────────────────────────────────────

def plot_metric_trajectories(
    tracker:  MetricsTracker,
    save_dir: str = "./outputs",
    fname:    str = "metric_trajectories.png",
) -> str:
    """
    Plot all 6 metrics + composite score across cycles.
    Returns path to saved figure.
    """
    os.makedirs(save_dir, exist_ok=True)
    cycles = [r.cycle for r in tracker.records]

    metrics_to_plot = [
        ("score",         "Composite Score", True),
        ("forget_acc",    "Forget Accuracy ↓", False),
        ("retain_acc",    "Retain Accuracy ↑", True),
        ("accuracy",      "Test Accuracy ↑", True),
        ("privacy",       "Privacy Score ↑", True),
        ("hallucination", "Overconfident Misclassification Rate (OMR) ↓", False),
        ("stability",     "Stability ↑", True),
    ]

    n_plots = len(metrics_to_plot)
    cols = 2
    rows = (n_plots + 1) // cols

    fig, axes = plt.subplots(rows, cols, figsize=(14, rows * 3.5))
    axes = axes.flatten()

    for ax, (key, label, higher_better) in zip(axes, metrics_to_plot):
        if key == "score":
            vals = tracker.score_series()
        else:
            vals = tracker.metric_series(key)

        colour = PALETTE.get(key, "#555555")
        ax.plot(cycles, vals, color=colour, linewidth=2, label=key)

        # Add moving average
        if len(vals) >= 5:
            ma = np.convolve(vals, np.ones(5) / 5, mode="same")
            ax.plot(cycles, ma, "--", color=colour, alpha=0.5, linewidth=1)

        ax.set_title(label, fontsize=10, fontweight="bold")
        ax.set_xlabel("Cycle")
        ax.set_ylabel(key)
        ax.grid(alpha=0.3)

        # Shade desired direction
        if higher_better:
            ax.axhline(y=max(vals), color=colour, alpha=0.2, linestyle=":")
        else:
            ax.axhline(y=min(vals), color=colour, alpha=0.2, linestyle=":")

    # Hide unused subplots
    for ax in axes[n_plots:]:
        ax.set_visible(False)

    plt.suptitle("Unlearning-MetaLearning: Metric Trajectories", fontsize=13,
                 fontweight="bold")
    plt.tight_layout()

    path = os.path.join(save_dir, fname)
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    return path


# ─────────────────────────────────────────────────────────────────────────────
# 2. Strategy effectiveness
# ─────────────────────────────────────────────────────────────────────────────

def plot_strategy_effectiveness(
    tracker:  MetricsTracker,
    save_dir: str = "./outputs",
    fname:    str = "strategy_effectiveness.png",
) -> str:
    """Bar chart: mean score-delta per strategy action."""
    os.makedirs(save_dir, exist_ok=True)
    eff = tracker.strategy_effectiveness()
    if not eff:
        return ""

    actions   = list(eff.keys())
    mean_deltas  = [eff[a]["mean_delta"]   for a in actions]
    improve_rates = [eff[a]["improve_rate"] for a in actions]
    counts    = [eff[a]["count"]           for a in actions]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # Mean delta
    colours = ["#2ecc71" if d >= 0 else "#e74c3c" for d in mean_deltas]
    bars = ax1.barh(actions, mean_deltas, color=colours, alpha=0.8)
    ax1.axvline(0, color="black", linewidth=0.8)
    ax1.set_title("Mean Score Δ per Strategy", fontweight="bold")
    ax1.set_xlabel("Score Delta")
    for bar, c in zip(bars, counts):
        ax1.text(bar.get_width() + 0.001, bar.get_y() + bar.get_height() / 2,
                 f"n={c}", va="center", fontsize=8)

    # Improvement rate
    bars2 = ax2.barh(actions, improve_rates, color="#3498db", alpha=0.8)
    ax2.set_xlim(0, 1)
    ax2.axvline(0.5, color="orange", linestyle="--", linewidth=1, label="50%")
    ax2.set_title("Improvement Rate per Strategy", fontweight="bold")
    ax2.set_xlabel("P(score improved)")
    ax2.legend()
    # Same n= annotation as ax1: a 100% improve-rate from 1 trial and from
    # 20 trials look identical without this, but mean very different things.
    for bar, c in zip(bars2, counts):
        ax2.text(bar.get_width() + 0.01, bar.get_y() + bar.get_height() / 2,
                  f"n={c}", va="center", fontsize=8)

    plt.suptitle("Strategy Effectiveness Analysis", fontsize=12,
                 fontweight="bold")
    plt.tight_layout()

    path = os.path.join(save_dir, fname)
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    return path


# ─────────────────────────────────────────────────────────────────────────────
# 3. Strategy memory lifecycle
# ─────────────────────────────────────────────────────────────────────────────

def plot_memory_lifecycle(
    memory_stats: Dict[str, int],
    save_dir:     str = "./outputs",
    fname:        str = "memory_lifecycle.png",
) -> str:
    """Pie chart of strategy memory states."""
    os.makedirs(save_dir, exist_ok=True)

    states = ["active", "dormant", "archive", "deleted"]
    labels = ["Active", "Dormant", "Archive", "Deleted"]
    colours = ["#2ecc71", "#f39c12", "#95a5a6", "#e74c3c"]
    sizes  = [memory_stats.get(s, 0) for s in states]

    non_zero = [(l, c, s) for l, c, s in zip(labels, colours, sizes) if s > 0]
    if not non_zero:
        return ""
    labels_nz, colours_nz, sizes_nz = zip(*non_zero)

    fig, ax = plt.subplots(figsize=(7, 5))
    wedges, texts, autotexts = ax.pie(
        sizes_nz, labels=labels_nz, colors=colours_nz,
        autopct="%1.0f%%", startangle=90,
        wedgeprops=dict(edgecolor="white", linewidth=2),
    )
    for t in autotexts:
        t.set_fontsize(10)
    ax.set_title(
        f"Strategy Memory Lifecycle\n"
        f"(total active+dormant+archive = {sum(sizes_nz)}, "
        f"deleted_total = {memory_stats.get('deleted_total', 0)})",
        fontsize=11, fontweight="bold",
    )

    path = os.path.join(save_dir, fname)
    plt.tight_layout()
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    return path


# ─────────────────────────────────────────────────────────────────────────────
# 4. Score heatmap
# ─────────────────────────────────────────────────────────────────────────────

def plot_score_heatmap(
    tracker:  MetricsTracker,
    save_dir: str = "./outputs",
    fname:    str = "score_heatmap.png",
) -> str:
    """Heatmap of all metric values across cycles."""
    os.makedirs(save_dir, exist_ok=True)

    metric_names = ["forget_acc", "retain_acc", "accuracy",
                    "privacy", "hallucination", "stability"]
    cycles = [r.cycle for r in tracker.records]

    # Build matrix  [metrics × cycles]
    matrix = np.array([
        tracker.metric_series(m) for m in metric_names
    ])

    fig, ax = plt.subplots(figsize=(max(10, len(cycles) * 0.4 + 2), 5))
    im = ax.imshow(matrix, aspect="auto", cmap="RdYlGn", vmin=0, vmax=1)

    ax.set_yticks(range(len(metric_names)))
    ax.set_yticklabels(metric_names, fontsize=9)
    ax.set_xticks(range(len(cycles)))
    ax.set_xticklabels(
        [str(c) for c in cycles],
        rotation=90, fontsize=7,
    )
    ax.set_xlabel("Cycle")
    ax.set_title("Metric Value Heatmap (green = good, red = bad)", fontweight="bold")

    plt.colorbar(im, ax=ax, fraction=0.02)
    plt.tight_layout()

    path = os.path.join(save_dir, fname)
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    return path


# ─────────────────────────────────────────────────────────────────────────────
# 5. MIA confidence distribution
# ─────────────────────────────────────────────────────────────────────────────

def plot_mia_distribution(
    forget_confs: List[float],
    test_confs:   List[float],
    save_dir:     str = "./outputs",
    fname:        str = "mia_distribution.png",
) -> str:
    """
    Overlapping histogram of model confidence on forget vs test sets.
    Perfect forgetting → distributions overlap completely.
    """
    os.makedirs(save_dir, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 4))

    bins = np.linspace(0, 1, 30)
    ax.hist(forget_confs, bins=bins, alpha=0.6, color="#e74c3c",
            label="Forget set", density=True)
    ax.hist(test_confs,   bins=bins, alpha=0.6, color="#3498db",
            label="Test set",   density=True)

    ax.set_xlabel("Model Confidence (max softmax prob)")
    ax.set_ylabel("Density")
    ax.set_title("MIA Confidence Distribution\n"
                 "(overlap → good forgetting)", fontweight="bold")
    ax.legend()
    ax.grid(alpha=0.3)

    path = os.path.join(save_dir, fname)
    plt.tight_layout()
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    return path


# ─────────────────────────────────────────────────────────────────────────────
# 6. Full dashboard
# ─────────────────────────────────────────────────────────────────────────────

def generate_dashboard(
    tracker:      MetricsTracker,
    memory_stats: Dict[str, int],
    save_dir:     str = "./outputs",
) -> List[str]:
    """
    Generate all plots and return list of saved file paths.
    """
    paths = []
    paths.append(plot_metric_trajectories(tracker, save_dir))
    paths.append(plot_strategy_effectiveness(tracker, save_dir))
    paths.append(plot_memory_lifecycle(memory_stats, save_dir))
    paths.append(plot_score_heatmap(tracker, save_dir))
    return [p for p in paths if p]
