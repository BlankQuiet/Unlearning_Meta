"""
utils/win_compat.py
======================
Windows-console compatibility shim.

Call enable_console_compat() once, as early as possible — ideally the
first line of any function that prints to the console — before any
print() statements or logging configuration happens.

Why this exists
----------------
This project prints box-drawing borders (┌─┐│└┘╔═╗║╚╝), arrows (→ ↑ ↓),
and a few trend emoji (📈 ⚠️ 🔴) in cycle-by-cycle output. Windows consoles
outside Windows Terminal / PowerShell 7 commonly default to a locale
codepage rather than UTF-8 (e.g. cp932 on Japanese Windows, cp1252 on
Western European Windows), and Python's print() does NOT catch encoding
errors the way logging.FileHandler does — an unguarded print() of any of
the above characters on such a console raises UnicodeEncodeError and
kills the whole script. On an 8GB-RAM Windows 11 laptop running a plain
`python main.py` from a default cmd.exe window (rather than Windows
Terminal), this is the single most likely first failure a user would hit,
well before any memory or performance concern.

What enable_console_compat() does
-----------------------------------
1. Reconfigures stdout/stderr to UTF-8 (errors="replace" as a last-resort
   safety net) so no Unicode character used anywhere in this codebase can
   ever raise UnicodeEncodeError on print().
2. On Windows specifically, nudges the console host into VT100/ANSI
   escape-sequence processing mode so the ANSI colour codes in
   utils/logger.py render as colour instead of raw control-sequence text.
   This is the well-known zero-dependency `os.system("")` trick, which
   has the side effect of enabling ENABLE_VIRTUAL_TERMINAL_PROCESSING on
   consoles where it isn't already on. Windows 11's default Windows
   Terminal already handles ANSI natively, so this mainly helps legacy
   cmd.exe or scripts launched from older terminals/IDEs.

This module is intentionally dependency-free (no colorama) to keep the
footprint minimal for memory-constrained environments — see config.py's
LOW_MEMORY preset and README.md's "8GB RAM / Windows 11" section.
"""

from __future__ import annotations
import os
import platform
import sys


def enable_console_compat() -> None:
    """
    Make stdout/stderr UTF-8-safe and enable ANSI colour on Windows.

    Safe to call on any platform (Linux/macOS/Windows), any number of
    times — it is a harmless no-op everywhere it isn't needed. Call this
    before any print() / logging call in an entry-point script or in any
    function (e.g. run_experiment()) that may be imported and called
    directly without going through an `if __name__ == "__main__":` guard.
    """
    # ── 1. UTF-8 stdout/stderr ──────────────────────────────────────────
    # Matters on any platform whose default locale encoding isn't UTF-8,
    # which in practice today means Windows.
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                # Best-effort only: if the stream doesn't support
                # reconfigure in this context (e.g. captured/redirected
                # to something unusual), continue without crashing.
                pass

    # ── 2. Enable ANSI escape processing on legacy Windows consoles ────
    if platform.system() == "Windows":
        try:
            os.system("")
        except Exception:
            pass
