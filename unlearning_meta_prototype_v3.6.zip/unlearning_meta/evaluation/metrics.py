"""
evaluation/metrics.py
=======================
Experiment Metrics Tracker

Collects per-cycle metrics and provides statistical summaries,
convergence detection, and export utilities.
"""

from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List, Optional
import json
import os

from unlearning_meta.schemas import UnlearningMetrics, StrategyUpdate


@dataclass
class CycleRecord:
    """One row in the experiment log."""
    cycle:         int
    metrics:       UnlearningMetrics
    strategy:      Optional[StrategyUpdate]
    score:         float
    config_snap:   Dict


class MetricsTracker:
    """
    Persistent experiment log with analysis utilities.

    Attributes:
        records: Ordered list of CycleRecords.
    """

    def __init__(
        self,
        score_weights:      Optional[Dict[str, float]] = None,
        target_forget_acc:  Optional[float] = None,
        retain_floor:       Optional[float] = None,
    ) -> None:
        """
        Args:
            score_weights:      Per-term weights for composite_score().
            target_forget_acc:  See UnlearningMetrics.composite_score() /
                                ARCHITECTURE.md §16. Pass the same value
                                used to construct ExperienceEngine for a
                                run, so logged/reported scores match what
                                the live strategy-selection machinery
                                actually optimised against — otherwise the
                                CSV/JSONL output and printed tables would
                                silently show a *different* score than the
                                one that drove decisions during the run.
            retain_floor:       See UnlearningMetrics.composite_score().
        """
        self.score_weights     = score_weights
        self.target_forget_acc = target_forget_acc
        self.retain_floor      = retain_floor
        self.records: List[CycleRecord] = []

    # ──────────────────────────────────────────────────────────────────────────

    def record(
        self,
        metrics:     UnlearningMetrics,
        strategy:    Optional[StrategyUpdate],
        config_snap: Dict,
    ) -> CycleRecord:
        """Add a cycle record."""
        score = metrics.composite_score(
            self.score_weights,
            target_forget_acc=self.target_forget_acc,
            retain_floor=self.retain_floor,
        )
        rec   = CycleRecord(
            cycle       = metrics.cycle,
            metrics     = metrics,
            strategy    = strategy,
            score       = score,
            config_snap = config_snap,
        )
        self.records.append(rec)
        return rec

    # ──────────────────────────────────────────────────────────────────────────
    # Query helpers
    # ──────────────────────────────────────────────────────────────────────────

    def best_cycle(self) -> Optional[CycleRecord]:
        if not self.records:
            return None
        return max(self.records, key=lambda r: r.score)

    def last_n_scores(self, n: int) -> List[float]:
        return [r.score for r in self.records[-n:]]

    def metric_series(self, name: str) -> List[float]:
        """Return all values of a named metric across cycles."""
        return [getattr(r.metrics, name) for r in self.records]

    def score_series(self) -> List[float]:
        return [r.score for r in self.records]

    # ──────────────────────────────────────────────────────────────────────────
    # Statistical analysis
    # ──────────────────────────────────────────────────────────────────────────

    def summary(self) -> Dict:
        if not self.records:
            return {}

        def stat(vals: List[float]) -> Dict:
            arr = vals
            n   = len(arr)
            mu  = sum(arr) / n
            var = sum((v - mu) ** 2 for v in arr) / max(n - 1, 1)
            return {
                "mean":  round(mu, 4),
                "std":   round(var ** 0.5, 4),
                "min":   round(min(arr), 4),
                "max":   round(max(arr), 4),
                "final": round(arr[-1], 4),
            }

        best = self.best_cycle()
        return {
            "n_cycles":     len(self.records),
            "score":        stat(self.score_series()),
            "forget_acc":   stat(self.metric_series("forget_acc")),
            "retain_acc":   stat(self.metric_series("retain_acc")),
            "accuracy":     stat(self.metric_series("accuracy")),
            "privacy":      stat(self.metric_series("privacy")),
            "hallucination":stat(self.metric_series("hallucination")),
            "stability":    stat(self.metric_series("stability")),
            "best_cycle":   best.cycle if best else -1,
            "best_score":   round(best.score, 4) if best else 0.0,
        }

    def convergence_cycle(self, window: int = 5, tol: float = 0.01) -> int:
        """
        Return the first cycle where the score stabilised (converged).
        Returns -1 if convergence was not detected.
        """
        scores = self.score_series()
        for i in range(window, len(scores)):
            window_scores = scores[i - window: i]
            span = max(window_scores) - min(window_scores)
            if span < tol:
                return self.records[i - window].cycle
        return -1

    def strategy_effectiveness(self) -> Dict[str, Dict]:
        """
        Per-strategy action: count, mean score after use, improvement rate.
        """
        action_data: Dict[str, List[float]] = defaultdict(list)

        for i in range(1, len(self.records)):
            prev = self.records[i - 1]
            curr = self.records[i]
            if prev.strategy is not None:
                delta = curr.score - prev.score
                action_data[prev.strategy.action.value].append(delta)

        result = {}
        for action, deltas in action_data.items():
            n = len(deltas)
            mean_delta  = sum(deltas) / n
            improve_rate = sum(1 for d in deltas if d > 0.01) / n
            result[action] = {
                "count":        n,
                "mean_delta":   round(mean_delta, 4),
                "improve_rate": round(improve_rate, 3),
            }
        return result

    # ──────────────────────────────────────────────────────────────────────────
    # Export
    # ──────────────────────────────────────────────────────────────────────────

    def to_jsonl(self, path: str) -> None:
        """Write records to a JSONL file."""
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            for rec in self.records:
                row = {
                    "cycle":    rec.cycle,
                    "score":    rec.score,
                    "metrics":  rec.metrics.to_dict(),
                    "strategy": rec.strategy.action.value if rec.strategy else "none",
                    "config":   rec.config_snap,
                }
                f.write(json.dumps(row) + "\n")

    def to_csv(self, path: str) -> None:
        """Write metric series as a CSV."""
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        header = (
            "cycle,score,forget_acc,retain_acc,accuracy,"
            "privacy,hallucination,stability,strategy\n"
        )
        with open(path, "w", encoding="utf-8") as f:
            f.write(header)
            for rec in self.records:
                m  = rec.metrics
                st = rec.strategy.action.value if rec.strategy else "none"
                f.write(
                    f"{rec.cycle},{rec.score:.4f},"
                    f"{m.forget_acc:.4f},{m.retain_acc:.4f},{m.accuracy:.4f},"
                    f"{m.privacy:.4f},{m.hallucination:.4f},{m.stability:.4f},"
                    f"{st}\n"
                )

    def print_table(self, last_n: int = 10) -> None:
        """Print a formatted table of the last N records."""
        header = (
            f"{'Cycle':>6} {'Score':>7} {'Forget':>7} {'Retain':>7} "
            f"{'Acc':>7} {'Priv':>7} {'Hall':>7} {'Stab':>7}  Strategy"
        )
        sep = "─" * len(header)
        print(sep)
        print(header)
        print(sep)
        for rec in self.records[-last_n:]:
            m  = rec.metrics
            st = rec.strategy.action.value[:20] if rec.strategy else "noop"
            print(
                f"{rec.cycle:>6} {rec.score:>7.3f} {m.forget_acc:>7.3f} "
                f"{m.retain_acc:>7.3f} {m.accuracy:>7.3f} {m.privacy:>7.3f} "
                f"{m.hallucination:>7.3f} {m.stability:>7.3f}  {st}"
            )
        print(sep)
