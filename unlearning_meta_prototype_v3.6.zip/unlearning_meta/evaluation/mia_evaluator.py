"""
evaluation/mia_evaluator.py
============================
Membership Inference Attack (MIA) Evaluator

Evaluates whether a model has truly forgotten its forget set
by testing if an attacker can distinguish forget data from
unseen data based on model confidence outputs.

Two attack variants are implemented:

  1. Confidence-threshold attack  (fast, no training required)
     — Compare entropy of outputs on forget vs. test sets.
     — AUC ≈ 0.5  →  forget data indistinguishable  (good forgetting).

  2. Shadow-model attack  (more rigorous, requires training a meta-classifier)
     — Train a binary classifier on (confidence_vector → member / non-member).
     — Standard benchmark for privacy audits.

Privacy score  =  1 − 2 · |AUC − 0.5|
  •  1.0  →  perfect forgetting (AUC = 0.5)
  •  0.0  →  complete membership disclosure (AUC = 1.0 or 0.0)
"""

from __future__ import annotations
from typing import Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score
from torch import Tensor
from torch.utils.data import DataLoader, TensorDataset


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _collect_model_outputs(
    model:   nn.Module,
    loader:  DataLoader,
    device:  str,
    max_n:   int = 1000,
) -> Tuple[Tensor, Tensor, Tensor]:
    """
    Collect (softmax_probs, entropy, max_conf) for every sample.

    Returns:
        probs    [N, C]
        entropy  [N]
        max_conf [N]
    """
    model.eval()
    all_probs = []
    total = 0
    with torch.no_grad():
        for x, _ in loader:
            if total >= max_n:
                break
            x = x.to(device)
            logits = model(x)
            probs  = F.softmax(logits, dim=-1)
            all_probs.append(probs.cpu())
            total += x.size(0)

    probs    = torch.cat(all_probs, dim=0)[:max_n]
    entropy  = -(probs * (probs + 1e-9).log()).sum(dim=-1)
    max_conf = probs.max(dim=-1).values
    return probs, entropy, max_conf


def _compute_auc(scores: np.ndarray, labels: np.ndarray) -> float:
    """
    Compute ROC-AUC.

    Bug found and fixed (external review, 2026-08-16): the previous
    version computed ranks via plain `np.argsort`, which assigns tied
    scores a strict, arbitrary total order (whatever the sort algorithm's
    tie-break happens to produce) instead of the average rank proper
    Mann-Whitney U / ROC-AUC requires for tied values. Verified directly:
    scores=[0.5,0.5], labels=[1,0] (one positive and one negative example
    with an identical score -- exactly the kind of tie a small MIA
    evaluation set or a saturated/quantized model output can produce)
    returned 0.0 from the old implementation; the correct value, cross-
    checked against sklearn.metrics.roc_auc_score, is 0.5. A second case
    (two tied pairs) returned 0.25 where 0.5 is correct. Both wrong in
    the same direction (biased toward reporting an artificially strong
    attack whenever ties are present), not simply noisy.

    Fixed by using sklearn.metrics.roc_auc_score directly -- scikit-learn
    is already a required dependency (requirements.txt) and is already
    used for this exact computation elsewhere in this codebase
    (modules/unlearning/evaluator.py's _mia_privacy_score, which feeds
    composite_score), so this also removes a previously-undetected
    inconsistency where two different AUC implementations coexisted in
    the same project. Traced, not assumed: composite_score's privacy
    term was already using sklearn's roc_auc_score before this fix and
    is therefore unaffected by this bug, exactly as it was unaffected by
    SS29's Shadow MIA leakage -- this bug lived only in ShadowMIA's own
    _compute_auc, which (per SS29.2) is not reachable from any scored or
    reported comparison in this document.

    The n_pos==0 / n_neg==0 fallback is preserved here rather than
    delegated to sklearn, since roc_auc_score raises in that case rather
    than returning a neutral value, and this function's callers rely on
    always getting a float back.
    """
    n_pos = (labels == 1).sum()
    n_neg = (labels == 0).sum()
    if n_pos == 0 or n_neg == 0:
        return 0.5
    return float(roc_auc_score(labels, scores))


# ─────────────────────────────────────────────────────────────────────────────
# Attack 1: Confidence-threshold MIA
# ─────────────────────────────────────────────────────────────────────────────

class ConfidenceMIA:
    """
    Simple confidence-based MIA.

    Attacker assumes high-confidence predictions signal membership.
    After unlearning, forget samples should have *low* confidence
    (similar to unseen test samples).
    """

    def __init__(self, device: str = "cpu", max_samples: int = 1000) -> None:
        self.device      = device
        self.max_samples = max_samples

    def evaluate(
        self,
        model:         nn.Module,
        forget_loader: DataLoader,
        test_loader:   DataLoader,
    ) -> Dict[str, float]:
        """
        Run confidence-based MIA.

        Returns:
            {
              "auc":            float  (0.5 = perfect forgetting),
              "privacy_score":  float  (1.0 = perfect privacy),
              "forget_entropy": float,
              "test_entropy":   float,
              "forget_conf":    float,
              "test_conf":      float,
            }
        """
        n = self.max_samples // 2

        _, f_ent, f_conf = _collect_model_outputs(
            model, forget_loader, self.device, n
        )
        _, t_ent, t_conf = _collect_model_outputs(
            model, test_loader, self.device, n
        )

        # Use max confidence as membership score (higher = more likely member)
        scores = np.concatenate([f_conf.numpy(), t_conf.numpy()])
        labels = np.concatenate([
            np.ones(len(f_conf)), np.zeros(len(t_conf))
        ])

        auc = _compute_auc(scores, labels)
        privacy = float(max(0.0, min(1.0, 1.0 - 2.0 * abs(auc - 0.5))))

        return {
            "auc":            round(auc, 4),
            "privacy_score":  round(privacy, 4),
            "forget_entropy": round(f_ent.mean().item(), 4),
            "test_entropy":   round(t_ent.mean().item(), 4),
            "forget_conf":    round(f_conf.mean().item(), 4),
            "test_conf":      round(t_conf.mean().item(), 4),
        }


# ─────────────────────────────────────────────────────────────────────────────
# Attack 2: Shadow-model MIA
# ─────────────────────────────────────────────────────────────────────────────

class ShadowMIA:
    """
    Shadow-model MIA (Shokri et al., 2017).

    Trains a binary meta-classifier on top of the target model's
    output probabilities to distinguish members from non-members.
    """

    def __init__(
        self,
        device:         str   = "cpu",
        max_samples:    int   = 2000,
        meta_epochs:    int   = 20,
        meta_lr:        float = 0.01,
    ) -> None:
        self.device      = device
        self.max_samples = max_samples
        self.meta_epochs = meta_epochs
        self.meta_lr     = meta_lr

    def evaluate(
        self,
        model:         nn.Module,
        forget_loader: DataLoader,
        test_loader:   DataLoader,
        retain_loader: Optional[DataLoader] = None,
    ) -> Dict[str, float]:
        """
        Train a meta-classifier and compute attack AUC.

        Args:
            model:          Target model to attack.
            forget_loader:  Forget-set samples  (positive / member class).
            test_loader:    Test-set samples     (negative / non-member class).
            retain_loader:  Optional retain samples for training meta-clf.

        Returns:
            {"auc": float, "privacy_score": float, "attack_acc": float,
             "strict_split": bool}  -- strict_split is False only in the
            degenerate fallback case (see below), signaling to callers
            that the leak-prevention guarantee did not hold for this run.

        Bug found and fixed (external review, 2026-08-16): the previous
        version collected test-set outputs ONCE and reused the identical
        samples as the non-member class in BOTH the meta-classifier's own
        training data (paired with retain) AND its evaluation data (paired
        with forget) -- the meta-classifier was being evaluated on data it
        had already seen the distribution of during its own training,
        which is not a genuine held-out test of the attack's
        generalization. Verified this never affected any result reported
        in ARCHITECTURE.md: composite_score's privacy term comes from a
        separate, independent confidence-only calculation
        (UnlearningEvaluator._mia_privacy_score) that never calls this
        class; ShadowMIA/MIAEvaluator are only reachable from main.py,
        run_real_experiment.py, and run_instance_level_experiment.py,
        each of which only prints its result as a supplementary,
        end-of-run diagnostic, never storing it in any seed_results/ file
        or feeding it back into any scoring/comparison decision. Fixed
        below by splitting the collected test outputs into two disjoint
        halves before they are ever used, so the eval-side non-member
        samples are never seen during the meta-classifier's training.
        """
        n = self.max_samples // 2
        train_loader_src = retain_loader or test_loader

        # ── Collect features ─────────────────────────────────────────────
        # Test set collected at 2n (not n): it needs to be split into two
        # disjoint halves below, so twice as many samples are requested to
        # keep each half's size comparable to what a single n-sized
        # collection would have given before this fix.
        f_probs, _, _ = _collect_model_outputs(model, forget_loader, self.device, n)
        t_probs, _, _ = _collect_model_outputs(model, test_loader,   self.device, 2 * n)
        r_probs, _, _ = _collect_model_outputs(model, train_loader_src, self.device, n)

        t_probs_train, t_probs_eval = self._split_test_outputs(t_probs)
        # True unless the degenerate (<2 test samples) fallback fired, in
        # which case t_probs_train and t_probs_eval are the SAME tensor —
        # the leak-prevention guarantee does not hold for that one run.
        # Surfaced in the return value (external review round 6, Gemini/
        # ChatGPT) rather than left only as an internal, silent fallback,
        # so a caller can programmatically detect and act on it.
        strict_split = len(t_probs) >= 2

        # ── Build meta-dataset ────────────────────────────────────────────
        # Training: retain (member) vs held-out-half of test (non-member)
        X_train = torch.cat([r_probs, t_probs_train], dim=0)
        y_train = torch.cat([
            torch.ones(len(r_probs)), torch.zeros(len(t_probs_train))
        ]).long()

        # Test: forget (member) vs the OTHER half of test (non-member) --
        # disjoint from t_probs_train, closing the leak.
        X_test = torch.cat([f_probs, t_probs_eval], dim=0)
        y_test = torch.cat([
            torch.ones(len(f_probs)), torch.zeros(len(t_probs_eval))
        ]).long()

        # ── Train meta-classifier ─────────────────────────────────────────
        meta_clf = self._build_meta_clf(X_train.shape[1]).to(self.device)
        self._train_meta(meta_clf, X_train, y_train)

        # ── Evaluate ──────────────────────────────────────────────────────
        meta_clf.eval()
        with torch.no_grad():
            X_test = X_test.to(self.device)
            logits = meta_clf(X_test)
            probs  = F.softmax(logits, dim=-1)[:, 1].cpu().numpy()
            preds  = (probs >= 0.5).astype(int)

        auc        = _compute_auc(probs, y_test.numpy())
        attack_acc = (preds == y_test.numpy()).mean()
        privacy    = float(max(0.0, min(1.0, 1.0 - 2.0 * abs(auc - 0.5))))

        return {
            "auc":          round(auc, 4),
            "privacy_score": round(privacy, 4),
            "attack_acc":   round(float(attack_acc), 4),
            "strict_split": strict_split,
        }

    # ──────────────────────────────────────────────────────────────────────────

    def _split_test_outputs(self, t_probs: Tensor) -> Tuple[Tensor, Tensor]:
        """
        Split collected test-set outputs into two disjoint halves: one
        for the meta-classifier's own training (paired with retain as
        the non-member class) and one for its evaluation (paired with
        forget as the non-member class). Pulled out as its own method
        specifically so the no-overlap property is directly unit-testable
        without needing to run the full stochastic evaluate() pipeline
        (mirroring _effective_epsilon in fisher_forgetting_baseline.py
        and _mean_rescale in memory_trace.py).

        Bug found and fixed (external review, 2026-08-16): evaluate()
        previously used the SAME collected test outputs as the
        non-member class in both its training data and its evaluation
        data, so the meta-classifier's evaluation was against data it
        had already seen the distribution of during its own training —
        not a genuine held-out test of the attack's generalization.

        Args:
            t_probs: collected test-set model outputs, shape [N, C].

        Returns:
            (t_probs_train, t_probs_eval) — disjoint splits of t_probs.
            Degenerate case (len(t_probs) < 2, no split possible):
            returns t_probs for both rather than raising, so evaluate()
            degrades gracefully on a tiny test set instead of crashing.
        """
        if len(t_probs) < 2:
            return t_probs, t_probs
        perm = torch.randperm(len(t_probs))
        half = len(t_probs) // 2
        return t_probs[perm[:half]], t_probs[perm[half:]]

    def _build_meta_clf(self, input_dim: int) -> nn.Module:
        return nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 2),
        )

    def _train_meta(
        self,
        clf:     nn.Module,
        X:       Tensor,
        y:       Tensor,
    ) -> None:
        clf.train()
        opt       = torch.optim.Adam(clf.parameters(), lr=self.meta_lr)
        criterion = nn.CrossEntropyLoss()
        dataset   = TensorDataset(X.to(self.device), y.to(self.device))
        loader    = DataLoader(dataset, batch_size=64, shuffle=True)

        for _ in range(self.meta_epochs):
            for xb, yb in loader:
                opt.zero_grad()
                criterion(clf(xb), yb).backward()
                opt.step()


# ─────────────────────────────────────────────────────────────────────────────
# Unified interface
# ─────────────────────────────────────────────────────────────────────────────

class MIAEvaluator:
    """
    Unified MIA evaluation wrapper.

    Runs both ConfidenceMIA and ShadowMIA and returns a combined report.
    """

    def __init__(self, device: str = "cpu", max_samples: int = 1000) -> None:
        self.conf_mia   = ConfidenceMIA(device=device, max_samples=max_samples)
        self.shadow_mia = ShadowMIA(device=device, max_samples=max_samples)

    def evaluate(
        self,
        model:         nn.Module,
        forget_loader: DataLoader,
        retain_loader: DataLoader,
        test_loader:   DataLoader,
    ) -> Dict[str, Dict]:
        """
        Run both MIA attacks and return combined results.

        Returns:
            {
              "confidence_mia": {...},
              "shadow_mia":     {...},
              "final_privacy":  float   (conservative average),
            }
        """
        conf_result   = self.conf_mia.evaluate(model, forget_loader, test_loader)
        shadow_result = self.shadow_mia.evaluate(model, forget_loader, test_loader, retain_loader)

        # Conservative estimate: take the minimum of the two privacy scores
        final_privacy = min(
            conf_result["privacy_score"],
            shadow_result["privacy_score"],
        )

        return {
            "confidence_mia": conf_result,
            "shadow_mia":     shadow_result,
            "final_privacy":  round(final_privacy, 4),
        }
